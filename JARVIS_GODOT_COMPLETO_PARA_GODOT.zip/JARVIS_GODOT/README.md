# JARVIS — projeto Godot para Android

**Projeto-fonte completo para abrir no Godot 4.7.2.** Este pacote não contém APK nem modelo GGUF.

## Importante: estado real do pacote

- O projeto Godot, telas, scripts, dados, plugin Android Kotlin/C++, integração JNI/llama.cpp, scripts de compilação e workflow GitHub Actions estão incluídos.
- A verificação estática `python tools/check_project.py` passou: 58 métodos Android expostos e 49 usados pelo GDScript, sem erros reportados.
- **Os arquivos `jarvis-debug.aar` e `jarvis-release.aar` NÃO estão incluídos.** Eles contêm o plugin Android e a biblioteca nativa `libjarvis_llama.so`. Sem esses AARs, a interface do projeto pode abrir, mas a IA local nativa, o seletor/importador GGUF e as funções Android do plugin não estarão operacionais no APK.
- O AAR ainda precisa ser compilado com Android SDK/NDK, CMake, JDK 17 e acesso à internet para baixar o Gradle e o llama.cpp. O projeto inclui `jarvis_android_plugin/scripts/build_aar.sh` e `.bat`, além de `.github/workflows/build-android.yml`.
- Não foi possível executar compilação Android nem teste em aparelho neste ambiente. Portanto, não afirmamos que o APK ou a inferência no celular já foram validados.

## Abrir no Godot

1. Extraia o ZIP mantendo a pasta `JARVIS_GODOT`.
2. Abra `project.godot` no **Godot 4.7.2**.
3. Aguarde a importação dos recursos.
4. Para exportar Android com o plugin v2, é necessário ter os AARs reais em `addons/jarvis_android/bin/` e usar o fluxo Gradle de Android. O preset Android já está no projeto.
5. Não tente exportar como se o AAR estivesse pronto: o exportador bloqueia a exportação incompleta em vez de criar um APK sem o motor de IA.

## Compilar o plugin Android

Em um ambiente de compilação compatível:

- JDK 17
- Android SDK platform 35
- Android NDK `27.2.12479018`
- CMake `3.22.1`
- Git e Python 3
- Conexão com a internet

Linux/macOS:
```bash
cd jarvis_android_plugin
bash scripts/build_aar.sh
```

Windows:
```bat
cd jarvis_android_plugin
scripts\build_aar.bat
```

A compilação deve gerar os AARs em `addons/jarvis_android/bin/`. Depois disso, abra/exporte o projeto com Gradle Android habilitado. O workflow `.github/workflows/build-android.yml` também automatiza AAR e APK em GitHub Actions quando o projeto está na raiz de um repositório e o workflow é executado.

## Modelo de IA

O modelo GGUF não é incluído no ZIP nem no APK. O app foi preparado para importar um arquivo GGUF pelo seletor Android depois que o plugin nativo estiver compilado e incluído. O modelo ocupa armazenamento adicional (aproximadamente 1,2 GB para a configuração Qwen 1.5B quantizada indicada na documentação).

Consulte `docs/IMPORTAR_MODELO_ANDROID.md`, `docs/COMPILAR_PLUGIN_ANDROID.md` e `docs/RELATORIO_TESTES.md`.

## Validação estática

Execute:
```bash
python tools/check_project.py
python tools/lint_gd.py
```

A aprovação estática não substitui a compilação Kotlin/C++, exportação APK e teste real no dispositivo.
