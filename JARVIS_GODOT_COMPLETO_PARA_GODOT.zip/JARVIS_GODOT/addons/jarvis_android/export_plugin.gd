@tool
extends EditorExportPlugin
# Plugin Android v2: inclui o AAR Kotlin + llama.cpp. Se ainda nao existir, tenta compila-lo
# automaticamente no primeiro export Android (requer JDK 17, Android SDK/NDK, CMake, Git e internet).

const PLUGIN_NAME := "JarvisPlugin"
const AAR_DEBUG := "res://addons/jarvis_android/bin/jarvis-debug.aar"
const AAR_RELEASE := "res://addons/jarvis_android/bin/jarvis-release.aar"
const BUILD_SH := "res://jarvis_android_plugin/scripts/build_aar.sh"
const BUILD_BAT := "res://jarvis_android_plugin/scripts/build_aar.bat"
const MIN_AAR_BYTES := 1000000
# Vosk opcional. STT/TTS padrao usa APIs do Android e nao depende de download adicional.
const INCLUDE_VOSK := false

func _get_name() -> String:
	return PLUGIN_NAME

func _supports_platform(platform: EditorExportPlatform) -> bool:
	return platform is EditorExportPlatformAndroid

func _build_plugin_if_needed() -> bool:
	var debug_ok := _valid_aar(AAR_DEBUG)
	var release_ok := _valid_aar(AAR_RELEASE)
	if debug_ok and release_ok:
		return true

	var output: Array = []
	var exit_code := -1
	if OS.get_name() == "Windows":
		var bat := ProjectSettings.globalize_path(BUILD_BAT)
		if not FileAccess.file_exists(BUILD_BAT):
			push_error("[JARVIS] Script de compilacao Windows ausente: " + BUILD_BAT)
			return false
		exit_code = OS.execute("cmd.exe", ["/C", bat], output, true)
	else:
		var sh := ProjectSettings.globalize_path(BUILD_SH)
		if not FileAccess.file_exists(BUILD_SH):
			push_error("[JARVIS] Script de compilacao ausente: " + BUILD_SH)
			return false
		exit_code = OS.execute("bash", [sh], output, true)

	for line in output:
		print("[JARVIS build] ", line)
	if exit_code != 0:
		push_error("[JARVIS] Nao foi possivel compilar o plugin Android (codigo %d). Veja o console do Godot. Requisitos: JDK 17, Android SDK/NDK, CMake, Git e internet." % exit_code)
		return false
	return _valid_aar(AAR_DEBUG) and _valid_aar(AAR_RELEASE)

func _valid_aar(path: String) -> bool:
	if not FileAccess.file_exists(path):
		return false
	var f := FileAccess.open(path, FileAccess.READ)
	return f != null and f.get_length() >= MIN_AAR_BYTES

func _get_android_libraries(platform: EditorExportPlatform, debug: bool) -> PackedStringArray:
	if not _build_plugin_if_needed():
		push_error("[JARVIS] O plugin Android completo e obrigatorio. O APK nao pode ser exportado sem o AAR real do llama.cpp.")
		return PackedStringArray()
	var path := AAR_DEBUG if debug else AAR_RELEASE
	print("[JARVIS] Plugin Android incluido: %s" % path)
	return PackedStringArray([path])

func _get_android_dependencies(platform: EditorExportPlatform, debug: bool) -> PackedStringArray:
	var deps := PackedStringArray()
	if INCLUDE_VOSK:
		deps.append("com.alphacephei:vosk-android:0.3.47")
		deps.append("net.java.dev.jna:jna:5.13.0@aar")
	return deps
