@tool
extends EditorPlugin

const ExportPlugin = preload("res://addons/jarvis_android/export_plugin.gd")
var _export_plugin = null

func _enter_tree() -> void:
	_export_plugin = ExportPlugin.new()
	add_export_plugin(_export_plugin)

func _exit_tree() -> void:
	if _export_plugin != null:
		remove_export_plugin(_export_plugin)
		_export_plugin = null
