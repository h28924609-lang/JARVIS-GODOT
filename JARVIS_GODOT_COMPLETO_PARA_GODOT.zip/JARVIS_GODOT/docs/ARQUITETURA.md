# Arquitetura

```
Godot (GDScript)                          Plugin Android (Kotlin, AAR)             Nativo
UI/Orb/Telas -> Agent (cerebro) ------->  JarvisPlugin (@UsedByGodot, JSON) ---->  libjarvis_llama.so (JNI)
   IntentRouter (regras PT-BR)            LlmManager / ModelDownloader               llama.cpp (CPU, GGUF, mmap)
   Persona (prompt + templates)           TtsController / SttController / Vosk
   Store (historico, memoria)             AppManager / SafetyPolicy / PlanExecutor
   Safety (confirmacoes)  <---- sinal unico "jarvis_event(nome, json)" ------  JarvisAccessibilityService
```
## Decisoes
- **Motor**: llama.cpp (tag `b8008`) via JNI proprio, CPU, `mmap`, contexto 3072. Escolhido por estabilidade/leveza e por suportar GGUF quantizado.
  Cache de prefixo do KV (so reprocessa o que mudou), cancelamento a qualquer token, gramatica GBNF opcional, `throttle` termico.
- **Personalidade independente do modelo**: JSON de persona + adaptadores de template (ChatML, Llama 3, Gemma).
- **Memoria != treinamento**: notas em `user://memory.json`, busca lexical com orcamento de tokens; injetadas na mensagem do usuario (prefixo do sistema permanece estavel para o cache).
- **Comandos**: (1) regras PT-BR para comandos diretos; (2) para pedidos ambiguos, o modelo gera JSON **restrito por gramatica** (`data/grammar/plan.gbnf`); (3) `plan_evaluate` (Kotlin) classifica cada passo; (4) confirmacao no Godot; (5) `plan_execute` roda em thread do plugin e **reavalia cada passo** com o app em primeiro plano.
- **Por que o executor fica no Kotlin**: o Godot pausa quando outro app abre; o plano precisa continuar sozinho.
- **Recuperacao de falhas**: sinalizadores de carga/geracao detectam encerramento brusco; `onTrimMemory` descarrega o modelo; descarregamento por inatividade; protecao termica (reduz/pausa). Melhoria futura: motor em processo separado.
- **Otimizacao**: arm64 apenas; `-march=armv8.2-a+dotprod` (se der SIGILL, `-PcpuArch=armv8-a`); threads configuraveis + benchmark; modo economia (30 fps, animacoes simples).
