# Compilar o plugin Android do JARVIS

O seletor de arquivos GGUF e a inferencia local so aparecem/funcionam quando o APK inclui o plugin Android v2 e `libjarvis_llama.so`. O ZIP de fontes nao contem AAR precompilado.

## Windows

1. Instale JDK 17, Git, CMake 3.22.1+, Android SDK (platform 35), Android NDK `27.2.12479018` e configure `ANDROID_HOME` (ou `ANDROID_SDK_ROOT`).
2. Confirme que `java -version` mostra Java 17 e que `sdkmanager --list` mostra os pacotes acima.
3. Execute `tools/BUILD_PLUGIN_WINDOWS.bat`.
4. O processo baixa a tag de llama.cpp indicada em `jarvis_android_plugin/scripts/LLAMA_CPP_TAG`, compila Kotlin + C++ para `arm64-v8a`, gera os dois AAR e valida o ELF e as classes.
5. Confirme que existem `addons/jarvis_android/bin/jarvis-debug.aar` e `jarvis-release.aar`.
6. Abra o projeto no Godot, confirme o plugin `JarvisPlugin` ativado em Project > Project Settings > Plugins e exporte Android novamente.

## Linux

Execute `tools/BUILD_PLUGIN_LINUX.sh` com os mesmos requisitos instalados.

## Como saber se deu certo

O script termina com `OK` para os dois AAR. O arquivo release deve conter `jni/arm64-v8a/libjarvis_llama.so`, classes Kotlin do plugin e o manifesto do Godot Plugin v2. Um AAR vazio ou sem a biblioteca nativa falha na validação.

Ao abrir o APK, a tela Modelos de IA deve indicar `Fonte dos dados: plugin Android` e mostrar `Selecionar arquivo GGUF`. Se ainda mostrar `plugin ausente`, esse APK foi exportado sem o AAR ou o plugin não foi ativado.

## Limite desta entrega

A compilação precisa baixar llama.cpp e dependências Gradle, e requer Android SDK/NDK. O ambiente que preparou este ZIP não possui Android SDK/NDK nem acesso de rede ao GitHub; portanto não foi possível gerar nem testar AAR/APK aqui. Não use arquivos AAR vazios como substitutos.
