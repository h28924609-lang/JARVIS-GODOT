# Importacao do modelo GGUF no Android

## Fluxo implementado

1. Na tela **Modelos**, toque em **Importar arquivo GGUF**.
2. O JARVIS abre o seletor de documentos do Android (`ACTION_OPEN_DOCUMENT`).
3. Escolha o arquivo `.gguf` no armazenamento, Downloads ou provedor de arquivos.
4. O plugin Kotlin copia o fluxo para `filesDir/models/` do aplicativo, sem pedir permissao ampla de armazenamento.
5. A copia valida o magic `GGUF`, le o cabecalho mesmo quando o provedor entrega blocos pequenos, informa progresso, verifica espaco e grava primeiro em `.part`.
6. Somente depois da copia integral e sincronizada o arquivo e renomeado para `.gguf`. Se a substituicao falhar, o modelo anterior e restaurado.
7. O GDScript recebe `model_import=done`, atualiza a lista e solicita o carregamento real pelo JNI. A tela so marca **Ativo** depois do evento `llm_load=ready`.

## Armazenamento

- Pasta privada usada pelo llama.cpp: `Context.filesDir/models/`.
- A importacao copia o modelo selecionado; o original nao e apagado.
- Arquivos incompletos `.part` nunca aparecem como modelos prontos.
- O modelo nao e empacotado dentro do APK.

## Requisitos para exportar o APK com o motor local

O projeto contem o codigo-fonte Kotlin/JNI e a receita de compilacao do llama.cpp, mas os AAR nao sao distribuidos neste ZIP. Na primeira exportacao Android feita pelo Godot Desktop, o export plugin tenta compilar os AAR automaticamente. O computador precisa ter:

- Godot 4.7.2 e templates Android da mesma versao;
- JDK 17;
- Android SDK platform 35 e Android NDK `27.2.12479018`;
- CMake 3.22.1;
- Git, Python 3 e acesso a internet para obter o Gradle e o llama.cpp fixado em `scripts/LLAMA_CPP_TAG`.

O primeiro build pode demorar. Se o ambiente nao tiver os requisitos ou nao puder acessar os repositorios, a exportacao falha com erro no console do Godot; nao e gerado um APK que finja ter IA local.

## Configuracao recomendada

Para Qwen2.5-1.5B-Instruct-Q4_K_M no aparelho com 8 GB de RAM, o perfil inicial usa CPU ARM64, mmap, 4 threads, contexto de 3072 e batch 256. O Android pode descarregar o modelo sob pressao critica de memoria. Se houver encerramento por memoria, reduza `n_ctx` para 2048 nas configuracoes do JARVIS.

## Limite de validacao desta entrega

A importacao foi corrigida por inspecao do fluxo Kotlin e validacoes estaticas. Este ambiente nao tem Android SDK/NDK, Gradle baixado, Godot nem aparelho fisico; portanto, ainda nao foi possivel compilar o AAR, instalar o APK ou executar a importacao real no Android. A inferencia local tambem depende do AAR nativo compilado no primeiro export.
