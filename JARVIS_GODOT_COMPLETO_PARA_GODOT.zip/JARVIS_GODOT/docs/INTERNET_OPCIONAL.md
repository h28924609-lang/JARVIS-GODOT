# Internet opcional
Desligada por padrao. Implementado (gratuito, sem chave): **Wikipedia pt** e **Open-Meteo** (clima), so o termo pesquisado, com dialogo de autorizacao.
**Pesquisa geral na web: desativada** (nao ha opcao gratuita e confiavel sem servidor/chave). Para adicionar: implemente um provedor em `scripts/core/net.gd`
(ex.: SearXNG proprio, Brave Search com chave gratuita) e registre uma intencao em `intent_router.gd`.
