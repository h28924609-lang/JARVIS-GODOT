# Modelos avaliados (nao medidos no aparelho)
| Modelo | Tamanho (Q4_K_M) | Licenca | Nota |
|---|---|---|---|
| **Qwen2.5 1.5B Instruct** (padrao) | ~1,1 GB | Apache-2.0 | Bom pt-BR para o porte, ChatML, estavel no llama.cpp. Esperado: poucos tokens/s em CPU de Galaxy A16 |
| Qwen2.5 0.5B Instruct | ~0,4 GB | Apache-2.0 | Mais rapido, qualidade menor |
| Qwen2.5 3B | ~2 GB | Qwen Research (nao comercial) | Fora do catalogo por licenca |
| Llama 3.2 3B | ~2 GB | Llama Community | Bom pt, mas lento e licenca com condicoes: use "Adicionar modelo" se quiser |
| Gemma 3 1B | ~0,8 GB | Gemma | 1B e basicamente ingles |
Velocidades reais dependem do aparelho: use *Diagnostico > Medir velocidade* e ajuste threads. Modelos novos: *Modelos de IA > Adicionar modelo (GGUF)*.
URLs: `huggingface.co/Qwen/Qwen2.5-*-Instruct-GGUF` (arquivos `qwen2.5-1.5b-instruct-q4_k_m.gguf` e `...0.5b...`). O tamanho exato vem do servidor ao baixar.
