# Relatorio - pacote de preparacao Android e importacao GGUF

Data: 2026-11-05

## Alteracoes realizadas nesta versao

- O importador Kotlin agora le o cabecalho GGUF em loop, evitando rejeitar arquivos validos quando um provedor SAF entrega menos de quatro bytes por leitura.
- A importacao fecha o fluxo em erro de espaco, copia para `.part`, sincroniza o arquivo, valida o tamanho declarado e faz substituicao com rollback para preservar o modelo anterior.
- O gerenciador nativo valida extensao, tamanho e magic GGUF antes de iniciar a carga JNI; arquivos incorretos nao sao enviados ao llama.cpp.
- A listagem aceita extensoes `.gguf` em maiusculas ou minusculas.
- A exclusao de um modelo que esta carregado/gerando foi serializada na fila do motor para nao apagar o arquivo enquanto o llama.cpp ainda o utiliza.
- O export plugin do Godot tenta compilar automaticamente os AAR no primeiro export Android, em vez de apenas emitir erro de arquivo ausente.
- Adicionado script Windows `build_aar.bat`, mantido script Linux/macOS e documentado o fluxo de importacao.

## Verificacoes executadas

| Verificacao | Resultado |
|---|---|
| `tools/check_project.py` | Aprovado: caminhos, JSON, metodos, eventos, JNI e manifest estaticamente consistentes |
| `tools/lint_gd.py` | 23 scripts verificados; 3 avisos de inferencia Variant ja existentes em `agent.gd` e `store.gd` |
| `bash -n` nos scripts shell | Aprovado |
| Python `py_compile` nos validadores | Aprovado |
| Inspecao da API C do llama.cpp fixada em `b8008` | Os simbolos usados foram comparados com os headers dessa revisao; nao substitui compilacao |

## Bloqueios e testes nao executados

- AAR debug/release nao estao incluidos porque nao foi possivel compilar neste ambiente.
- O wrapper Gradle tentou baixar Gradle 8.10.2, mas a resolucao DNS para `services.gradle.org` falhou (`UnknownHostException`).
- O clone de llama.cpp tambem depende de acesso a `github.com`.
- Este ambiente nao possui Android SDK/NDK configurados, Godot executavel nem dispositivo Android conectado.
- Nao foi possivel compilar Kotlin/C++, exportar/instalar APK, escolher um GGUF no seletor Android, carregar o Qwen na memoria ou medir inferencia real no Galaxy A16.
- Microfone, TTS e acoes Android tambem nao foram testados em dispositivo fisico.

## Como o primeiro build deve ocorrer no computador do usuario

Ao exportar Android pelo Godot Desktop, o `EditorExportPlugin` tenta executar `build_aar.bat` no Windows ou `build_aar.sh` no Linux/macOS se os AAR nao existirem. O computador precisa de JDK 17, Godot 4.7.2 com templates Android, Android SDK platform 35, NDK `27.2.12479018`, CMake 3.22.1, Git, Python 3 e internet para baixar Gradle e a revisao fixada do llama.cpp.

Se o build do AAR terminar corretamente, o exportador inclui `libjarvis_llama.so` para `arm64-v8a` e o plugin Kotlin no APK. O modelo GGUF permanece fora do APK e e importado pelo seletor SAF para o armazenamento privado do aplicativo.

## Estado desta entrega

Este ZIP e um pacote de codigo-fonte corrigido e preparado para compilar o plugin no primeiro export em um computador com os requisitos. **Ainda nao e um APK validado e nao se pode afirmar que a importacao/inferencia ja foi comprovada no Android.** A importacao real depende do AAR gerado com sucesso e de um teste no aparelho.
