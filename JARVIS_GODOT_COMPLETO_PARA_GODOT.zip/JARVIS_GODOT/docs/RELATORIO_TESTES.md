# Relatorio de testes (atualizado)

**Resumo honesto:** o AAR, o APK e o carregamento/resposta do modelo **NAO foram executados nem comprovados** neste ambiente
(sem Android SDK/NDK, sem acesso ao Maven/Google/Gradle, sem aparelho e sem o arquivo GGUF). Abaixo, o que foi realmente conferido.

## Verificado nesta rodada
| Verificacao | Como | Resultado |
|---|---|---|
| Projeto abre no Godot 4.7.2 oficial (desktop, headless) | `godot --headless --import` e execucao da cena principal | sem erros de script; so o aviso esperado "plugin nao encontrado" (no PC nao existe o AAR) |
| Telas Modelos / Configuracoes / Diagnostico instanciam | cena de teste temporaria dentro do projeto | ok, incluindo eventos de importacao simulados |
| Plugin Kotlin compila (checagem de tipos) | `kotlinc 2.0.21` + `android.jar` API 34 + stubs da API Godot (nao a godot-lib real) | **2 erros reais encontrados e corrigidos** (`PlanExecutor.kt`: Char x String; `LlmManager.kt`: colisao JVM `setThreads`). Depois: sem erros |
| Motor nativo C++ (JNI) | `g++ -fsyntax-only` com os cabecalhos reais do llama.cpp `b8008` + `jni.h` do OpenJDK | sem erros (nao e o compilador do NDK e nao liga a biblioteca) |
| `tools/lint_gd.py`, `tools/check_project.py` | scripts do projeto | sem erros; metodos chamados no GDScript existem no Kotlin |
| Versoes de SDK/NDK exigidas pelo Godot 4.7.2 | lidas de `platform/android/java/app/config.gradle` (tag 4.7.2-stable) | CI corrigido: platform 36, build-tools 36.1.0, NDK 29.0.14206865 |

## NAO verificado (precisa do seu build/aparelho)
- Compilacao real do AAR (Gradle + NDK + CMake) e do APK (export do Godot com Gradle).
- `libjarvis_llama.so` dentro do APK, plugin registrado no aparelho, sinal Kotlin -> Godot.
- Carregar o GGUF, responder em portugues sem internet, memoria de conversa, consumo de RAM/temperatura no A16.
- Seletor de arquivos (SAF), copia de ~1,1 GB, voz (STT/TTS), acessibilidade.
Todos esses itens tem teste real na tela **Configuracoes > Diagnostico > Executar autoteste completo** (roda no aparelho).

## Riscos conhecidos
1. Gradle/AGP/NDK reais podem acusar erros que a checagem de tipos nao pega (envie o log do passo que falhar).
2. `GodotPlugin` foi checado contra stubs: se a assinatura de `onMainActivityResult` diferir na godot-lib 4.7.2, o seletor de arquivos nao recebe o resultado. O erro aparecera na compilacao do AAR.
3. `-march=armv8.2-a+dotprod`: se o app fechar com SIGILL ao carregar o modelo, recompile com `-PcpuArch=armv8-a`.
4. Palavra de ativacao (Vosk) esta desligada por padrao (`INCLUDE_VOSK := false`).
