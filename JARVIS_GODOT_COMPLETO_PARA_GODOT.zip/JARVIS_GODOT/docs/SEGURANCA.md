# Seguranca
- O modelo **nunca** executa comandos: so propoe passos de ferramentas fixas (`open_app, go_home, go_back, recents, notifications, quick_settings, open_settings, click_text, type_text, scroll, wait, open_url, compose_message, read_screen`).
- **Bloqueados**: apps bancarios/financeiros (lista + heuristicas + lista do usuario), campos de senha, telas de permissao/instalacao, alterar Configuracoes por automacao (so abrir telas permitidas), CPF/cartao digitados, esquemas de URL nao-http(s).
- **Confirmacao** antes de: enviar, publicar, compartilhar, excluir, comprar/pagar, gravar, conceder permissoes/instalar, ligar, ler a tela. Mostra os passos exatos. Passo novo de risco no meio do plano pede nova confirmacao por notificacao.
- Nao ha gravacao de audio/tela escondida. Mensagens sao apenas **preparadas** (voce toca em enviar).
- Lista de bloqueio e heuristica de melhor esforco; revise em Configuracoes. O servico de acessibilidade so age em planos aprovados.
- Dados ficam em `user://` (sem backup do Android). Nada e enviado sem autorizacao.
