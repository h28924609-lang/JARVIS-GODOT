# Plugin Android do Jarvis
Requisitos: JDK 17, Android SDK 35, NDK 27.2.12479018, CMake 3.22.1, Gradle 8.10+, git.
`bash scripts/build_aar.sh` -> clona llama.cpp (`scripts/LLAMA_CPP_TAG`), compila `libjarvis_llama.so` (arm64-v8a) e gera os AAR em `../addons/jarvis_android/bin/`.
Opcoes: `-PgodotVersion=4.7.2.stable`, `-PcpuArch=armv8-a`.
O singleton no Godot e `JarvisPlugin` (sinal `jarvis_event(nome, json)`); metodos em `JarvisPlugin.kt`.
