plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

val godotVersion: String = (project.findProperty("godotVersion") as String?) ?: "4.7.2.stable"

android {
    namespace = "com.jarvis.assistant"
    compileSdk = 35
    ndkVersion = "27.2.12479018"

    defaultConfig {
        minSdk = 24
        consumerProguardFiles("consumer-rules.pro")
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild {
            cmake {
                cppFlags += "-std=c++17"
                arguments += listOf(
                    "-DANDROID_STL=c++_static",
                    "-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON",
                    // Se o app der SIGILL no aparelho, recompile com: -PcpuArch=armv8-a
                    "-DJARVIS_CPU_ARCH=" + ((project.findProperty("cpuArch") as String?) ?: "armv8.2-a+dotprod")
                )
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
        debug { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // Biblioteca Android do Godot (Maven Central). O app final ja a contem: compileOnly.
    compileOnly("org.godotengine:godot:$godotVersion")
}
