// Motor de IA local do Jarvis: ponte JNI fina sobre o llama.cpp (API C, tag fixada em scripts/LLAMA_CPP_TAG).
// Escrito contra a API estavel: llama_model_load_from_file / llama_init_from_model / llama_memory_* /
// llama_sampler_* / llama_batch_get_one / llama_decode. NAO foi compilado no ambiente de desenvolvimento
// (sem NDK); a compilacao real acontece no build do AAR (veja README). Se a API do llama.cpp mudar, ajuste aqui.

#include <jni.h>
#include <android/log.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "llama.h"

#define TAG "JarvisLlama"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

struct Engine {
    llama_model *model = nullptr;
    llama_context *ctx = nullptr;
    const llama_vocab *vocab = nullptr;
    int n_ctx = 0;
    int n_batch = 256;
    std::vector<llama_token> cached;  // tokens atualmente no KV (sequencia 0)
    std::atomic<bool> cancel{false};
    std::atomic<int> throttle_ms{0};
    std::mutex mtx;
    // estatisticas da ultima geracao
    double prefill_ms = 0.0;
    double gen_ms = 0.0;
    int n_prompt = 0;
    int n_reused = 0;
    int n_gen = 0;
};

std::string g_last_error;
bool g_backend_ready = false;
std::mutex g_global_mtx;

void log_callback(enum ggml_log_level level, const char *text, void *) {
    if (text == nullptr) return;
    int prio = ANDROID_LOG_INFO;
    if (level == GGML_LOG_LEVEL_ERROR) prio = ANDROID_LOG_ERROR;
    else if (level == GGML_LOG_LEVEL_WARN) prio = ANDROID_LOG_WARN;
    else if (level == GGML_LOG_LEVEL_DEBUG) return;
    __android_log_write(prio, TAG, text);
}

void ensure_backend() {
    std::lock_guard<std::mutex> lk(g_global_mtx);
    if (g_backend_ready) return;
    llama_log_set(log_callback, nullptr);
    llama_backend_init();
    ggml_backend_load_all();
    g_backend_ready = true;
}

std::string jstr(JNIEnv *env, jstring s) {
    if (s == nullptr) return std::string();
    const char *c = env->GetStringUTFChars(s, nullptr);
    std::string out(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return out;
}

Engine *E(jlong h) { return reinterpret_cast<Engine *>(h); }

bool tokenize(const llama_vocab *vocab, const std::string &text, std::vector<llama_token> &out) {
    out.assign(text.size() + 16, 0);
    int n = llama_tokenize(vocab, text.c_str(), (int32_t) text.size(), out.data(), (int32_t) out.size(),
                           /*add_special=*/false, /*parse_special=*/true);
    if (n < 0) {
        out.assign((size_t) (-n), 0);
        n = llama_tokenize(vocab, text.c_str(), (int32_t) text.size(), out.data(), (int32_t) out.size(), false, true);
    }
    if (n < 0) return false;
    out.resize((size_t) n);
    return true;
}

}  // namespace

extern "C" {

JNIEXPORT void JNICALL Java_com_jarvis_assistant_engine_LlamaBridge_nativeBackendInit(JNIEnv *, jobject) {
    try {
        ensure_backend();
    } catch (...) {
        g_last_error = "falha ao iniciar backend";
    }
}

JNIEXPORT jstring JNICALL Java_com_jarvis_assistant_engine_LlamaBridge_nativeLastError(JNIEnv *env, jobject) {
    return env->NewStringUTF(g_last_error.c_str());
}

JNIEXPORT jstring JNICALL Java_com_jarvis_assistant_engine_LlamaBridge_nativeSystemInfo(JNIEnv *env, jobject) {
    try {
        ensure_backend();
        const char *s = llama_print_system_info();
        return env->NewStringUTF(s ? s : "");
    } catch (...) {
        return env->NewStringUTF("");
    }
}

JNIEXPORT jlong JNICALL Java_com_jarvis_assistant_engine_LlamaBridge_nativeLoad(
        JNIEnv *env, jobject, jstring jpath, jint nCtx, jint nThreads, jint nBatch, jboolean useMmap) {
    try {
        ensure_backend();
        std::string path = jstr(env, jpath);
        g_last_error.clear();

        llama_model_params mp = llama_model_default_params();
        mp.n_gpu_layers = 0;  // somente CPU: estavel e previsivel no Galaxy A16
        mp.use_mmap = useMmap == JNI_TRUE;
        mp.use_mlock = false;

        llama_model *model = llama_model_load_from_file(path.c_str(), mp);
        if (model == nullptr) {
            g_last_error = "nao foi possivel carregar o modelo (arquivo invalido ou memoria insuficiente)";
            return 0;
        }

        llama_context_params cp = llama_context_default_params();
        cp.n_ctx = (uint32_t) std::max(512, (int) nCtx);
        cp.n_batch = (uint32_t) std::max(32, (int) nBatch);
        cp.n_ubatch = std::min(cp.n_batch, (uint32_t) 256);
        cp.n_threads = std::max(1, (int) nThreads);
        cp.n_threads_batch = std::max(1, (int) nThreads);

        llama_context *ctx = llama_init_from_model(model, cp);
        if (ctx == nullptr) {
            llama_model_free(model);
            g_last_error = "nao foi possivel criar o contexto (reduza o tamanho do contexto)";
            return 0;
        }

        Engine *e = new Engine();
        e->model = model;
        e->ctx = ctx;
        e->vocab = llama_model_get_vocab(model);
        e->n_ctx = (int) llama_n_ctx(ctx);
        e->n_batch = (int) cp.n_batch;
        LOGI("modelo carregado: n_ctx=%d n_batch=%d threads=%d", e->n_ctx, e->n_batch, (int) nThreads);
        return reinterpret_cast<jlong>(e);
    } catch (const std::exception &ex) {
        g_last_error = std::string("excecao: ") + ex.what();
        LOGE("%s", g_last_error.c_str());
        return 0;
    } catch (...) {
        g_last_error = "excecao desconhecida ao carregar";
        return 0;
    }
}

JNIEXPORT void JNICALL Java_com_jarvis_assistant_engine_LlamaBridge_nativeFree(JNIEnv *, jobject, jlong h) {
    Engine *e = E(h);
    if (e == nullptr) return;
    e->cancel.store(true);
    std::lock_guard<std::mutex> lk(e->mtx);  // espera uma geracao em curso terminar
    if (e->ctx) llama_free(e->ctx);
    if (e->model) llama_model_free(e->model);
    e->ctx = nullptr;
    e->model = nullptr;
    delete e;
}

JNIEXPORT void JNICALL Java_com_jarvis_assistant_engine_LlamaBridge_nativeCancel(JNIEnv *, jobject, jlong h) {
    Engine *e = E(h);
    if (e) e->cancel.store(true);
}

JNIEXPORT void JNICALL Java_com_jarvis_assistant_engine_LlamaBridge_nativeSetThreads(JNIEnv *, jobject, jlong h, jint n) {
    Engine *e = E(h);
    if (e && e->ctx) llama_set_n_threads(e->ctx, std::max(1, (int) n), std::max(1, (int) n));
}

JNIEXPORT void JNICALL Java_com_jarvis_assistant_engine_LlamaBridge_nativeSetThrottle(JNIEnv *, jobject, jlong h, jint ms) {
    Engine *e = E(h);
    if (e) e->throttle_ms.store(std::max(0, (int) ms));
}

JNIEXPORT void JNICALL Java_com_jarvis_assistant_engine_LlamaBridge_nativeResetCache(JNIEnv *, jobject, jlong h) {
    Engine *e = E(h);
    if (e == nullptr || e->ctx == nullptr) return;
    std::lock_guard<std::mutex> lk(e->mtx);
    llama_memory_clear(llama_get_memory(e->ctx), true);
    e->cached.clear();
}

JNIEXPORT jint JNICALL Java_com_jarvis_assistant_engine_LlamaBridge_nativeTokenCount(JNIEnv *env, jobject, jlong h, jstring jtext) {
    Engine *e = E(h);
    if (e == nullptr || e->vocab == nullptr) return -1;
    std::string text = jstr(env, jtext);
    int n = llama_tokenize(e->vocab, text.c_str(), (int32_t) text.size(), nullptr, 0, false, true);
    return n < 0 ? -n : n;
}

JNIEXPORT jstring JNICALL Java_com_jarvis_assistant_engine_LlamaBridge_nativeStats(JNIEnv *env, jobject, jlong h) {
    Engine *e = E(h);
    char buf[256];
    if (e == nullptr) {
        snprintf(buf, sizeof(buf), "{}");
    } else {
        double tps = e->gen_ms > 0.0 ? (e->n_gen * 1000.0 / e->gen_ms) : 0.0;
        double pps = e->prefill_ms > 0.0 ? ((e->n_prompt - e->n_reused) * 1000.0 / e->prefill_ms) : 0.0;
        snprintf(buf, sizeof(buf),
                 "{\"n_ctx\":%d,\"n_prompt\":%d,\"n_reused\":%d,\"n_gen\":%d,\"prefill_ms\":%.0f,\"gen_ms\":%.0f,\"tps\":%.2f,\"pps\":%.2f,\"cached\":%d}",
                 e->n_ctx, e->n_prompt, e->n_reused, e->n_gen, e->prefill_ms, e->gen_ms, tps, pps, (int) e->cached.size());
    }
    return env->NewStringUTF(buf);
}

// Retorno: 0=fim natural (EOG), 1=limite de tokens, 2=cancelado, 3=parado pelo chamador (stop sequence),
//          -1=erro (veja nativeLastError), -2=prompt maior que o contexto.
JNIEXPORT jint JNICALL Java_com_jarvis_assistant_engine_LlamaBridge_nativeGenerate(
        JNIEnv *env, jobject, jlong h, jstring jprompt, jint maxTokens, jfloat temperature, jfloat topP, jint topK,
        jfloat minP, jfloat repeatPenalty, jint seed, jstring jgrammar, jint throttleMs, jobject callback) {
    Engine *e = E(h);
    if (e == nullptr || e->ctx == nullptr) {
        g_last_error = "modelo nao carregado";
        return -1;
    }
    std::lock_guard<std::mutex> lk(e->mtx);
    e->cancel.store(false);
    e->throttle_ms.store(std::max(0, (int) throttleMs));
    g_last_error.clear();

    jclass cbClass = env->GetObjectClass(callback);
    jmethodID onPiece = env->GetMethodID(cbClass, "onPiece", "([B)Z");
    if (onPiece == nullptr) {
        g_last_error = "callback invalido";
        return -1;
    }

    llama_sampler *smpl = nullptr;
    int rc = 0;
    try {
        std::string prompt = jstr(env, jprompt);
        std::string grammar = jstr(env, jgrammar);

        std::vector<llama_token> toks;
        if (!tokenize(e->vocab, prompt, toks) || toks.empty()) {
            g_last_error = "falha ao tokenizar o prompt";
            return -1;
        }
        const int n = (int) toks.size();
        if (n > e->n_ctx - 16) {
            g_last_error = "prompt maior que o contexto";
            return -2;
        }
        int budget = std::min((int) maxTokens, e->n_ctx - n - 1);
        if (budget < 1) budget = 1;

        // ---- reaproveitamento do prefixo do KV cache ----
        size_t k = 0;
        const size_t lim = std::min(e->cached.size(), toks.size());
        while (k < lim && e->cached[k] == toks[k]) k++;
        if (k >= toks.size()) k = toks.size() - 1;  // precisa decodificar ao menos 1 token para ter logits
        llama_memory_t mem = llama_get_memory(e->ctx);
        if (k == 0) {
            llama_memory_clear(mem, true);
            e->cached.clear();
        } else if (!llama_memory_seq_rm(mem, 0, (llama_pos) k, -1)) {
            llama_memory_clear(mem, true);
            e->cached.clear();
            k = 0;
        } else {
            e->cached.resize(k);
        }
        e->n_prompt = n;
        e->n_reused = (int) k;

        // ---- prefill ----
        auto t0 = std::chrono::steady_clock::now();
        for (size_t i = k; i < toks.size();) {
            if (e->cancel.load()) return 2;
            int cnt = (int) std::min((size_t) e->n_batch, toks.size() - i);
            llama_batch batch = llama_batch_get_one(toks.data() + i, cnt);
            if (llama_decode(e->ctx, batch) != 0) {
                g_last_error = "llama_decode falhou no prefill";
                llama_memory_clear(mem, true);
                e->cached.clear();
                return -1;
            }
            for (int j = 0; j < cnt; j++) e->cached.push_back(toks[i + j]);
            i += (size_t) cnt;
        }
        auto t1 = std::chrono::steady_clock::now();
        e->prefill_ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        // ---- sampler ----
        llama_sampler_chain_params sp = llama_sampler_chain_default_params();
        sp.no_perf = true;
        smpl = llama_sampler_chain_init(sp);
        if (!grammar.empty()) {
            llama_sampler *g = llama_sampler_init_grammar(e->vocab, grammar.c_str(), "root");
            if (g == nullptr) {
                g_last_error = "gramatica GBNF invalida";
                llama_sampler_free(smpl);
                return -1;
            }
            llama_sampler_chain_add(smpl, g);
        }
        if (repeatPenalty > 1.001f) {
            llama_sampler_chain_add(smpl, llama_sampler_init_penalties(64, repeatPenalty, 0.0f, 0.0f));
        }
        if (temperature <= 0.01f) {
            llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
        } else {
            if (topK > 0) llama_sampler_chain_add(smpl, llama_sampler_init_top_k((int32_t) topK));
            if (topP > 0.0f && topP < 1.0f) llama_sampler_chain_add(smpl, llama_sampler_init_top_p(topP, 1));
            if (minP > 0.0f) llama_sampler_chain_add(smpl, llama_sampler_init_min_p(minP, 1));
            llama_sampler_chain_add(smpl, llama_sampler_init_temp(temperature));
            uint32_t s = seed < 0 ? LLAMA_DEFAULT_SEED : (uint32_t) seed;
            llama_sampler_chain_add(smpl, llama_sampler_init_dist(s));
        }

        // ---- geracao ----
        auto g0 = std::chrono::steady_clock::now();
        int produced = 0;
        rc = 1;
        std::vector<char> big;
        while (produced < budget) {
            if (e->cancel.load()) { rc = 2; break; }
            llama_token tok = llama_sampler_sample(smpl, e->ctx, -1);
            if (llama_vocab_is_eog(e->vocab, tok)) { rc = 0; break; }

            char buf[256];
            int len = llama_token_to_piece(e->vocab, tok, buf, (int32_t) sizeof(buf), 0, false);
            const char *piece = buf;
            if (len < 0) {
                big.assign((size_t) (-len), 0);
                len = llama_token_to_piece(e->vocab, tok, big.data(), (int32_t) big.size(), 0, false);
                piece = big.data();
            }

            llama_batch b = llama_batch_get_one(&tok, 1);
            if (llama_decode(e->ctx, b) != 0) {
                g_last_error = "llama_decode falhou na geracao";
                rc = -1;
                break;
            }
            e->cached.push_back(tok);
            produced++;

            if (len > 0) {
                jbyteArray arr = env->NewByteArray(len);
                env->SetByteArrayRegion(arr, 0, len, reinterpret_cast<const jbyte *>(piece));
                jboolean cont = env->CallBooleanMethod(callback, onPiece, arr);
                env->DeleteLocalRef(arr);
                if (env->ExceptionCheck()) {
                    env->ExceptionClear();
                    rc = 3;
                    break;
                }
                if (cont == JNI_FALSE) { rc = 3; break; }
            }
            int th = e->throttle_ms.load();
            if (th > 0) std::this_thread::sleep_for(std::chrono::milliseconds(th));
        }
        auto g1 = std::chrono::steady_clock::now();
        e->gen_ms = std::chrono::duration<double, std::milli>(g1 - g0).count();
        e->n_gen = produced;
    } catch (const std::exception &ex) {
        g_last_error = std::string("excecao: ") + ex.what();
        rc = -1;
    } catch (...) {
        g_last_error = "excecao desconhecida na geracao";
        rc = -1;
    }
    if (smpl) llama_sampler_free(smpl);
    return rc;
}

}  // extern "C"
