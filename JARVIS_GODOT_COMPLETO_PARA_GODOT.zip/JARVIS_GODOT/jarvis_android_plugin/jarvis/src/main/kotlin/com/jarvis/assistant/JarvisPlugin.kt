package com.jarvis.assistant

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.WindowManager
import com.jarvis.assistant.access.Automation
import com.jarvis.assistant.apps.AppManager
import com.jarvis.assistant.device.DeviceStatus
import com.jarvis.assistant.engine.LlamaBridge
import com.jarvis.assistant.engine.LlmManager
import com.jarvis.assistant.engine.ModelDownloader
import com.jarvis.assistant.engine.ModelImporter
import com.jarvis.assistant.plan.PlanExecutor
import com.jarvis.assistant.safety.SafetyPolicy
import com.jarvis.assistant.util.EventSink
import com.jarvis.assistant.util.JLog
import com.jarvis.assistant.util.TextUtil
import com.jarvis.assistant.voice.SttController
import com.jarvis.assistant.voice.TtsController
import com.jarvis.assistant.voice.VoskEngine
import com.jarvis.assistant.voice.VoskModelManager
import com.jarvis.assistant.voice.WakeWordCore
import com.jarvis.assistant.voice.WakeWordService
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot
import org.json.JSONArray
import org.json.JSONObject

/**
 * Ponte Godot <-> Android. Todos os metodos retornam JSON (String). Eventos assincronos chegam ao Godot
 * pelo sinal unico "jarvis_event(nome: String, json: String)".
 * Nenhum metodo executa comandos arbitrarios: acoes no aparelho so passam por plan_evaluate/plan_execute
 * (SafetyPolicy) e por ferramentas fixas.
 */
class JarvisPlugin(godot: Godot) : GodotPlugin(godot), EventSink {
    companion object {
        const val VERSION = "1.0.0"
        const val API = 2
        const val REQ_PICK_MODEL = 7342
    }

    private val appCtx: Context by lazy { activity!!.applicationContext }
    private val llm: LlmManager by lazy { LlmManager(appCtx, this) }
    private val downloader: ModelDownloader by lazy { ModelDownloader(this) }
    private val importer: ModelImporter by lazy { ModelImporter(appCtx, this, llm.modelsDir) }
    private val tts: TtsController by lazy { TtsController(appCtx, this) }
    private val stt: SttController by lazy { SttController(appCtx, this) }
    private val vosk: VoskEngine by lazy { VoskEngine(appCtx) }
    private val voskModels: VoskModelManager by lazy { VoskModelManager(appCtx, this) }
    private val apps: AppManager by lazy { AppManager(appCtx) }
    private val planner: PlanExecutor by lazy { PlanExecutor(appCtx, apps, this) }

    private var wakeCore: WakeWordCore? = null
    private var wakeMode: String = ""
    private var callbacksRegistered = false

    override fun getPluginName(): String = "JarvisPlugin"

    override fun getPluginSignals(): Set<SignalInfo> {
        val s = mutableSetOf<SignalInfo>()
        s.add(SignalInfo("jarvis_event", String::class.java, String::class.java))
        return s
    }

    // ---------- eventos ----------
    override fun emit(name: String, payload: JSONObject) {
        try {
            // Coordena o microfone: pausa a palavra de ativacao enquanto o Jarvis fala/escuta.
            when (name) {
                "tts_state" -> if (payload.optString("state") == "start") wakeCore?.pause()
                    else if (payload.optInt("pending", 0) == 0) wakeCore?.resume()
                "stt_final", "stt_error" -> wakeCore?.resume()
            }
            emitSignal("jarvis_event", name, payload.toString())
        } catch (t: Throwable) {
            JLog.e("plugin", "falha ao emitir $name", t)
        }
    }

    private fun ok(): String = JSONObject().put("ok", true).toString()
    private fun err(code: String, detail: String = ""): String =
        JSONObject().put("ok", false).put("error", code).put("detail", detail).toString()

    // ---------- ciclo de vida ----------
    override fun onMainResume() {
        if (!callbacksRegistered) {
            callbacksRegistered = true
            try {
                appCtx.registerComponentCallbacks(object : ComponentCallbacks2 {
                    override fun onTrimMemory(level: Int) { llm.onTrimMemory(level) }
                    override fun onConfigurationChanged(newConfig: Configuration) {}
                    @Deprecated("Deprecated in Java")
                    override fun onLowMemory() { llm.onTrimMemory(15) }
                })
            } catch (t: Throwable) { JLog.e("plugin", "registerComponentCallbacks", t) }
        }
        if (WakeWordService.pendingWake) {
            WakeWordService.pendingWake = false
            emit("wake_word", JSONObject().put("source", "service"))
        }
    }

    override fun onMainActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode != REQ_PICK_MODEL) return
        val uri = data?.data
        if (resultCode != android.app.Activity.RESULT_OK || uri == null) {
            emit("model_import", JSONObject().put("id", "pick").put("state", "cancelled").put("name", ""))
            return
        }
        importer.importUri(uri, llm.loadedName)
    }

    override fun onMainPause() {
        stt.cancel()
    }

    override fun onMainDestroy() {
        try { wakeCore?.stop() } catch (_: Throwable) {}
        try { tts.shutdown() } catch (_: Throwable) {}
        try { stt.shutdown() } catch (_: Throwable) {}
    }

    // ---------- basico / diagnostico ----------
    @UsedByGodot
    fun ping(echo: String): String {
        val o = JSONObject().put("ok", true).put("echo", echo).put("plugin_version", VERSION).put("api", API)
            .put("sdk", Build.VERSION.SDK_INT).put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
            .put("native_llm", LlamaBridge.available).put("native_error", LlamaBridge.loadError)
        // prova do caminho Kotlin -> Godot (sinal)
        emit("pong", JSONObject().put("echo", echo).put("t", System.currentTimeMillis()))
        return o.toString()
    }

    @UsedByGodot
    fun get_device_status(): String = DeviceStatus.get(appCtx, llm.modelsDir).toString()

    @UsedByGodot
    fun get_logs(): String = JLog.dump()

    @UsedByGodot
    fun share_text(title: String, text: String): Boolean {
        val act = activity ?: return false
        return try {
            val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text).putExtra(Intent.EXTRA_SUBJECT, title)
            act.startActivity(Intent.createChooser(i, title))
            true
        } catch (_: Throwable) { false }
    }

    @UsedByGodot
    fun minimize_app(): Boolean = try { activity?.moveTaskToBack(true) ?: false } catch (_: Throwable) { false }

    @UsedByGodot
    fun keep_screen_on(on: Boolean): Boolean {
        val act = activity ?: return false
        act.runOnUiThread {
            if (on) act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        return true
    }

    @UsedByGodot
    fun get_media_volume(): Int {
        val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max
    }

    @UsedByGodot
    fun set_media_volume(percent: Int): Int {
        val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (percent.coerceIn(0, 100) * max + 50) / 100, 0)
        return get_media_volume()
    }

    // ---------- permissoes e telas de configuracao ----------
    @UsedByGodot
    fun has_permission(name: String): Boolean {
        val full = if (name.contains(".")) name else "android.permission.$name"
        if (full == "android.permission.POST_NOTIFICATIONS" && Build.VERSION.SDK_INT < 33) return true
        return appCtx.checkSelfPermission(full) == PackageManager.PERMISSION_GRANTED
    }

    @UsedByGodot
    fun request_permissions(namesJson: String): Boolean {
        val act = activity ?: return false
        return try {
            val a = JSONArray(namesJson)
            val need = ArrayList<String>()
            for (i in 0 until a.length()) {
                val n = a.getString(i)
                val full = if (n.contains(".")) n else "android.permission.$n"
                if (full == "android.permission.POST_NOTIFICATIONS" && Build.VERSION.SDK_INT < 33) continue
                if (appCtx.checkSelfPermission(full) != PackageManager.PERMISSION_GRANTED) need.add(full)
            }
            if (need.isNotEmpty()) act.requestPermissions(need.toTypedArray(), 7331)
            true
        } catch (_: Throwable) { false }
    }

    private fun openScreen(i: Intent): Boolean {
        val act = activity ?: return false
        return try { act.startActivity(i); true } catch (_: Throwable) { false }
    }

    @UsedByGodot
    fun open_accessibility_settings(): Boolean = openScreen(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

    @UsedByGodot
    fun open_app_details(): Boolean =
        openScreen(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + appCtx.packageName)))

    @UsedByGodot
    fun open_tts_settings(): Boolean = openScreen(Intent("com.android.settings.TTS_SETTINGS"))

    @UsedByGodot
    fun open_notification_settings(): Boolean {
        val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, appCtx.packageName)
        return openScreen(i)
    }

    // ---------- LLM ----------
    @UsedByGodot
    fun llm_info(): String {
        val o = llm.status()
        o.put("system_info", llm.systemInfo())
        o.put("models_dir", llm.modelsDir.absolutePath)
        o.put("external_models_dir", importer.externalModelsDir()?.absolutePath ?: "")
        return o.toString()
    }

    @UsedByGodot
    fun llm_list_models(): String = JSONObject().put("ok", true).put("models", llm.listModels()).toString()

    /** Abre o seletor de arquivos do Android para escolher o .gguf; o resultado chega pelo evento "model_import". */
    @UsedByGodot
    fun llm_pick_model_file(): String {
        val act = activity ?: return err("no_activity")
        if (importer.isBusy()) return err("busy", "ja existe uma copia em andamento")
        return try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*")
                .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/x-gguf", "*/*"))
            act.startActivityForResult(i, REQ_PICK_MODEL)
            ok()
        } catch (t: Throwable) { err("exception", t.toString()) }
    }

    /** Procura .gguf em Android/data/<pacote>/files/models (pasta externa do app). */
    @UsedByGodot
    fun llm_scan_external(): String {
        val dir = importer.externalModelsDir()
        return JSONObject().put("ok", true).put("dir", dir?.absolutePath ?: "").put("found", importer.scanExternal()).toString()
    }

    @UsedByGodot
    fun llm_import_external(name: String, deleteSource: Boolean): String {
        importer.importExternal(name, deleteSource, llm.loadedName)
        return ok()
    }

    @UsedByGodot
    fun llm_import_cancel(): String { importer.cancel(); return ok() }

    @UsedByGodot
    fun llm_download(json: String): String {
        return try {
            val o = JSONObject(json)
            val file = o.getString("filename")
            val url = o.getString("url")
            if (file.contains("/") || file.contains("..") || !file.endsWith(".gguf")) return err("invalid_filename")
            if (!url.startsWith("https://")) return err("invalid_url", "somente https")
            downloader.start(o.optString("id", file), url, llm.modelsDir, file, o.optLong("expected_bytes", 0L), o.optString("sha256", ""), "GGUF")
            ok()
        } catch (t: Throwable) { err("exception", t.toString()) }
    }

    @UsedByGodot
    fun llm_download_cancel(id: String, deletePartial: Boolean): String {
        downloader.cancel(id, deletePartial)
        if (deletePartial) {
            val f = java.io.File(llm.modelsDir, "$id.part")
            if (f.exists()) f.delete()
        }
        return ok()
    }

    @UsedByGodot
    fun llm_delete_model(filename: String): String = llm.deleteModel(filename).toString()

    @UsedByGodot
    fun llm_load(filename: String, paramsJson: String): String =
        try { llm.load(filename, JSONObject(paramsJson)).toString() } catch (t: Throwable) { err("exception", t.toString()) }

    @UsedByGodot
    fun llm_unload(): String = llm.unload().toString()

    @UsedByGodot
    fun llm_status(): String = llm.status().toString()

    @UsedByGodot
    fun llm_generate(requestJson: String): String =
        try { llm.generate(JSONObject(requestJson)).toString() } catch (t: Throwable) { err("exception", t.toString()) }

    @UsedByGodot
    fun llm_cancel(): String { llm.cancel(); return ok() }

    @UsedByGodot
    fun llm_count_tokens(text: String): Int = llm.countTokens(text)

    @UsedByGodot
    fun llm_set_threads(n: Int): String { llm.changeThreads(n); return ok() }

    @UsedByGodot
    fun llm_set_throttle(ms: Int): String { llm.setThrottle(ms); return ok() }

    @UsedByGodot
    fun llm_reset_cache(): String { llm.resetCache(); return ok() }

    @UsedByGodot
    fun llm_benchmark(): String {
        val max = Runtime.getRuntime().availableProcessors()
        llm.benchmark(listOf(2, 3, 4, 6).filter { it <= max })
        return ok()
    }

    @UsedByGodot
    fun llm_clear_crash_flags(): String { llm.clearCrashFlags(); return ok() }

    // ---------- voz: sintese ----------
    @UsedByGodot
    fun tts_init(): String { tts.init(); return ok() }

    @UsedByGodot
    fun tts_status(): String = tts.status().toString()

    @UsedByGodot
    fun tts_list_voices(): String = JSONObject().put("ok", true).put("voices", tts.listVoices()).toString()

    @UsedByGodot
    fun tts_set_voice(name: String): Boolean = tts.setVoice(name)

    @UsedByGodot
    fun tts_configure(rate: Float, pitch: Float, volume: Float): String {
        tts.configure(rate, pitch, volume)
        return ok()
    }

    @UsedByGodot
    fun tts_speak(text: String, queue: Boolean, id: String): Boolean = tts.speak(text, queue, id)

    @UsedByGodot
    fun tts_stop(): String { tts.stop(); return ok() }

    @UsedByGodot
    fun tts_speaking(): Boolean = tts.isSpeaking()

    // ---------- voz: reconhecimento ----------
    @UsedByGodot
    fun stt_status(): String {
        val o = stt.status()
        o.put("vosk_library", VoskEngine.libraryAvailable())
        o.put("vosk_model", vosk.modelReady())
        return o.toString()
    }

    @UsedByGodot
    fun stt_start(optsJson: String): String {
        return try {
            val o = JSONObject(optsJson)
            wakeCore?.pause()
            if (o.optString("engine", "android") == "vosk") {
                vosk.start(null, 20, object : VoskEngine.Listener {
                    override fun onPartial(text: String) { emit("stt_partial", JSONObject().put("text", text)) }
                    override fun onFinal(text: String) { emit("stt_final", JSONObject().put("text", text).put("confidence", -1.0)) }
                    override fun onError(code: String, message: String) { emit("stt_error", JSONObject().put("code", code).put("message", message)) }
                    override fun onStopped() { emit("stt_state", JSONObject().put("state", "end")) }
                })
                emit("stt_state", JSONObject().put("state", "ready"))
            } else {
                stt.start(o.optBoolean("prefer_offline", true), o.optBoolean("on_device_only", false))
            }
            ok()
        } catch (t: Throwable) { err("exception", t.toString()) }
    }

    @UsedByGodot
    fun stt_stop(): String { stt.stop(); vosk.stop(); return ok() }

    @UsedByGodot
    fun stt_cancel(): String { stt.cancel(); vosk.stop(); wakeCore?.resume(); return ok() }

    @UsedByGodot
    fun vosk_status(): String = voskModels.status().toString()

    @UsedByGodot
    fun vosk_download(): String { voskModels.download(); return ok() }

    @UsedByGodot
    fun vosk_cancel(): String { voskModels.cancel(); return ok() }

    @UsedByGodot
    fun vosk_delete(): String = JSONObject().put("ok", voskModels.delete()).toString()

    // ---------- palavra de ativacao ----------
    private fun stopWake() {
        wakeCore?.stop()
        wakeCore = null
        if (wakeMode == "service") { WakeWordService.listener = null; WakeWordService.stop(appCtx) }
        wakeMode = ""
    }

    @UsedByGodot
    fun wake_set(json: String): String {
        return try {
            val o = JSONObject(json)
            stopWake()
            if (!o.optBoolean("enabled", false)) return ok()
            if (!VoskEngine.libraryAvailable()) return err("vosk_missing", "biblioteca Vosk nao incluida neste build")
            if (!vosk.modelReady()) return err("model_missing", "baixe o modelo de voz offline")
            if (!has_permission("RECORD_AUDIO")) return err("permission", "microfone")
            if (o.optBoolean("background", false)) {
                WakeWordService.listener = { emit("wake_word", JSONObject().put("source", "service")) }
                WakeWordService.start(appCtx)
                wakeMode = "service"
            } else {
                val c = WakeWordCore(appCtx, { emit("wake_word", JSONObject().put("source", "app")) },
                    { code, msg -> emit("wake_status", JSONObject().put("active", false).put("error", code).put("message", msg)) })
                wakeCore = c
                wakeMode = "app"
                c.start()
            }
            emit("wake_status", JSONObject().put("active", true).put("mode", wakeMode))
            ok()
        } catch (t: Throwable) { err("exception", t.toString()) }
    }

    @UsedByGodot
    fun wake_status(): String = JSONObject().put("ok", true).put("mode", wakeMode)
        .put("active", if (wakeMode == "service") WakeWordService.running else (wakeCore?.isActive() ?: false)).toString()

    // ---------- apps, acessibilidade e planos ----------
    @UsedByGodot
    fun apps_list(query: String): String =
        JSONObject().put("ok", true).put("apps", apps.search(query)).toString()

    @UsedByGodot
    fun set_blocked_packages(json: String): String {
        return try {
            val a = JSONArray(json)
            val s = HashSet<String>()
            for (i in 0 until a.length()) {
                val v = a.getString(i).trim()
                if (v.isNotEmpty()) s.add(if (v.contains(".")) v.lowercase() else TextUtil.norm(v))
            }
            SafetyPolicy.extraBlocked = s
            ok()
        } catch (t: Throwable) { err("exception", t.toString()) }
    }

    @UsedByGodot
    fun accessibility_status(): String {
        val connected = Automation.isConnected()
        var enabled = false
        try {
            val v = Settings.Secure.getString(appCtx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            enabled = v.contains(appCtx.packageName + "/", ignoreCase = true)
        } catch (_: Throwable) {}
        return JSONObject().put("ok", true).put("connected", connected).put("enabled_in_settings", enabled)
            .put("foreground", Automation.foregroundPackage() ?: "").put("sdk", Build.VERSION.SDK_INT).toString()
    }

    @UsedByGodot
    fun plan_evaluate(stepsJson: String): String =
        try { planner.evaluate(JSONArray(stepsJson)).toString() } catch (t: Throwable) { err("exception", t.toString()) }

    @UsedByGodot
    fun plan_execute(json: String): String {
        return try {
            val o = JSONObject(json)
            planner.execute(o.optString("plan_id", "plan"), o.getJSONArray("steps"), o.optBoolean("approved", false)).toString()
        } catch (t: Throwable) { err("exception", t.toString()) }
    }

    @UsedByGodot
    fun plan_cancel(): String { planner.cancel(); return ok() }
}
