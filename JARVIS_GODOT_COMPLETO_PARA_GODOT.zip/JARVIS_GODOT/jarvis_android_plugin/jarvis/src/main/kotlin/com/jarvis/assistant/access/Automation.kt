package com.jarvis.assistant.access

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import com.jarvis.assistant.safety.SafetyPolicy
import com.jarvis.assistant.util.TextUtil
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Primitivas de automacao de UI (clicar, digitar, rolar, ler). Nenhuma delas e exposta diretamente ao modelo. */
object Automation {
    class R(val ok: Boolean, val message: String, val data: String = "")

    private fun svc(): JarvisAccessibilityService? = JarvisAccessibilityService.instance
    fun isConnected(): Boolean = svc() != null

    fun foregroundPackage(): String? {
        val s = svc() ?: return null
        return s.rootInActiveWindow?.packageName?.toString() ?: JarvisAccessibilityService.lastPackage.ifEmpty { null }
    }

    private fun walk(root: AccessibilityNodeInfo, limit: Int = 1800, visit: (AccessibilityNodeInfo) -> Unit) {
        val q = ArrayDeque<AccessibilityNodeInfo>()
        q.add(root)
        var n = 0
        while (q.isNotEmpty() && n < limit) {
            val node = q.removeFirst()
            n++
            visit(node)
            for (i in 0 until node.childCount) {
                val c = node.getChild(i)
                if (c != null) q.addLast(c)
            }
        }
    }

    private fun labelOf(n: AccessibilityNodeInfo): String =
        (n.text?.toString() ?: n.contentDescription?.toString() ?: "")

    fun global(action: String): R {
        val s = svc() ?: return R(false, "acessibilidade_desativada")
        val code = when (action) {
            "home" -> AccessibilityService.GLOBAL_ACTION_HOME
            "back" -> AccessibilityService.GLOBAL_ACTION_BACK
            "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
            else -> return R(false, "acao_desconhecida")
        }
        return if (s.performGlobalAction(code)) R(true, "ok") else R(false, "falhou")
    }

    /** Acha o melhor no visivel para o texto; retorna (no, rotulo). */
    fun findBest(target: String): Pair<AccessibilityNodeInfo, String>? {
        val s = svc() ?: return null
        val root = s.rootInActiveWindow ?: return null
        val t = TextUtil.norm(target)
        if (t.isEmpty()) return null
        var best: AccessibilityNodeInfo? = null
        var bestScore = 0
        var bestLabel = ""
        walk(root) { n ->
            if (!n.isVisibleToUser || n.isPassword) return@walk
            val label = labelOf(n)
            if (label.isEmpty()) return@walk
            val ln = TextUtil.norm(label)
            var sc = when {
                ln == t -> 100
                ln.startsWith(t) -> 80
                ln.contains(t) -> 60
                ln.length >= 3 && t.contains(ln) -> 40
                else -> 0
            }
            if (sc > 0 && n.isClickable) sc += 5
            if (sc > bestScore) { bestScore = sc; best = n; bestLabel = label }
        }
        val b = best ?: return null
        return if (bestScore >= 40) Pair(b, bestLabel) else null
    }

    fun clickNode(n: AccessibilityNodeInfo): R {
        var cur: AccessibilityNodeInfo? = n
        var hops = 0
        while (cur != null && hops < 7) {
            if (cur.isClickable && cur.isEnabled && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return R(true, "ok")
            cur = cur.parent
            hops++
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        return if (tap(r.centerX().toFloat(), r.centerY().toFloat())) R(true, "ok_gesto") else R(false, "nao_clicavel")
    }

    private fun gesture(path: Path, durationMs: Long): Boolean {
        val s = svc() ?: return false
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build()
        val latch = CountDownLatch(1)
        var ok = false
        val sent = s.dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(gestureDescription: GestureDescription?) { latch.countDown() }
        }, null)
        if (!sent) return false
        latch.await(2000, TimeUnit.MILLISECONDS)
        return ok
    }

    fun tap(x: Float, y: Float): Boolean = gesture(Path().apply { moveTo(x, y) }, 60)

    fun typeText(text: String, append: Boolean): R {
        val s = svc() ?: return R(false, "acessibilidade_desativada")
        val root = s.rootInActiveWindow ?: return R(false, "sem_janela")
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        var found: AccessibilityNodeInfo? = if (focused != null && focused.isEditable) focused else null
        if (found == null) {
            walk(root) { n -> if (found == null && n.isEditable && n.isVisibleToUser) found = n }
        }
        val t = found ?: return R(false, "sem_campo_de_texto")
        if (t.isPassword) return R(false, "campo_de_senha_bloqueado")
        t.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val a = Bundle()
        val base = if (append) (t.text?.toString() ?: "") else ""
        a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, base + text)
        return if (t.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)) R(true, "ok") else R(false, "falhou_digitar")
    }

    fun scroll(down: Boolean): R {
        val s = svc() ?: return R(false, "acessibilidade_desativada")
        val root = s.rootInActiveWindow ?: return R(false, "sem_janela")
        var sc: AccessibilityNodeInfo? = null
        walk(root) { n -> if (sc == null && n.isScrollable && n.isVisibleToUser) sc = n }
        val node = sc
        if (node != null) {
            val act = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            if (node.performAction(act)) return R(true, "ok")
        }
        val dm = s.resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val p = Path()
        if (down) { p.moveTo(w / 2, h * 0.72f); p.lineTo(w / 2, h * 0.28f) } else { p.moveTo(w / 2, h * 0.28f); p.lineTo(w / 2, h * 0.72f) }
        return if (gesture(p, 320)) R(true, "ok_gesto") else R(false, "falhou_rolar")
    }

    /** Texto visivel (sem campos de senha). Retorna JSON {package, items:[...]}; bloqueado em apps financeiros. */
    fun readScreen(maxChars: Int = 1500): R {
        val s = svc() ?: return R(false, "acessibilidade_desativada")
        val root = s.rootInActiveWindow ?: return R(false, "sem_janela")
        val pkg = root.packageName?.toString() ?: ""
        if (SafetyPolicy.isBlockedPackage(pkg) || pkg in SafetyPolicy.sensitiveSystemPkgs) return R(false, "tela_protegida")
        val items = JSONArray()
        var chars = 0
        val seen = HashSet<String>()
        walk(root) { n ->
            if (chars >= maxChars || !n.isVisibleToUser || n.isPassword) return@walk
            val l = labelOf(n).trim()
            if (l.isNotEmpty() && seen.add(l)) {
                val cut = if (l.length > 120) l.substring(0, 120) else l
                items.put(cut)
                chars += cut.length
            }
        }
        return R(true, "ok", JSONObject().put("package", pkg).put("items", items).toString())
    }
}
