package com.jarvis.assistant.access

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import com.jarvis.assistant.util.JLog

/** Servico de acessibilidade usado SOMENTE para executar passos de planos aprovados (veja PlanExecutor/SafetyPolicy). */
class JarvisAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
        @Volatile var lastPackage: String = ""
        @Volatile var lastEventMs: Long = 0L
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        JLog.i("access", "servico de acessibilidade conectado")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = event.packageName?.toString() ?: return
            lastPackage = p
        }
        lastEventMs = System.currentTimeMillis()
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        JLog.i("access", "servico de acessibilidade desconectado")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
