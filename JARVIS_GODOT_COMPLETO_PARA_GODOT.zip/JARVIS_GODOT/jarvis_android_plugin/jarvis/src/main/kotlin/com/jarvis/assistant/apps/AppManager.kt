package com.jarvis.assistant.apps

import android.content.Context
import android.content.Intent
import com.jarvis.assistant.util.TextUtil
import org.json.JSONArray
import org.json.JSONObject

/** Identifica apps instalados (com icone de launcher) e resolve nomes falados para pacotes. */
class AppManager(private val ctx: Context) {
    data class App(val label: String, val pkg: String, val norm: String)
    data class Scored(val app: App, val score: Int)

    @Volatile private var cache: List<App> = emptyList()
    @Volatile private var cacheTime = 0L

    private val aliases = mapOf(
        "zap" to "whatsapp", "zapzap" to "whatsapp", "whats" to "whatsapp", "wpp" to "whatsapp",
        "insta" to "instagram", "face" to "facebook", "tube" to "youtube", "navegador" to "chrome",
        "config" to "configuracoes", "ajustes" to "configuracoes", "camera" to "camera",
        "mapa" to "maps", "mapas" to "maps", "loja" to "play store", "gmail" to "gmail", "relogio" to "relogio"
    )

    fun all(force: Boolean = false): List<App> {
        val now = System.currentTimeMillis()
        if (!force && cache.isNotEmpty() && now - cacheTime < 60_000) return cache
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val list = try { pm.queryIntentActivities(i, 0) } catch (_: Throwable) { emptyList() }
        val res = list.mapNotNull { ri ->
            try {
                val l = ri.loadLabel(pm).toString()
                App(l, ri.activityInfo.packageName, TextUtil.norm(l))
            } catch (_: Throwable) { null }
        }.distinctBy { it.pkg }.sortedBy { it.norm }
        cache = res
        cacheTime = now
        return res
    }

    private fun score(q: String, a: App): Int {
        val n = a.norm
        if (n.isEmpty()) return 0
        if (n == q || a.pkg == q) return 100
        if (n.startsWith(q)) return 85
        if (n.contains(q)) return 70
        val qt = q.split(" ").filter { it.length > 1 }
        if (qt.isNotEmpty() && qt.all { n.contains(it) }) return 60
        if (q.contains(n) && n.length >= 4) return 55
        val d = TextUtil.lev(q, n)
        if (q.length >= 4 && d <= 2) return 50 - d
        return 0
    }

    fun resolve(query: String): List<Scored> {
        var q = TextUtil.norm(query)
        if (q.isEmpty()) return emptyList()
        aliases[q]?.let { q = it }
        return all().map { Scored(it, score(q, it)) }.filter { it.score >= 45 }.sortedByDescending { it.score }.take(3)
    }

    fun search(query: String, limit: Int = 60): JSONArray {
        val arr = JSONArray()
        val q = TextUtil.norm(query)
        val src = if (q.isEmpty()) all() else all().filter { it.norm.contains(q) }
        for (a in src.take(limit)) arr.put(JSONObject().put("label", a.label).put("package", a.pkg))
        return arr
    }

    fun launchIntent(pkg: String): Intent? {
        val it = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return null
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return it
    }
}
