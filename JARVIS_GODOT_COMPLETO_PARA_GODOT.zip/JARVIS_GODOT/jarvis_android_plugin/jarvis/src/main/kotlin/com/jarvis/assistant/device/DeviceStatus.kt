package com.jarvis.assistant.device

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Debug
import android.os.PowerManager
import android.os.StatFs
import org.json.JSONObject
import java.io.File

/** Leitura de RAM, temperatura/termica, bateria, armazenamento e rede (para controle de recursos). */
object DeviceStatus {
    fun isOnline(ctx: Context): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork ?: return false
            val c = cm.getNetworkCapabilities(n) ?: return false
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (_: Throwable) { false }
    }

    fun get(ctx: Context, dir: File): JSONObject {
        val o = JSONObject()
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            o.put("ram_total_mb", mi.totalMem / 1048576)
            o.put("ram_avail_mb", mi.availMem / 1048576)
            o.put("low_memory", mi.lowMemory)
            o.put("app_pss_mb", Debug.getPss() / 1024)
        } catch (_: Throwable) {}
        try {
            var thermal = -1
            if (Build.VERSION.SDK_INT >= 29) {
                thermal = (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus
            }
            o.put("thermal", thermal)  // 0 nenhum,1 leve,2 moderado,3 severo,4 critico,5 emergencia,6 desligando
        } catch (_: Throwable) { o.put("thermal", -1) }
        try {
            val b: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (b != null) {
                val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                o.put("battery_pct", if (lvl >= 0) lvl * 100 / scale else -1)
                o.put("battery_temp_c", b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0)
                val plugged = b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
                o.put("charging", plugged != 0)
            }
        } catch (_: Throwable) {}
        try {
            o.put("storage_free_mb", StatFs(dir.absolutePath).availableBytes / 1048576)
        } catch (_: Throwable) {}
        o.put("online", isOnline(ctx))
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            o.put("metered", cm.isActiveNetworkMetered)
        } catch (_: Throwable) {}
        o.put("cores", Runtime.getRuntime().availableProcessors())
        o.put("sdk", Build.VERSION.SDK_INT)
        o.put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
        return o
    }
}
