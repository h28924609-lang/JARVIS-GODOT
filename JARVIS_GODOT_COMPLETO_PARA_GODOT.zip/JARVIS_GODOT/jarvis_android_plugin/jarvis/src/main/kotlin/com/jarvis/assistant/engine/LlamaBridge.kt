package com.jarvis.assistant.engine

/** Declaracoes JNI do motor nativo (libjarvis_llama.so, construida a partir do llama.cpp). */
object LlamaBridge {
    @Volatile var available: Boolean = false
    @Volatile var loadError: String = ""

    init {
        try {
            System.loadLibrary("jarvis_llama")
            available = true
        } catch (t: Throwable) {
            available = false
            loadError = t.toString()
        }
    }

    interface PieceCallback {
        /** Recebe bytes UTF-8 crus de um token. Retorne false para parar a geracao. */
        fun onPiece(bytes: ByteArray): Boolean
    }

    external fun nativeBackendInit()
    external fun nativeLastError(): String
    external fun nativeSystemInfo(): String
    external fun nativeLoad(path: String, nCtx: Int, nThreads: Int, nBatch: Int, useMmap: Boolean): Long
    external fun nativeFree(handle: Long)
    external fun nativeCancel(handle: Long)
    external fun nativeSetThreads(handle: Long, n: Int)
    external fun nativeSetThrottle(handle: Long, ms: Int)
    external fun nativeResetCache(handle: Long)
    external fun nativeTokenCount(handle: Long, text: String): Int
    external fun nativeStats(handle: Long): String
    external fun nativeGenerate(
        handle: Long, prompt: String, maxTokens: Int, temperature: Float, topP: Float, topK: Int,
        minP: Float, repeatPenalty: Float, seed: Int, grammar: String, throttleMs: Int, cb: PieceCallback
    ): Int
}
