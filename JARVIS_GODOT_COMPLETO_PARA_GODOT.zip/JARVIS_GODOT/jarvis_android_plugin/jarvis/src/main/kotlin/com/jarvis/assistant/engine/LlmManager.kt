package com.jarvis.assistant.engine

import android.app.ActivityManager
import android.content.Context
import android.os.SystemClock
import com.jarvis.assistant.util.EventSink
import com.jarvis.assistant.util.JLog
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/** Quebra bytes UTF-8 em texto sem cortar caracteres multibyte no meio. */
class Utf8Chunker {
    private var buf = ByteArray(0)

    fun push(b: ByteArray): String {
        buf += b
        var end = buf.size
        var i = end - 1
        var back = 0
        while (i >= 0 && back < 4 && (buf[i].toInt() and 0xC0) == 0x80) { i--; back++ }
        if (i >= 0) {
            val lead = buf[i].toInt() and 0xFF
            val need = when {
                lead >= 0xF0 -> 4
                lead >= 0xE0 -> 3
                lead >= 0xC0 -> 2
                else -> 1
            }
            if (need > 1 && (end - i) < need) end = i
        }
        val s = String(buf, 0, end, Charsets.UTF_8)
        buf = buf.copyOfRange(end, buf.size)
        return s
    }

    fun flush(): String {
        val s = String(buf, Charsets.UTF_8)
        buf = ByteArray(0)
        return s
    }
}

/** Gerencia o modelo local: carregar/descarregar, gerar texto em streaming, cancelar, medir desempenho. */
class LlmManager(private val ctx: Context, private val sink: EventSink) {
    val modelsDir: File = File(ctx.filesDir, "models").apply { mkdirs() }
    private val flagLoad = File(ctx.filesDir, "llm_loading.flag")
    private val flagGen = File(ctx.filesDir, "llm_generating.flag")
    private val exec = Executors.newSingleThreadExecutor { r -> Thread(r, "jarvis-llm") }

    /** "load" ou "generate" se o processo morreu no meio dessas operacoes na execucao anterior. */
    val uncleanExit: String = when {
        flagLoad.exists() -> "load"
        flagGen.exists() -> "generate"
        else -> ""
    }

    @Volatile private var handle: Long = 0L
    @Volatile var loadedName: String = ""
    @Volatile var nCtx: Int = 0
    @Volatile var threads: Int = 4
    @Volatile var generating: Boolean = false
    @Volatile var loading: Boolean = false
    @Volatile var lastError: String = ""
    @Volatile var throttleMs: Int = 0
    @Volatile private var lastStats: String = "{}"

    init {
        flagLoad.delete()
        flagGen.delete()
    }

    private fun err(code: String, detail: String = ""): JSONObject =
        JSONObject().put("ok", false).put("error", code).put("detail", detail)

    fun clearCrashFlags() { flagLoad.delete(); flagGen.delete() }

    fun listModels(): JSONArray {
        val arr = JSONArray()
        val files = modelsDir.listFiles() ?: emptyArray()
        for (f in files.sortedBy { it.name }) {
            if (f.name.endsWith(".gguf", ignoreCase = true)) {
                arr.put(JSONObject().put("name", f.name).put("size", f.length()).put("partial", false)
                    .put("loaded", f.name == loadedName))
            } else if (f.name.endsWith(".part", ignoreCase = true)) {
                arr.put(JSONObject().put("name", f.name.removeSuffix(".part")).put("size", f.length()).put("partial", true)
                    .put("loaded", false))
            }
        }
        return arr
    }

    fun deleteModel(name: String): JSONObject {
        if (name.contains("/") || name.contains("\\") || name.contains("..") || name.isBlank()) return err("invalid_name")
        val a = File(modelsDir, name)
        val b = File(modelsDir, "$name.part")
        if (name == loadedName || loading || generating) {
            cancel()
            exec.execute {
                if (name == loadedName) unloadInternal()
                val ok1 = if (a.exists()) a.delete() else true
                val ok2 = if (b.exists()) b.delete() else true
                emit("model_delete", JSONObject().put("name", name).put("ok", ok1 && ok2))
            }
            return JSONObject().put("ok", true).put("started", true)
        }
        val ok1 = if (a.exists()) a.delete() else true
        val ok2 = if (b.exists()) b.delete() else true
        return JSONObject().put("ok", ok1 && ok2)
    }

    fun status(): JSONObject {
        val o = JSONObject()
        o.put("ok", true)
        o.put("native_available", LlamaBridge.available)
        o.put("native_error", LlamaBridge.loadError)
        o.put("loaded", handle != 0L)
        o.put("loading", loading)
        o.put("generating", generating)
        o.put("model", loadedName)
        o.put("n_ctx", nCtx)
        o.put("threads", threads)
        o.put("last_error", lastError)
        o.put("unclean_exit", uncleanExit)
        try { o.put("stats", JSONObject(lastStats)) } catch (e: Exception) { o.put("stats", JSONObject()) }
        return o
    }

    fun systemInfo(): String = if (LlamaBridge.available) LlamaBridge.nativeSystemInfo() else ""

    fun load(name: String, params: JSONObject): JSONObject {
        if (!LlamaBridge.available) return err("native_missing", LlamaBridge.loadError)
        if (name.contains("/") || name.contains("..")) return err("invalid_name")
        if (!name.endsWith(".gguf", ignoreCase = true)) return err("invalid_format", "selecione um arquivo .gguf")
        val f = File(modelsDir, name)
        if (!f.isFile || !f.exists()) return err("file_missing")
        if (f.length() < 1024L) return err("file_too_small", "arquivo GGUF vazio ou truncado")
        try {
            f.inputStream().use { input ->
                val magic = ByteArray(4)
                var offset = 0
                while (offset < magic.size) {
                    val n = input.read(magic, offset, magic.size - offset)
                    if (n < 0) break
                    if (n > 0) offset += n
                }
                if (offset != 4 || !magic.contentEquals(byteArrayOf(0x47, 0x47, 0x55, 0x46)))
                    return err("invalid_gguf", "cabecalho GGUF invalido")
            }
        } catch (t: Throwable) { return err("read_failed", t.toString()) }
        if (loading) return err("busy")
        loading = true
        if (generating) cancel()
        exec.execute {
            try {
                unloadInternal()
                val nCtxP = params.optInt("n_ctx", 3072)
                val thr = params.optInt("threads", 4)
                val batch = params.optInt("n_batch", 256)
                val mmap = params.optBoolean("mmap", true)
                val mi = ActivityManager.MemoryInfo()
                (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
                val availMb = mi.availMem / (1024 * 1024)
                emit("llm_load", JSONObject().put("state", "loading").put("model", name).put("avail_mb", availMb))
                flagLoad.createNewFile()
                val t0 = SystemClock.elapsedRealtime()
                val h = LlamaBridge.nativeLoad(f.absolutePath, nCtxP, thr, batch, mmap)
                flagLoad.delete()
                val ms = SystemClock.elapsedRealtime() - t0
                if (h == 0L) {
                    lastError = LlamaBridge.nativeLastError()
                    JLog.e("llm", "falha ao carregar: $lastError")
                    emit("llm_load", JSONObject().put("state", "error").put("model", name).put("error", lastError))
                } else {
                    handle = h
                    loadedName = name
                    nCtx = nCtxP
                    threads = thr
                    lastError = ""
                    JLog.i("llm", "modelo $name carregado em ${ms}ms")
                    emit("llm_load", JSONObject().put("state", "ready").put("model", name).put("ms", ms)
                        .put("n_ctx", nCtxP).put("threads", thr))
                }
            } catch (t: Throwable) {
                flagLoad.delete()
                lastError = t.toString()
                JLog.e("llm", "excecao ao carregar", t)
                emit("llm_load", JSONObject().put("state", "error").put("model", name).put("error", lastError))
            } finally {
                loading = false
            }
        }
        return JSONObject().put("ok", true).put("started", true)
    }

    private fun unloadInternal() {
        val h = handle
        if (h != 0L) {
            handle = 0L
            loadedName = ""
            try { LlamaBridge.nativeFree(h) } catch (t: Throwable) { JLog.e("llm", "erro ao liberar", t) }
            emit("llm_load", JSONObject().put("state", "unloaded"))
        }
    }

    fun unload(): JSONObject {
        cancel()
        exec.execute { unloadInternal() }
        return JSONObject().put("ok", true)
    }

    fun cancel() {
        val h = handle
        if (h != 0L) try { LlamaBridge.nativeCancel(h) } catch (_: Throwable) {}
    }

    fun changeThreads(n: Int) {
        threads = n.coerceIn(1, 8)
        val h = handle
        if (h != 0L) LlamaBridge.nativeSetThreads(h, threads)
    }

    fun setThrottle(ms: Int) {
        throttleMs = ms.coerceIn(0, 2000)
        val h = handle
        if (h != 0L) LlamaBridge.nativeSetThrottle(h, throttleMs)
    }

    fun resetCache() {
        val h = handle
        if (h != 0L) exec.execute { try { LlamaBridge.nativeResetCache(h) } catch (_: Throwable) {} }
    }

    fun countTokens(text: String): Int {
        val h = handle
        return if (h == 0L) -1 else try { LlamaBridge.nativeTokenCount(h, text) } catch (_: Throwable) { -1 }
    }

    fun onTrimMemory(level: Int) {
        // 15 = TRIM_MEMORY_RUNNING_CRITICAL, 60+ = app em cache sendo reclamado
        if (level >= 15 && handle != 0L) {
            val wasGenerating = generating
            if (wasGenerating) cancel()
            exec.execute { unloadInternal() }
            emit("memory_trim", JSONObject().put("level", level).put("unloaded", true).put("was_generating", wasGenerating))
        }
    }

    fun generate(req: JSONObject): JSONObject {
        val h = handle
        if (h == 0L) return err("not_loaded")
        val id = req.optString("id", "req")
        generating = true
        exec.execute { runGenerate(h, id, req) }
        return JSONObject().put("ok", true).put("id", id)
    }

    private fun runGenerate(h: Long, id: String, req: JSONObject) {
        val stops = ArrayList<String>()
        req.optJSONArray("stop")?.let { a -> for (i in 0 until a.length()) { val s = a.optString(i); if (s.isNotEmpty()) stops.add(s) } }
        val maxStop = stops.maxOfOrNull { it.length } ?: 0
        val chunker = Utf8Chunker()
        val full = StringBuilder()
        val out = StringBuilder()
        var emitted = 0
        var stopHit = false
        var lastFlush = SystemClock.elapsedRealtime()
        var rc = -1
        try {
            flagGen.createNewFile()
            fun flushOut(force: Boolean) {
                if (out.isEmpty()) return
                val now = SystemClock.elapsedRealtime()
                if (force || now - lastFlush >= 60) {
                    emit("llm_token", JSONObject().put("id", id).put("text", out.toString()))
                    out.setLength(0)
                    lastFlush = now
                }
            }
            val cb = object : LlamaBridge.PieceCallback {
                override fun onPiece(bytes: ByteArray): Boolean {
                    val s = chunker.push(bytes)
                    if (s.isEmpty()) return true
                    full.append(s)
                    var idx = -1
                    for (st in stops) {
                        val i = full.indexOf(st, maxOf(0, emitted - st.length))
                        if (i >= 0 && (idx < 0 || i < idx)) idx = i
                    }
                    if (idx >= 0) {
                        if (idx > emitted) out.append(full.substring(emitted, idx))
                        emitted = idx
                        stopHit = true
                        flushOut(true)
                        return false
                    }
                    val safeEnd = full.length - (if (maxStop > 1) maxStop - 1 else 0)
                    if (safeEnd > emitted) {
                        out.append(full.substring(emitted, safeEnd))
                        emitted = safeEnd
                    }
                    flushOut(false)
                    return true
                }
            }
            rc = LlamaBridge.nativeGenerate(
                h, req.getString("prompt"), req.optInt("max_tokens", 384),
                req.optDouble("temperature", 0.7).toFloat(), req.optDouble("top_p", 0.9).toFloat(),
                req.optInt("top_k", 40), req.optDouble("min_p", 0.05).toFloat(),
                req.optDouble("repeat_penalty", 1.1).toFloat(), req.optInt("seed", -1),
                req.optString("grammar", ""), req.optInt("throttle_ms", throttleMs), cb
            )
            if (!stopHit) {
                full.append(chunker.flush())
                if (full.length > emitted) { out.append(full.substring(emitted)); emitted = full.length }
            }
            flushOut(true)
        } catch (t: Throwable) {
            JLog.e("llm", "excecao na geracao", t)
            lastError = t.toString()
            rc = -1
        } finally {
            flagGen.delete()
            generating = false
        }
        val reason = when (rc) {
            0 -> "eos"
            1 -> "length"
            2 -> "cancelled"
            3 -> if (stopHit) "stop" else "stopped"
            -2 -> "prompt_too_long"
            else -> "error"
        }
        if (rc == -1) lastError = LlamaBridge.nativeLastError().ifEmpty { lastError }
        try { lastStats = LlamaBridge.nativeStats(h) } catch (_: Throwable) {}
        val done = JSONObject().put("id", id).put("reason", reason).put("text", full.substring(0, emitted))
        if (reason == "error") done.put("error", lastError)
        try { done.put("stats", JSONObject(lastStats)) } catch (_: Exception) {}
        emit("llm_done", done)
    }

    /** Mede tokens/s com varias contagens de threads e escolhe a melhor. */
    fun benchmark(candidates: List<Int>) {
        val h = handle
        if (h == 0L) { emit("llm_bench", JSONObject().put("ok", false).put("error", "not_loaded")); return }
        generating = true
        exec.execute {
            val results = JSONArray()
            var best = threads
            var bestTps = 0.0
            try {
                for (n in candidates) {
                    LlamaBridge.nativeSetThreads(h, n)
                    LlamaBridge.nativeResetCache(h)
                    val cb = object : LlamaBridge.PieceCallback { override fun onPiece(bytes: ByteArray): Boolean = true }
                    LlamaBridge.nativeGenerate(h, "Conte de um ate vinte em portugues: um, dois, tres,", 24, 0f, 1f, 0, 0f, 1f, 1, "", 0, cb)
                    val st = JSONObject(LlamaBridge.nativeStats(h))
                    val tps = st.optDouble("tps", 0.0)
                    results.put(JSONObject().put("threads", n).put("tps", tps))
                    if (tps > bestTps) { bestTps = tps; best = n }
                }
                threads = best
                LlamaBridge.nativeSetThreads(h, best)
                LlamaBridge.nativeResetCache(h)
                emit("llm_bench", JSONObject().put("ok", true).put("results", results).put("best", best).put("tps", bestTps))
            } catch (t: Throwable) {
                emit("llm_bench", JSONObject().put("ok", false).put("error", t.toString()))
            } finally {
                generating = false
            }
        }
    }

    private fun emit(name: String, o: JSONObject) = sink.emit(name, o)
}
