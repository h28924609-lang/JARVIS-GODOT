package com.jarvis.assistant.engine

import android.os.StatFs
import android.os.SystemClock
import com.jarvis.assistant.util.EventSink
import com.jarvis.assistant.util.JLog
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Download com retomada (HTTP Range), verificacao de espaco livre, progresso e checagem de integridade.
 * Emite o evento "download" com: id, state (starting|downloading|verifying|done|error|cancelled), downloaded, total, speed_bps.
 */
class ModelDownloader(private val sink: EventSink, private val eventName: String = "download") {
    private class Job(val id: String) {
        @Volatile var cancel = false
        @Volatile var deletePart = false
    }

    private val jobs = ConcurrentHashMap<String, Job>()

    fun isRunning(id: String): Boolean = jobs.containsKey(id)

    fun cancel(id: String, deletePart: Boolean) {
        jobs[id]?.let { it.cancel = true; it.deletePart = deletePart }
    }

    /** magic: bytes esperados no inicio do arquivo (ex.: "GGUF", "PK"); vazio = nao verifica. */
    fun start(id: String, url: String, dir: File, filename: String, expectedBytes: Long, sha256: String, magic: String) {
        if (jobs.containsKey(id)) return
        val job = Job(id)
        jobs[id] = job
        Thread({ run(job, url, dir, filename, expectedBytes, sha256, magic) }, "jarvis-dl-$id").start()
    }

    private fun emit(id: String, state: String, downloaded: Long, total: Long, speed: Long, error: String = "", extra: String = "") {
        val o = JSONObject().put("id", id).put("state", state).put("downloaded", downloaded).put("total", total)
            .put("speed_bps", speed)
        if (error.isNotEmpty()) o.put("error", error)
        if (extra.isNotEmpty()) o.put("detail", extra)
        sink.emit(eventName, o)
    }

    private fun run(job: Job, url: String, dir: File, filename: String, expectedBytes: Long, sha256: String, magic: String) {
        val id = job.id
        var conn: HttpURLConnection? = null
        try {
            dir.mkdirs()
            val part = File(dir, "$filename.part")
            val dest = File(dir, filename)
            var existing = if (part.exists()) part.length() else 0L
            emit(id, "starting", existing, expectedBytes, 0)

            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20000
                readTimeout = 30000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "JarvisAssistant/1.0 (Android)")
                if (existing > 0) setRequestProperty("Range", "bytes=$existing-")
            }
            val code = conn.responseCode
            if (code == 416 && existing > 0) {
                // ja temos tudo (ou o servidor nao aceita o intervalo): tenta finalizar
                conn.disconnect()
                finish(job, part, dest, existing, expectedBytes, sha256, magic)
                return
            }
            if (code != 200 && code != 206) {
                emit(id, "error", existing, expectedBytes, 0, "http_$code")
                return
            }
            if (code == 200 && existing > 0) { // servidor ignorou Range: recomeca
                part.delete()
                existing = 0
            }
            val len = conn.contentLengthLong
            val total = if (len > 0) len + existing else expectedBytes

            val stat = StatFs(dir.absolutePath)
            val free = stat.availableBytes
            val need = (if (total > 0) total - existing else 0L) + 64L * 1024 * 1024
            if (total > 0 && free < need) {
                emit(id, "error", existing, total, 0, "no_space", "livre=${free / 1048576}MB necessario=${need / 1048576}MB")
                return
            }

            var downloaded = existing
            var lastEmit = 0L
            var lastBytes = existing
            var lastT = SystemClock.elapsedRealtime()
            var speed = 0L
            conn.inputStream.use { input ->
                FileOutputStream(part, existing > 0).use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        if (job.cancel) break
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        downloaded += n
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastEmit >= 400) {
                            val dt = now - lastT
                            if (dt > 0) speed = (downloaded - lastBytes) * 1000 / dt
                            lastT = now; lastBytes = downloaded; lastEmit = now
                            emit(id, "downloading", downloaded, total, speed)
                        }
                    }
                    out.flush()
                }
            }
            if (job.cancel) {
                if (job.deletePart) part.delete()
                emit(id, "cancelled", downloaded, total, 0)
                return
            }
            finish(job, part, dest, downloaded, total, sha256, magic)
        } catch (t: Throwable) {
            JLog.e("download", "erro em $id", t)
            val part = File(dir, "$filename.part")
            emit(id, "error", if (part.exists()) part.length() else 0L, expectedBytes, 0, "io_error", t.toString())
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
            jobs.remove(id)
        }
    }

    private fun finish(job: Job, part: File, dest: File, downloaded: Long, total: Long, sha256: String, magic: String) {
        val id = job.id
        if (total > 0 && part.length() != total) {
            emit(id, "error", part.length(), total, 0, "incomplete", "baixado=${part.length()} esperado=$total")
            return
        }
        emit(id, "verifying", downloaded, total, 0)
        if (magic.isNotEmpty()) {
            val head = ByteArray(magic.length)
            RandomAccessFile(part, "r").use { it.readFully(head) }
            if (String(head, Charsets.ISO_8859_1) != magic) {
                part.delete()
                emit(id, "error", 0, total, 0, "corrupt", "arquivo nao e do tipo esperado ($magic)")
                return
            }
        }
        if (sha256.isNotEmpty()) {
            val md = MessageDigest.getInstance("SHA-256")
            part.inputStream().use { ins ->
                val b = ByteArray(256 * 1024)
                while (true) { val n = ins.read(b); if (n < 0) break; md.update(b, 0, n) }
            }
            val hex = md.digest().joinToString("") { "%02x".format(it) }
            if (!hex.equals(sha256, ignoreCase = true)) {
                part.delete()
                emit(id, "error", 0, total, 0, "checksum", "sha256 diferente do esperado")
                return
            }
        }
        if (dest.exists()) dest.delete()
        if (!part.renameTo(dest)) {
            emit(id, "error", part.length(), total, 0, "rename_failed")
            return
        }
        emit(id, "done", dest.length(), dest.length(), 0)
    }
}
