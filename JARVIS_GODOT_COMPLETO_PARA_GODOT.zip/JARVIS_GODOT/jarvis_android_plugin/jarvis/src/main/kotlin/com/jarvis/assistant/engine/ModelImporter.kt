package com.jarvis.assistant.engine

import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.os.SystemClock
import android.provider.OpenableColumns
import com.jarvis.assistant.util.EventSink
import com.jarvis.assistant.util.JLog
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream

/**
 * Traz um arquivo .gguf para o armazenamento PRIVADO do app (filesDir/models), de onde o llama.cpp o carrega.
 *
 * Duas origens:
 *  - Seletor de arquivos do Android (Storage Access Framework): o app recebe um Uri e copia o conteudo (sem precisar
 *     de permissao de armazenamento).
 *  - Pasta externa do proprio app: Android/data/<pacote>/files/models (acessivel por USB/adb/gerenciador de arquivos).
 *
 * Emite o evento "model_import": id, state (copying|done|error|cancelled), name, copied, total, speed_bps, error, detail.
 * Valida o cabecalho "GGUF" e o espaco livre. Nunca marca como pronto um arquivo incompleto (copia para .part e renomeia).
 */
class ModelImporter(private val ctx: Context, private val sink: EventSink, private val modelsDir: File) {
    companion object {
        const val EVENT = "model_import"
        private val MAGIC = byteArrayOf('G'.code.toByte(), 'G'.code.toByte(), 'U'.code.toByte(), 'F'.code.toByte())
        private const val MIN_FREE_MARGIN = 200L * 1024 * 1024
    }

    @Volatile private var busy = false
    @Volatile private var cancelFlag = false

    fun isBusy(): Boolean = busy
    fun cancel() { cancelFlag = true }

    /** Pasta onde o usuario pode colocar o GGUF manualmente (criada se necessario). */
    fun externalModelsDir(): File? = try {
        ctx.getExternalFilesDir(null)?.let { File(it, "models").apply { mkdirs() } }
    } catch (t: Throwable) { JLog.w("import", "pasta externa indisponivel: $t"); null }

    /** Lista .gguf encontrados nas pastas externas do app. */
    fun scanExternal(): JSONArray {
        val arr = JSONArray()
        val seen = HashSet<String>()
        val roots = ArrayList<File>()
        externalModelsDir()?.let { roots.add(it); it.parentFile?.let { p -> roots.add(p) } }
        for (r in roots) {
            val files = r.listFiles() ?: continue
            for (f in files.sortedBy { it.name }) {
                if (f.isFile && f.name.endsWith(".gguf", ignoreCase = true) && seen.add(f.absolutePath)) {
                    arr.put(JSONObject().put("name", f.name).put("size", f.length()).put("path", f.absolutePath))
                }
            }
        }
        return arr
    }

    private fun emit(id: String, state: String, name: String, copied: Long, total: Long, speed: Long, error: String = "", detail: String = "") {
        val o = JSONObject().put("id", id).put("state", state).put("name", name)
            .put("copied", copied).put("total", total).put("speed_bps", speed)
        if (error.isNotEmpty()) o.put("error", error)
        if (detail.isNotEmpty()) o.put("detail", detail)
        sink.emit(EVENT, o)
    }

    /** Nome seguro para arquivo local; sempre termina em .gguf. */
    fun safeName(raw: String): String {
        var n = raw.substringAfterLast('/').substringAfterLast('\\').trim()
        n = n.replace(Regex("[^A-Za-z0-9._-]"), "_").trimStart('.')
        if (n.length > 120) n = n.takeLast(120)
        if (n.isEmpty()) n = "modelo"
        if (!n.endsWith(".gguf", ignoreCase = true)) n += ".gguf"
        return n
    }

    fun importUri(uri: Uri, loadedName: String) {
        if (busy) { emit("pick", "error", "", 0, 0, 0, "busy", "ja existe uma copia em andamento"); return }
        var display = "modelo.gguf"
        var size = -1L
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0 && !c.isNull(ni)) display = c.getString(ni)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (t: Throwable) { JLog.w("import", "consulta do Uri falhou: $t") }
        val name = safeName(display)
        val stream = try { ctx.contentResolver.openInputStream(uri) } catch (t: Throwable) { null }
        if (stream == null) { emit("pick", "error", name, 0, 0, 0, "open_failed", "nao foi possivel abrir o arquivo escolhido"); return }
        start("pick", name, size, stream, null, false, loadedName)
    }

    fun importExternal(fileName: String, deleteSource: Boolean, loadedName: String) {
        if (fileName.contains("/") || fileName.contains("..")) { emit("ext", "error", fileName, 0, 0, 0, "invalid_name"); return }
        val src = (0 until scanExternal().length()).map { scanExternal().getJSONObject(it) }
            .firstOrNull { it.getString("name") == fileName }?.getString("path")?.let { File(it) }
        if (src == null || !src.exists()) { emit("ext", "error", fileName, 0, 0, 0, "file_missing"); return }
        val stream = try { FileInputStream(src) } catch (t: Throwable) { null }
        if (stream == null) { emit("ext", "error", fileName, 0, 0, 0, "open_failed"); return }
        start("ext", safeName(fileName), src.length(), stream, if (deleteSource) src else null, deleteSource, loadedName)
    }

    private fun start(id: String, name: String, total: Long, input: InputStream, sourceToDelete: File?, deleteSource: Boolean, loadedName: String) {
        if (name == loadedName) {
            try { input.close() } catch (_: Throwable) {}
            emit(id, "error", name, 0, total, 0, "in_use", "descarregue o modelo antes de substituir o arquivo")
            return
        }
        busy = true
        cancelFlag = false
        Thread({
            try { run(id, name, total, input, sourceToDelete) }
            finally { busy = false }
        }, "jarvis-import").start()
    }

    private fun run(id: String, name: String, total: Long, input: InputStream, sourceToDelete: File?) {
        val part = File(modelsDir, "$name.part")
        val dest = File(modelsDir, name)
        val backup = File(modelsDir, "$name.replace-backup")
        var copied = 0L
        try {
            modelsDir.mkdirs()
            val free = try { StatFs(modelsDir.absolutePath).availableBytes } catch (_: Throwable) { Long.MAX_VALUE }
            val existing = if (dest.exists()) dest.length() else 0L
            if (total > 0 && free + existing < total + MIN_FREE_MARGIN) {
                try { input.close() } catch (_: Throwable) {}
                emit(id, "error", name, 0, total, 0, "no_space", "livre ${(free + existing) / 1048576} MB, necessario ${(total + MIN_FREE_MARGIN) / 1048576} MB")
                return
            }
            emit(id, "copying", name, 0, total, 0)
            val t0 = SystemClock.elapsedRealtime()
            var lastEmit = t0
            val buf = ByteArray(1 shl 20)
            input.use { ins ->
                // ContentResolver/InputStream nao garante que uma unica leitura devolva os 4 bytes do magic.
                // Leia o cabecalho em loop para nao rejeitar GGUF valido em provedores que fragmentam leituras.
                val header = ByteArray(4)
                var headerRead = 0
                while (headerRead < header.size) {
                    if (cancelFlag) {
                        part.delete()
                        emit(id, "cancelled", name, copied, total, 0)
                        return
                    }
                    val n = ins.read(header, headerRead, header.size - headerRead)
                    if (n < 0) break
                    if (n == 0) continue
                    headerRead += n
                }
                if (headerRead != 4 || !header.contentEquals(MAGIC)) {
                    part.delete()
                    emit(id, "error", name, 0, total, 0, "not_gguf", "o arquivo nao possui cabecalho GGUF valido")
                    return
                }
                FileOutputStream(part).use { out ->
                    out.write(header)
                    copied = 4
                    var lastSpaceCheck = copied
                    while (true) {
                        if (cancelFlag) {
                            part.delete()
                            emit(id, "cancelled", name, copied, total, 0)
                            return
                        }
                        val n = ins.read(buf)
                        if (n < 0) break
                        if (n == 0) continue
                        out.write(buf, 0, n)
                        copied += n
                        // Verificacao periodica evita consumir todo o armazenamento se o tamanho do Uri for desconhecido.
                        if (copied - lastSpaceCheck >= 64L * 1024 * 1024) {
                            lastSpaceCheck = copied
                            val left = try { StatFs(modelsDir.absolutePath).availableBytes } catch (_: Throwable) { Long.MAX_VALUE }
                            if (left < MIN_FREE_MARGIN) throw IllegalStateException("espaco livre abaixo da margem de seguranca")
                        }
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastEmit >= 250) {
                            lastEmit = now
                            val dt = (now - t0).coerceAtLeast(1)
                            emit(id, "copying", name, copied, total, copied * 1000 / dt)
                        }
                    }
                    out.fd.sync()
                }
            }
            if (copied < 1024) {
                part.delete()
                emit(id, "error", name, copied, total, 0, "empty", "arquivo GGUF pequeno ou truncado")
                return
            }
            if (total > 0 && copied != total) {
                part.delete()
                emit(id, "error", name, copied, total, 0, "incomplete", "copiados $copied de $total bytes")
                return
            }
            // Substituicao com rollback: nao apaga um modelo anterior se o rename final falhar.
            if (backup.exists()) {
                if (!dest.exists()) backup.renameTo(dest) else backup.delete()
            }
            if (dest.exists() && !dest.renameTo(backup)) {
                part.delete()
                emit(id, "error", name, copied, total, 0, "replace_failed", "nao foi possivel preservar o modelo anterior")
                return
            }
            if (!part.renameTo(dest)) {
                if (backup.exists()) backup.renameTo(dest)
                part.delete()
                emit(id, "error", name, copied, total, 0, "rename_failed", "nao foi possivel finalizar a importacao")
                return
            }
            if (backup.exists()) backup.delete()
            if (sourceToDelete != null) { try { sourceToDelete.delete() } catch (_: Throwable) {} }
            JLog.i("import", "modelo $name copiado ($copied bytes)")
            emit(id, "done", name, copied, copied, 0)
        } catch (t: Throwable) {
            JLog.e("import", "falha na copia", t)
            try { part.delete() } catch (_: Throwable) {}
            if (backup.exists() && !dest.exists()) try { backup.renameTo(dest) } catch (_: Throwable) {}
            emit(id, "error", name, copied, total, 0, "io_error", t.toString())
        }
    }
}
