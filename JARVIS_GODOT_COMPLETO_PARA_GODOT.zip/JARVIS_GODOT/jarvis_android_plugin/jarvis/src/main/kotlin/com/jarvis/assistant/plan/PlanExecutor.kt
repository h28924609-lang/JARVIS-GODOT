package com.jarvis.assistant.plan

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.jarvis.assistant.access.Automation
import com.jarvis.assistant.apps.AppManager
import com.jarvis.assistant.safety.ConfirmationNotifier
import com.jarvis.assistant.safety.SafetyPolicy
import com.jarvis.assistant.safety.StepEval
import com.jarvis.assistant.util.EventSink
import com.jarvis.assistant.util.JLog
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * Executa planos (lista de passos estruturados) em thread propria, para continuar funcionando
 * mesmo quando o Godot e pausado ao abrir outro app. Cada passo e REAVALIADO pela SafetyPolicy
 * com o app em primeiro plano real; o que o usuario nao aprovou antes exige nova confirmacao.
 */
class PlanExecutor(private val ctx: Context, private val apps: AppManager, private val sink: EventSink) {
    private val exec = Executors.newSingleThreadExecutor { r -> Thread(r, "jarvis-plan") }
    @Volatile private var cancelFlag = false
    @Volatile var running = false
        private set

    fun evaluate(steps: JSONArray): JSONObject {
        val ev = SafetyPolicy.evaluatePlan(steps, apps, null)
        val arr = JSONArray()
        var blocked = false
        var needs = false
        val reasons = ArrayList<String>()
        for (e in ev) {
            arr.put(e.toJson())
            if (e.level == "blocked") { blocked = true; reasons.addAll(e.reasons) }
            if (e.level == "confirm") needs = true
        }
        return JSONObject().put("ok", true).put("blocked", blocked).put("needs_confirmation", needs)
            .put("steps", arr).put("blocked_reasons", JSONArray(reasons))
            .put("accessibility", Automation.isConnected())
    }

    fun cancel() { cancelFlag = true }

    fun execute(planId: String, steps: JSONArray, approved: Boolean): JSONObject {
        if (running) return JSONObject().put("ok", false).put("error", "busy")
        val pre = SafetyPolicy.evaluatePlan(steps, apps, null)
        if (pre.isEmpty()) return JSONObject().put("ok", false).put("error", "empty_plan")
        if (pre.any { it.level == "blocked" }) return JSONObject().put("ok", false).put("error", "blocked")
        if (pre.any { it.level == "confirm" } && !approved) return JSONObject().put("ok", false).put("error", "needs_confirmation")
        running = true
        cancelFlag = false
        exec.execute { run(planId, steps, pre) }
        return JSONObject().put("ok", true).put("plan_id", planId)
    }

    private fun progress(planId: String, step: Int, total: Int, status: String, msg: String, human: String = "", data: String = "") {
        val o = JSONObject().put("plan_id", planId).put("step", step).put("total", total).put("status", status)
            .put("message", msg).put("human", human)
        if (data.isNotEmpty()) o.put("data", data)
        sink.emit("plan_progress", o)
    }

    private fun run(planId: String, steps: JSONArray, pre: List<StepEval>) {
        val total = pre.size
        var finalStatus = "done"
        var finalMsg = "Concluido"
        try {
            for (i in 0 until total) {
                if (cancelFlag) { finalStatus = "cancelled"; finalMsg = "Cancelado pelo usuario"; break }
                val step = steps.optJSONObject(i) ?: JSONObject()
                val approvedClasses = pre[i].classes
                val live = SafetyPolicy.evaluate(i, step, apps, Automation.foregroundPackage())
                progress(planId, i, total, "running", "", live.human)
                if (live.level == "blocked") {
                    finalStatus = "blocked"; finalMsg = "Bloqueado por seguranca: " + live.reasons.joinToString("; ")
                    break
                }
                val extra = live.classes - approvedClasses
                if (extra.isNotEmpty() && !askRuntime(live, extra)) {
                    finalStatus = "cancelled"; finalMsg = "Voce nao confirmou: ${live.human}"
                    break
                }
                val r = runStep(step, live, approvedClasses)
                if (!r.ok) { finalStatus = "failed"; finalMsg = r.message; progress(planId, i, total, "failed", r.message, live.human); break }
                progress(planId, i, total, "ok", r.message, live.human, r.data)
                try { Thread.sleep(350) } catch (_: InterruptedException) {}
            }
        } catch (t: Throwable) {
            JLog.e("plan", "excecao", t)
            finalStatus = "failed"; finalMsg = "Erro inesperado: $t"
        } finally {
            running = false
        }
        progress(planId, total, total, finalStatus, finalMsg)
    }

    private fun askRuntime(ev: StepEval, extra: Set<String>): Boolean =
        ConfirmationNotifier.ask(ctx, "Jarvis: confirmar acao", "${ev.human}\nRisco: ${extra.joinToString()}")

    private class SR(val ok: Boolean, val message: String, val data: String = "")

    private fun startNew(i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i); true
    } catch (t: Throwable) { JLog.w("plan", "startActivity falhou: $t"); false }

    private fun runStep(step: JSONObject, live: StepEval, approved: Set<String>): SR {
        val a = live.args
        when (live.tool) {
            "open_app" -> {
                val name = a.optString("name", a.optString("package", ""))
                val c = apps.resolve(name)
                if (c.isEmpty()) return SR(false, "App nao encontrado: $name")
                if (c.size > 1 && c[0].score < 100 && c[1].score >= c[0].score - 5)
                    return SR(false, "Mais de um app combina: ${c.joinToString { it.app.label }}. Diga o nome exato.")
                val app = c[0].app
                val launch = apps.launchIntent(app.pkg) ?: return SR(false, "Sem tela inicial: ${app.label}")
                if (!startNew(Intent(launch))) {
                    ConfirmationNotifier.postOpenApp(ctx, app.label, launch)
                    return SR(false, "O Android bloqueou abrir ${app.label}; toque na notificacao.")
                }
                if (Automation.isConnected()) {
                    var waited = 0
                    while (waited < 3000 && Automation.foregroundPackage() != app.pkg) { Thread.sleep(200); waited += 200 }
                    if (Automation.foregroundPackage() != app.pkg) {
                        ConfirmationNotifier.postOpenApp(ctx, app.label, launch)
                        return SR(false, "O Android pode ter bloqueado; toque na notificacao para abrir ${app.label}.")
                    }
                } else Thread.sleep(900)
                return SR(true, "Abri ${app.label}")
            }
            "go_home" -> {
                if (Automation.isConnected()) { val r = Automation.global("home"); return SR(r.ok, if (r.ok) "Tela inicial" else r.message) }
                return if (startNew(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))) SR(true, "Tela inicial") else SR(false, "Nao consegui ir para a tela inicial")
            }
            "go_back" -> return needAcc { Automation.global("back") }
            "recents" -> return needAcc { Automation.global("recents") }
            "notifications" -> return needAcc { Automation.global("notifications") }
            "quick_settings" -> return needAcc { Automation.global("quick_settings") }
            "open_settings" -> {
                val act = SafetyPolicy.settingsAction(a.optString("section", "principal")) ?: return SR(false, "Tela nao permitida")
                return if (startNew(Intent(act))) SR(true, "Abri configuracoes") else SR(false, "Nao foi possivel abrir")
            }
            "click_text" -> {
                if (!Automation.isConnected()) return SR(false, "Ative o servico de acessibilidade do Jarvis nas configuracoes.")
                val f = Automation.findBest(a.optString("text")) ?: return SR(false, "Nao vi \"${a.optString("text")}\" na tela")
                val actual = SafetyPolicy.classify(f.second)
                val extra = actual - approved
                if (extra.isNotEmpty()) {
                    val ev = StepEval(live.index, live.tool, a, "confirm", extra, emptyList(), "Tocar em \"${f.second}\"")
                    if (!askRuntime(ev, extra)) return SR(false, "Voce nao confirmou o toque em \"${f.second}\"")
                }
                val r = Automation.clickNode(f.first)
                return SR(r.ok, if (r.ok) "Toquei em ${f.second}" else "Nao consegui tocar em ${f.second}")
            }
            "type_text" -> {
                val r = Automation.typeText(a.optString("text"), a.optBoolean("append", false))
                return SR(r.ok, if (r.ok) "Digitei o texto" else r.message)
            }
            "scroll" -> {
                val r = Automation.scroll(a.optString("direction", "down") != "up")
                return SR(r.ok, if (r.ok) "Rolei a tela" else r.message)
            }
            "wait" -> { Thread.sleep(a.optInt("ms", 800).coerceIn(100, 5000).toLong()); return SR(true, "Aguardei") }
            "read_screen" -> {
                val r = Automation.readScreen()
                return SR(r.ok, if (r.ok) "Li a tela" else r.message, r.data)
            }
            "open_url" -> {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url")))
                return if (startNew(i)) SR(true, "Abri o endereco") else SR(false, "Nao foi possivel abrir o endereco")
            }
            "compose_message" -> {
                val text = a.optString("text")
                val to = a.optString("to").filter { it.isDigit() || it == '+' }
                val i: Intent = when (a.optString("channel", "sms")) {
                    "whatsapp" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + to.removePrefix("+") + "?text=" + Uri.encode(text)))
                    "email" -> Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + a.optString("to"))).putExtra(Intent.EXTRA_TEXT, text)
                    "share" -> Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Compartilhar")
                    else -> Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$to")).putExtra("sms_body", text)
                }
                return if (startNew(i)) SR(true, "Mensagem preparada; falta voce tocar em enviar") else SR(false, "Nao foi possivel preparar a mensagem")
            }
        }
        return SR(false, "Ferramenta desconhecida")
    }

    private fun needAcc(block: () -> Automation.R): SR {
        if (!Automation.isConnected()) return SR(false, "Ative o servico de acessibilidade do Jarvis nas configuracoes.")
        val r = block()
        return SR(r.ok, if (r.ok) "ok" else r.message)
    }
}
