package com.jarvis.assistant.safety

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.jarvis.assistant.util.JLog
import java.util.UUID
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** Confirmacoes em tempo de execucao via notificacao com botoes (funciona mesmo com outro app aberto). */
object ConfirmationNotifier {
    const val ACTION = "com.jarvis.assistant.CONFIRM"
    private const val CHANNEL = "jarvis_confirm"
    private val pending = ConcurrentHashMap<String, CompletableFuture<Boolean>>()

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Confirmacoes do Jarvis", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun builder(ctx: Context): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CHANNEL) else Notification.Builder(ctx)

    private fun pi(ctx: Context, token: String, yes: Boolean, req: Int): PendingIntent {
        val i = Intent(ctx, ConfirmReceiver::class.java).setAction(ACTION).setPackage(ctx.packageName)
            .putExtra("token", token).putExtra("answer", yes)
        return PendingIntent.getBroadcast(ctx, req, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    /** Bloqueia ate a resposta do usuario (ou timeout => nega). Chamar fora da thread principal. */
    fun ask(ctx: Context, title: String, text: String, timeoutMs: Long = 45_000): Boolean {
        val token = UUID.randomUUID().toString()
        val fut = CompletableFuture<Boolean>()
        pending[token] = fut
        val nid = (token.hashCode() and 0x7fffffff) % 100000 + 1000
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try {
            ensureChannel(ctx)
            val n = builder(ctx).setContentTitle(title).setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.ic_dialog_alert).setAutoCancel(true)
                .addAction(android.R.drawable.ic_menu_send, "Confirmar", pi(ctx, token, true, nid * 2))
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancelar", pi(ctx, token, false, nid * 2 + 1))
                .build()
            nm.notify(nid, n)
            return try { fut.get(timeoutMs, TimeUnit.MILLISECONDS) } catch (_: Throwable) { false }
        } catch (t: Throwable) {
            JLog.e("confirm", "falha ao notificar", t)
            return false
        } finally {
            pending.remove(token)
            try { nm.cancel(nid) } catch (_: Throwable) {}
        }
    }

    /** Notificacao tocavel para abrir um app quando o Android bloqueia abertura em segundo plano. */
    fun postOpenApp(ctx: Context, label: String, launch: Intent) {
        try {
            ensureChannel(ctx)
            val p = PendingIntent.getActivity(ctx, 77, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = builder(ctx).setContentTitle("Jarvis: toque para abrir $label")
                .setContentText("O Android bloqueou a abertura automatica em segundo plano.")
                .setSmallIcon(android.R.drawable.ic_menu_view).setContentIntent(p).setAutoCancel(true).build()
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(7777, n)
        } catch (t: Throwable) { JLog.e("confirm", "postOpenApp", t) }
    }

    fun answer(token: String, yes: Boolean) { pending[token]?.complete(yes) }
}

class ConfirmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent == null || intent.action != ConfirmationNotifier.ACTION) return
        val token = intent.getStringExtra("token") ?: return
        ConfirmationNotifier.answer(token, intent.getBooleanExtra("answer", false))
    }
}
