package com.jarvis.assistant.safety

import android.provider.Settings
import com.jarvis.assistant.apps.AppManager
import com.jarvis.assistant.util.TextUtil
import org.json.JSONArray
import org.json.JSONObject

data class StepEval(
    val index: Int,
    val tool: String,
    val args: JSONObject,
    val level: String,           // safe | confirm | blocked
    val classes: Set<String>,    // classes de risco que exigem confirmacao
    val reasons: List<String>,
    val human: String
) {
    fun toJson(): JSONObject = JSONObject().put("i", index).put("tool", tool).put("args", args).put("level", level)
        .put("classes", JSONArray(classes.toList())).put("reasons", JSONArray(reasons)).put("human", human)
}

/**
 * Politica de seguranca unica (fonte de verdade). Avalia cada passo de um plano antes de executar:
 *  - bloqueia apps bancarios/financeiros, telas de permissao/instalacao, campos de senha e dados financeiros digitados;
 *  - exige confirmacao para enviar/publicar/compartilhar/excluir/comprar/gravar/permitir/ligar e leitura de tela.
 * E uma lista de melhor esforco: nao substitui o julgamento do usuario.
 */
object SafetyPolicy {
    @Volatile var extraBlocked: Set<String> = emptySet()   // pacotes ou nomes adicionados pelo usuario (normalizados)

    private val bankPkgHints = listOf(
        "bank", "banco", "bradesco", "itau", "santander", "nubank", "nu.production", "picpay", "mercadopago",
        "pagseguro", "pagbank", "sicoob", "sicredi", "c6bank", "binance", "mercadobitcoin", "paypal",
        "btgpactual", "wallet", "caixa.tem", "gabba.caixa", "intermedium", "agibank", "safra", "samsung.android.spay"
    )
    private val bankTokens = setOf(
        "banco", "bank", "bradesco", "itau", "santander", "nubank", "picpay", "sicoob", "sicredi", "pagbank",
        "pagseguro", "paypal", "binance", "bitcoin", "cripto", "crypto", "wallet", "carteira", "fintech",
        "corretora", "investimentos", "cartao", "fatura", "emprestimo", "safra", "agibank", "bmg", "daycoval", "sofisa"
    )
    private val bankPhrases = listOf(
        "mercado pago", "mercado bitcoin", "banco do brasil", "caixa tem", "caixa economica", "c6 bank",
        "samsung pay", "google pay", "google wallet", "xp investimentos", "btg pactual", "banco inter", "inter bank", "nu pagamentos"
    )
    val sensitiveSystemPkgs = setOf(
        "com.android.permissioncontroller", "com.google.android.permissioncontroller",
        "com.android.packageinstaller", "com.google.android.packageinstaller",
        "com.samsung.android.packageinstaller", "com.android.systemui"
    )
    val settingsPkgs = setOf("com.android.settings", "com.samsung.android.settings")

    private val riskWords: Map<String, List<String>> = mapOf(
        "enviar" to listOf("enviar", "send", "mandar"),
        "publicar" to listOf("publicar", "postar", "post", "tweetar", "publish"),
        "compartilhar" to listOf("compartilhar", "share", "encaminhar", "forward"),
        "excluir" to listOf("excluir", "apagar", "deletar", "delete", "remover", "remove", "desinstalar", "uninstall",
            "limpar tudo", "esvaziar", "formatar", "redefinir", "reset", "sair da conta"),
        "comprar" to listOf("comprar", "buy", "pagar", "pay", "finalizar pedido", "confirmar pedido", "fazer pedido",
            "place order", "assinar", "subscribe", "doar", "donate", "transferir", "transfer", "contratar"),
        "gravar" to listOf("gravar", "record", "iniciar gravacao", "filmar", "start recording"),
        "permissao" to listOf("permitir", "allow", "conceder", "grant", "instalar", "install", "ativar", "habilitar"),
        "ligar" to listOf("ligar", "call", "chamar", "discar")
    )

    private val settingsMap: Map<String, String> = mapOf(
        "principal" to Settings.ACTION_SETTINGS,
        "wifi" to Settings.ACTION_WIFI_SETTINGS,
        "bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
        "tela" to Settings.ACTION_DISPLAY_SETTINGS,
        "som" to Settings.ACTION_SOUND_SETTINGS,
        "bateria" to Settings.ACTION_BATTERY_SAVER_SETTINGS,
        "apps" to Settings.ACTION_APPLICATION_SETTINGS,
        "acessibilidade" to Settings.ACTION_ACCESSIBILITY_SETTINGS,
        "armazenamento" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
        "data" to Settings.ACTION_DATE_SETTINGS,
        "idioma" to Settings.ACTION_LOCALE_SETTINGS,
        "localizacao" to Settings.ACTION_LOCATION_SOURCE_SETTINGS,
        "aviao" to Settings.ACTION_AIRPLANE_MODE_SETTINGS
    )

    fun settingsAction(section: String): String? = settingsMap[TextUtil.norm(section).replace(" ", "")]
    fun settingsSections(): List<String> = settingsMap.keys.toList()

    fun isFinancialName(name: String): Boolean {
        val n = TextUtil.norm(name)
        if (n.isEmpty()) return false
        if (extraBlocked.any { it.isNotEmpty() && (n == it || n.contains(it)) }) return true
        val padded = " $n "
        if (bankPhrases.any { padded.contains(" $it ") }) return true
        return n.split(" ").any { it in bankTokens }
    }

    fun isBlockedPackage(pkg: String?): Boolean {
        if (pkg == null) return false
        val p = pkg.lowercase()
        if (extraBlocked.contains(p)) return true
        return bankPkgHints.any { p.contains(it) }
    }

    fun isBlockedApp(label: String, pkg: String): Boolean = isBlockedPackage(pkg) || isFinancialName(label)

    fun classify(label: String): Set<String> {
        val padded = " " + TextUtil.norm(label) + " "
        val out = HashSet<String>()
        for ((cls, words) in riskWords) if (words.any { padded.contains(" $it ") }) out.add(cls)
        return out
    }

    private val cardRe = Regex("\\d{4}[ -]?\\d{4}[ -]?\\d{4}[ -]?\\d{3,4}")
    private val cpfRe = Regex("\\d{3}\\.?\\d{3}\\.?\\d{3}-?\\d{2}")

    fun looksFinancialData(text: String): Boolean = cardRe.containsMatchIn(text) || cpfRe.containsMatchIn(text)

    private fun cut(s: String, n: Int = 60) = if (s.length > n) s.substring(0, n) + "..." else s

    fun evaluate(index: Int, step: JSONObject, apps: AppManager, fgPackage: String?): StepEval {
        val tool = step.optString("tool")
        val args = step.optJSONObject("args") ?: JSONObject()
        val reasons = ArrayList<String>()
        val classes = HashSet<String>()
        var level = "safe"
        var human = tool
        fun block(r: String) { level = "blocked"; reasons.add(r) }
        fun confirm(r: String, c: String? = null) { if (level != "blocked") level = "confirm"; reasons.add(r); if (c != null) classes.add(c) }

        // Contexto de primeiro plano (so conhecido na execucao): protege apps financeiros e telas sensiveis.
        val uiTools = setOf("click_text", "type_text", "scroll", "read_screen")
        if (fgPackage != null && tool in uiTools) {
            if (isBlockedPackage(fgPackage)) block("Aplicativo financeiro/bancario em primeiro plano ($fgPackage)")
            else if (fgPackage in sensitiveSystemPkgs) block("Tela de permissao/instalacao do sistema")
            else if (fgPackage in settingsPkgs && (tool == "click_text" || tool == "type_text"))
                block("Alterar Configuracoes por automacao nao e permitido (apenas abrir telas)")
        }

        when (tool) {
            "open_app" -> {
                val name = args.optString("name", args.optString("package", ""))
                human = "Abrir o app \"$name\""
                if (name.isBlank()) block("Nome do app ausente")
                else if (isFinancialName(name)) block("App financeiro/bancario bloqueado")
                else {
                    val c = apps.resolve(name)
                    if (c.isNotEmpty() && isBlockedApp(c[0].app.label, c[0].app.pkg)) block("App financeiro/bancario bloqueado")
                    else if (c.isNotEmpty() && c[0].app.pkg in sensitiveSystemPkgs) block("App de sistema sensivel")
                    else if (c.isEmpty()) reasons.add("App nao encontrado entre os instalados")
                    else human = "Abrir o app \"${c[0].app.label}\""
                }
            }
            "go_home" -> human = "Voltar a tela inicial"
            "go_back" -> human = "Voltar (tela anterior)"
            "recents" -> human = "Abrir apps recentes"
            "notifications" -> human = "Abrir a barra de notificacoes"
            "quick_settings" -> human = "Abrir configuracoes rapidas"
            "open_settings" -> {
                val sec = args.optString("section", "principal")
                human = "Abrir Configuracoes: $sec"
                if (settingsAction(sec) == null) block("Tela de configuracoes nao permitida (permitidas: ${settingsSections().joinToString()})")
            }
            "click_text" -> {
                val t = args.optString("text")
                human = "Tocar em \"${cut(t)}\" na tela"
                if (t.isBlank()) block("Texto do botao ausente")
                val cls = classify(t)
                for (c in cls) confirm("O toque pode $c algo", c)
            }
            "type_text" -> {
                val t = args.optString("text")
                human = "Digitar \"${cut(t)}\""
                if (looksFinancialData(t)) block("Texto parece conter CPF/numero de cartao: bloqueado")
            }
            "scroll" -> human = "Rolar a tela para " + (if (args.optString("direction", "down") == "up") "cima" else "baixo")
            "wait" -> human = "Aguardar ${args.optInt("ms", 800).coerceIn(100, 5000)} ms"
            "read_screen" -> {
                human = "Ler o texto visivel na tela"
                confirm("Le o conteudo atual da tela", "ler_tela")
            }
            "open_url" -> {
                val u = args.optString("url")
                human = "Abrir o endereco ${cut(u, 80)}"
                val l = u.lowercase()
                if (!(l.startsWith("https://") || l.startsWith("http://"))) block("Somente enderecos http/https")
                else if (isFinancialName(l.substringAfter("://").substringBefore("/").replace(".", " ")))
                    block("Site financeiro/bancario bloqueado")
            }
            "compose_message" -> {
                val ch = args.optString("channel", "sms")
                human = "Preparar mensagem ($ch) para ${cut(args.optString("to", "(escolher destinatario)"))}: \"${cut(args.optString("text"))}\" - voce ainda toca em enviar"
                if (ch !in setOf("sms", "whatsapp", "email", "share")) block("Canal desconhecido")
                else confirm("Compartilha conteudo com outro app", "compartilhar")
            }
            else -> block("Ferramenta desconhecida: $tool")
        }
        return StepEval(index, tool, args, level, classes, reasons, human)
    }

    fun evaluatePlan(steps: JSONArray, apps: AppManager, fgPackage: String?): List<StepEval> {
        val out = ArrayList<StepEval>()
        val n = minOf(steps.length(), 8)
        for (i in 0 until n) out.add(evaluate(i, steps.optJSONObject(i) ?: JSONObject(), apps, fgPackage))
        return out
    }
}
