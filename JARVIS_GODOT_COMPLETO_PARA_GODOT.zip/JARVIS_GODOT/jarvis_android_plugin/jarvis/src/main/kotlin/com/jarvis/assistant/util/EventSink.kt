package com.jarvis.assistant.util

import org.json.JSONObject

/** Canal de eventos Kotlin -> Godot (um unico sinal "jarvis_event(nome, json)"). */
interface EventSink {
    fun emit(name: String, payload: JSONObject)
}
