package com.jarvis.assistant.util

import android.util.Log
import java.util.ArrayDeque

/** Log simples com anel em memoria (ultimas linhas) para a tela de diagnostico. */
object JLog {
    private val ring = ArrayDeque<String>()

    @Synchronized
    private fun add(level: String, tag: String, msg: String) {
        ring.addLast("${System.currentTimeMillis() % 100000000} $level/$tag: $msg")
        while (ring.size > 300) ring.removeFirst()
    }

    fun i(tag: String, msg: String) { Log.i("Jarvis", "$tag: $msg"); add("I", tag, msg) }
    fun w(tag: String, msg: String) { Log.w("Jarvis", "$tag: $msg"); add("W", tag, msg) }
    fun e(tag: String, msg: String, t: Throwable? = null) {
        Log.e("Jarvis", "$tag: $msg", t)
        add("E", tag, msg + (if (t != null) " | $t" else ""))
    }

    @Synchronized
    fun dump(): String = ring.joinToString("\n")
}
