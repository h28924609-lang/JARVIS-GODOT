package com.jarvis.assistant.util

import java.text.Normalizer
import java.util.Locale

object TextUtil {
    private val marks = Regex("\\p{M}+")
    private val nonAlnum = Regex("[^a-z0-9 ]+")
    private val spaces = Regex("\\s+")

    /** minusculas, sem acentos, so letras/numeros/espaco. */
    fun norm(s: String): String {
        val d = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        return d.replace(marks, "").replace(nonAlnum, " ").replace(spaces, " ").trim()
    }

    fun lev(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }
}
