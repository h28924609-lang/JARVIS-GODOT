package com.jarvis.assistant.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.jarvis.assistant.util.EventSink
import com.jarvis.assistant.util.JLog
import org.json.JSONObject

/** Reconhecimento de fala via SpeechRecognizer do Android (pt-BR). Pode exigir pacote de idioma offline instalado. */
class SttController(private val ctx: Context, private val sink: EventSink) {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    @Volatile var active = false
        private set
    private var lastRms = 0L

    fun status(): JSONObject {
        val o = JSONObject()
        o.put("available", SpeechRecognizer.isRecognitionAvailable(ctx))
        var onDevice = false
        if (Build.VERSION.SDK_INT >= 33) {
            try { onDevice = SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx) } catch (_: Throwable) {}
        }
        o.put("on_device_available", onDevice)
        o.put("permission", ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
        o.put("active", active)
        return o
    }

    fun start(preferOffline: Boolean, onDeviceOnly: Boolean) {
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sink.emit("stt_error", JSONObject().put("code", "permission").put("message", "Permissao de microfone ausente"))
            return
        }
        main.post {
            try {
                destroyInternal()
                val rec: SpeechRecognizer = if (Build.VERSION.SDK_INT >= 33 && onDeviceOnly &&
                    SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx)
                ) {
                    SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
                } else {
                    if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
                        sink.emit("stt_error", JSONObject().put("code", "unavailable").put("message", "Servico de reconhecimento de fala indisponivel"))
                        return@post
                    }
                    SpeechRecognizer.createSpeechRecognizer(ctx)
                }
                rec.setRecognitionListener(listener)
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline || onDeviceOnly)
                i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
                recognizer = rec
                active = true
                rec.startListening(i)
            } catch (t: Throwable) {
                active = false
                JLog.e("stt", "falha ao iniciar", t)
                sink.emit("stt_error", JSONObject().put("code", "exception").put("message", t.toString()))
            }
        }
    }

    fun stop() { main.post { try { recognizer?.stopListening() } catch (_: Throwable) {} } }

    fun cancel() {
        main.post {
            try { recognizer?.cancel() } catch (_: Throwable) {}
            destroyInternal()
            sink.emit("stt_state", JSONObject().put("state", "cancelled"))
        }
    }

    private fun destroyInternal() {
        active = false
        try { recognizer?.destroy() } catch (_: Throwable) {}
        recognizer = null
    }

    fun shutdown() { main.post { destroyInternal() } }

    private fun first(b: Bundle?): String =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { sink.emit("stt_state", JSONObject().put("state", "ready")) }
        override fun onBeginningOfSpeech() { sink.emit("stt_state", JSONObject().put("state", "begin")) }
        override fun onRmsChanged(rmsdB: Float) {
            val now = System.currentTimeMillis()
            if (now - lastRms < 80) return
            lastRms = now
            val level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            sink.emit("stt_rms", JSONObject().put("level", level.toDouble()))
        }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { sink.emit("stt_state", JSONObject().put("state", "end")) }
        override fun onError(error: Int) {
            active = false
            val name = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH -> "no_match"
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "timeout"
                SpeechRecognizer.ERROR_AUDIO -> "audio"
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "network"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "permission"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "busy"
                SpeechRecognizer.ERROR_CLIENT -> "client"
                12, 13 -> "language_unavailable" // ERROR_LANGUAGE_NOT_SUPPORTED / UNAVAILABLE (API 31+)
                else -> "error_$error"
            }
            sink.emit("stt_error", JSONObject().put("code", name).put("message", "SpeechRecognizer erro $error"))
        }
        override fun onResults(results: Bundle?) {
            active = false
            val conf = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)?.firstOrNull() ?: -1f
            sink.emit("stt_final", JSONObject().put("text", first(results)).put("confidence", conf.toDouble()))
        }
        override fun onPartialResults(partialResults: Bundle?) {
            val t = first(partialResults)
            if (t.isNotEmpty()) sink.emit("stt_partial", JSONObject().put("text", t))
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }
}
