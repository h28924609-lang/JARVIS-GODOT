package com.jarvis.assistant.voice

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.jarvis.assistant.util.EventSink
import com.jarvis.assistant.util.JLog
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Sintese de voz com o TextToSpeech do Android (vozes offline pt-BR quando instaladas). */
class TtsController(private val ctx: Context, private val sink: EventSink) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var initializing = false
    @Volatile private var initError = ""
    private var rate = 1.0f
    private var pitch = 1.0f
    private var volume = 1.0f
    private var voiceName = ""
    @Volatile private var pending = 0

    fun init() {
        if (ready || initializing) { sink.emit("tts_ready", status()); return }
        initializing = true
        main.post {
            try {
                tts = TextToSpeech(ctx.applicationContext) { st -> onInit(st) }
            } catch (t: Throwable) {
                initializing = false
                initError = t.toString()
                sink.emit("tts_ready", status())
            }
        }
    }

    private fun onInit(status: Int) {
        initializing = false
        val t = tts
        if (status != TextToSpeech.SUCCESS || t == null) {
            initError = "init_failed_$status"
            sink.emit("tts_ready", status())
            return
        }
        val r = t.setLanguage(Locale("pt", "BR"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            initError = "pt_br_indisponivel"
        } else initError = ""
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                sink.emit("tts_state", JSONObject().put("id", utteranceId ?: "").put("state", "start"))
            }
            override fun onDone(utteranceId: String?) {
                pending = maxOf(0, pending - 1)
                sink.emit("tts_state", JSONObject().put("id", utteranceId ?: "").put("state", "done").put("pending", pending))
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                pending = maxOf(0, pending - 1)
                sink.emit("tts_state", JSONObject().put("id", utteranceId ?: "").put("state", "error").put("pending", pending))
            }
            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                pending = maxOf(0, pending - 1)
                sink.emit("tts_state", JSONObject().put("id", utteranceId ?: "").put("state", "stopped").put("pending", pending))
            }
        })
        ready = true
        if (voiceName.isNotEmpty()) applyVoice(voiceName)
        JLog.i("tts", "pronto; engine=${t.defaultEngine}")
        sink.emit("tts_ready", status())
    }

    fun status(): JSONObject {
        val o = JSONObject().put("ready", ready).put("initializing", initializing).put("error", initError)
        try { o.put("engine", tts?.defaultEngine ?: "") } catch (_: Throwable) {}
        o.put("voice", voiceName).put("speaking", pending > 0)
        return o
    }

    fun listVoices(): JSONArray {
        val arr = JSONArray()
        try {
            val vs = tts?.voices ?: return arr
            for (v in vs.sortedBy { it.name }) {
                if (v.locale.language != "pt") continue
                arr.put(
                    JSONObject().put("name", v.name).put("locale", v.locale.toLanguageTag())
                        .put("quality", v.quality).put("latency", v.latency)
                        .put("offline", !v.isNetworkConnectionRequired)
                )
            }
        } catch (t: Throwable) { JLog.e("tts", "listVoices", t) }
        return arr
    }

    private fun applyVoice(name: String): Boolean {
        return try {
            val v = tts?.voices?.firstOrNull { it.name == name } ?: return false
            tts?.voice = v
            true
        } catch (t: Throwable) { false }
    }

    fun setVoice(name: String): Boolean {
        voiceName = name
        return if (ready) applyVoice(name) else true
    }

    fun configure(rate: Float, pitch: Float, volume: Float) {
        this.rate = rate.coerceIn(0.5f, 2.0f)
        this.pitch = pitch.coerceIn(0.5f, 2.0f)
        this.volume = volume.coerceIn(0.0f, 1.0f)
    }

    fun speak(text: String, queue: Boolean, id: String): Boolean {
        val t = tts
        if (!ready || t == null || text.isBlank()) return false
        t.setSpeechRate(rate)
        t.setPitch(pitch)
        val params = Bundle()
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume)
        pending++
        val r = t.speak(text, if (queue) TextToSpeech.QUEUE_ADD else TextToSpeech.QUEUE_FLUSH, params, id)
        if (r != TextToSpeech.SUCCESS) { pending = maxOf(0, pending - 1); return false }
        return true
    }

    fun stop() {
        pending = 0
        try { tts?.stop() } catch (_: Throwable) {}
    }

    fun isSpeaking(): Boolean = pending > 0 || (try { tts?.isSpeaking == true } catch (_: Throwable) { false })

    fun shutdown() {
        try { tts?.stop(); tts?.shutdown() } catch (_: Throwable) {}
        tts = null
        ready = false
    }
}
