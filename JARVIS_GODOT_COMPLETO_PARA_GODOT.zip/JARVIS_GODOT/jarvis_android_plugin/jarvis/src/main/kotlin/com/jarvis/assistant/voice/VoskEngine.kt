package com.jarvis.assistant.voice

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.jarvis.assistant.util.JLog
import org.json.JSONObject
import java.io.File

/**
 * Reconhecimento 100% offline com Vosk, acessado por REFLEXAO (a biblioteca com.alphacephei:vosk-android
 * e dependencia opcional do app; se ausente, o recurso informa "indisponivel" sem quebrar a compilacao).
 * Modos: palavra de ativacao (gramatica restrita) e ditado (vocabulario completo).
 */
class VoskEngine(private val ctx: Context) {
    interface Listener {
        fun onPartial(text: String)
        fun onFinal(text: String)
        fun onError(code: String, message: String)
        fun onStopped()
    }

    companion object {
        const val MODEL_DIR_NAME = "vosk-model-small-pt-0.3"
        @Volatile private var cachedModel: Any? = null
        @Volatile private var cachedPath: String = ""

        fun libraryAvailable(): Boolean = try { Class.forName("org.vosk.Model"); true } catch (_: Throwable) { false }
    }

    fun modelDir(): File = File(File(ctx.filesDir, "vosk"), MODEL_DIR_NAME)
    fun modelReady(): Boolean = File(modelDir(), "conf").exists() || File(modelDir(), "am").exists()

    @Volatile private var running = false
    private var thread: Thread? = null

    fun isRunning(): Boolean = running

    fun stop() { running = false }

    /** grammarJson != null => modo palavra-chave; null => ditado. */
    fun start(grammarJson: String?, maxSeconds: Int, listener: Listener) {
        if (running) return
        if (!libraryAvailable()) { listener.onError("vosk_missing", "Biblioteca Vosk nao incluida no app"); return }
        if (!modelReady()) { listener.onError("model_missing", "Modelo Vosk nao instalado"); return }
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            listener.onError("permission", "Permissao de microfone ausente"); return
        }
        running = true
        thread = Thread({ loop(grammarJson, maxSeconds, listener) }, "jarvis-vosk").also { it.start() }
    }

    private fun loop(grammarJson: String?, maxSeconds: Int, listener: Listener) {
        var rec: Any? = null
        var ar: AudioRecord? = null
        var recCls: Class<*>? = null
        try {
            val modelCls = Class.forName("org.vosk.Model")
            recCls = Class.forName("org.vosk.Recognizer")
            val path = modelDir().absolutePath
            if (cachedModel == null || cachedPath != path) {
                cachedModel = modelCls.getConstructor(String::class.java).newInstance(path)
                cachedPath = path
            }
            val floatT = Float::class.javaPrimitiveType
            rec = if (grammarJson != null)
                recCls.getConstructor(modelCls, floatT, String::class.java).newInstance(cachedModel, 16000.0f, grammarJson)
            else
                recCls.getConstructor(modelCls, floatT).newInstance(cachedModel, 16000.0f)
            val accept = recCls.getMethod("acceptWaveForm", ByteArray::class.java, Int::class.javaPrimitiveType)
            val getResult = recCls.getMethod("getResult")
            val getPartial = recCls.getMethod("getPartialResult")
            val resetM = try { recCls.getMethod("reset") } catch (_: Throwable) { null }

            val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            ar = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 16000))
            if (ar.state != AudioRecord.STATE_INITIALIZED) { listener.onError("audio", "Nao foi possivel abrir o microfone"); return }
            ar.startRecording()

            val buf = ByteArray(3200)
            val start = System.currentTimeMillis()
            var heard = false
            var lastPartial = ""
            while (running) {
                val now = System.currentTimeMillis()
                if (maxSeconds > 0 && now - start > maxSeconds * 1000L) {
                    if (grammarJson == null) {
                        if (!heard) listener.onError("timeout", "Nenhuma fala detectada")
                    }
                    break
                }
                if (grammarJson == null && !heard && now - start > 8000) { listener.onError("timeout", "Nenhuma fala detectada"); break }
                val n = ar.read(buf, 0, buf.size)
                if (n <= 0) continue
                val endpoint = accept.invoke(rec, buf, n) as Boolean
                if (endpoint) {
                    val text = JSONObject(getResult.invoke(rec) as String).optString("text")
                    if (text.isNotEmpty()) {
                        heard = true
                        listener.onFinal(text)
                        if (grammarJson == null) break
                        try { resetM?.invoke(rec) } catch (_: Throwable) {}
                        lastPartial = ""
                    }
                } else {
                    val p = JSONObject(getPartial.invoke(rec) as String).optString("partial")
                    if (p.isNotEmpty() && p != lastPartial) {
                        lastPartial = p
                        heard = true
                        listener.onPartial(p)
                    }
                }
            }
        } catch (t: Throwable) {
            JLog.e("vosk", "falha no loop", t)
            listener.onError("exception", t.toString())
        } finally {
            running = false
            try { ar?.stop() } catch (_: Throwable) {}
            try { ar?.release() } catch (_: Throwable) {}
            try { recCls?.getMethod("close")?.invoke(rec) } catch (_: Throwable) {}
            listener.onStopped()
        }
    }
}
