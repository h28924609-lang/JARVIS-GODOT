package com.jarvis.assistant.voice

import android.content.Context
import com.jarvis.assistant.engine.ModelDownloader
import com.jarvis.assistant.util.EventSink
import com.jarvis.assistant.util.JLog
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

/** Baixa (~31 MB) e instala o modelo Vosk pt-BR pequeno. Licenca Apache 2.0 (alphacephei.com/vosk/models). */
class VoskModelManager(private val ctx: Context, private val sink: EventSink) {
    companion object {
        const val URL = "https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip"
        const val ZIP_NAME = "vosk-model-small-pt-0.3.zip"
    }

    private val engine = VoskEngine(ctx)
    private val root = File(ctx.filesDir, "vosk")

    private val wrapper = object : EventSink {
        override fun emit(name: String, payload: JSONObject) {
            if (payload.optString("state") == "done") {
                Thread({
                    try {
                        sink.emit("vosk_download", JSONObject().put("id", "vosk").put("state", "installing"))
                        unzip(File(root, ZIP_NAME), root)
                        File(root, ZIP_NAME).delete()
                        sink.emit("vosk_download", JSONObject().put("id", "vosk").put("state", "done"))
                    } catch (t: Throwable) {
                        JLog.e("vosk", "falha ao instalar", t)
                        sink.emit("vosk_download", JSONObject().put("id", "vosk").put("state", "error").put("error", "unzip").put("detail", t.toString()))
                    }
                }, "jarvis-vosk-unzip").start()
            } else sink.emit(name, payload)
        }
    }
    private val dl = ModelDownloader(wrapper, "vosk_download")

    fun status(): JSONObject = JSONObject()
        .put("library", VoskEngine.libraryAvailable())
        .put("model_ready", engine.modelReady())
        .put("downloading", dl.isRunning("vosk"))

    fun download() { root.mkdirs(); dl.start("vosk", URL, root, ZIP_NAME, 0L, "", "PK") }
    fun cancel() { dl.cancel("vosk", false) }
    fun delete(): Boolean = root.deleteRecursively()

    private fun unzip(zip: File, dest: File) {
        val destPath = dest.canonicalPath + File.separator
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val out = File(dest, e.name)
                if (!out.canonicalPath.startsWith(destPath)) throw SecurityException("entrada invalida no zip")
                if (e.isDirectory) { out.mkdirs() } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { fo -> zin.copyTo(fo) }
                }
            }
        }
    }
}
