package com.jarvis.assistant.voice

import android.content.Context
import com.jarvis.assistant.util.JLog
import com.jarvis.assistant.util.TextUtil
import org.json.JSONArray

/** Loop de palavra de ativacao: escuta continuamente (local, Vosk com gramatica restrita) e avisa ao detectar "Jarvis". */
class WakeWordCore(ctx: Context, private val onDetected: (String) -> Unit, private val onProblem: (String, String) -> Unit) {
    private val engine = VoskEngine(ctx)
    @Volatile private var wanted = false
    @Volatile private var lastDetect = 0L
    private val keys = listOf("jarvis", "ja vis", "jarvi", "jarves", "djarvis")

    private fun grammar(): String {
        val a = JSONArray()
        for (w in listOf("jarvis", "já vis", "jarvi", "[unk]")) a.put(w)
        return a.toString()
    }

    fun start() {
        wanted = true
        launch()
    }

    private fun launch() {
        if (!wanted || engine.isRunning()) return
        engine.start(grammar(), 0, object : VoskEngine.Listener {
            private fun check(t: String) {
                val n = TextUtil.norm(t)
                val hit = keys.any { n.contains(it) }
                val now = System.currentTimeMillis()
                if (hit && now - lastDetect > 3000) {
                    lastDetect = now
                    JLog.i("wake", "palavra de ativacao detectada")
                    onDetected(n)
                }
            }
            override fun onPartial(text: String) = check(text)
            override fun onFinal(text: String) = check(text)
            override fun onError(code: String, message: String) { wanted = false; onProblem(code, message) }
            override fun onStopped() {}
        })
    }

    fun pause() { engine.stop() }
    fun resume() { if (wanted) launch() }
    fun stop() { wanted = false; engine.stop() }
    fun isActive(): Boolean = wanted && engine.isRunning()
    fun isWanted(): Boolean = wanted
}
