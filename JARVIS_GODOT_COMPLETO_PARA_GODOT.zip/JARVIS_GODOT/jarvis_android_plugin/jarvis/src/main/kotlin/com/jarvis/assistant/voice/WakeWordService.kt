package com.jarvis.assistant.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.jarvis.assistant.util.JLog

/**
 * Servico em primeiro plano (tipo microfone) que mantem a escuta da palavra de ativacao com o app em segundo plano.
 * Sempre exibe uma notificacao visivel. O Android pode bloquear a abertura do app a partir do segundo plano;
 * nesse caso o toque na notificacao abre o Jarvis. Nao funciona de forma irrestrita com a tela bloqueada.
 */
class WakeWordService : Service() {
    companion object {
        const val CHANNEL = "jarvis_wake"
        const val NOTIF_ID = 4711
        @Volatile var listener: ((String) -> Unit)? = null
        @Volatile var pendingWake: Boolean = false
        @Volatile var running: Boolean = false

        fun start(ctx: Context) {
            val i = Intent(ctx, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, WakeWordService::class.java)) }
    }

    private var core: WakeWordCore? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Palavra de ativacao", NotificationManager.IMPORTANCE_LOW))
        }
        val open = packageManager.getLaunchIntentForPackage(packageName)
        val pi = if (open != null) PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE) else null
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        b.setContentTitle("Jarvis esta ouvindo a palavra de ativacao")
            .setContentText("Diga \"Jarvis\". Toque para abrir. O microfone esta em uso.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
        if (pi != null) b.setContentIntent(pi)
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(NOTIF_ID, b.build())
        } catch (t: Throwable) {
            JLog.e("wake", "startForeground falhou", t)
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        if (core == null) {
            core = WakeWordCore(this, { text ->
                pendingWake = true
                val l = listener
                if (l != null) l(text)
                try {
                    val launch = packageManager.getLaunchIntentForPackage(packageName)
                    launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    if (launch != null) startActivity(launch)
                } catch (t: Throwable) { JLog.w("wake", "Android bloqueou abrir o app em segundo plano: $t") }
            }, { code, msg -> JLog.w("wake", "problema: $code $msg"); stopSelf() })
        }
        core?.start()
        return START_STICKY
    }

    override fun onDestroy() {
        core?.stop()
        core = null
        running = false
        super.onDestroy()
    }
}
