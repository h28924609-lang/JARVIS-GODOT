@echo off
setlocal EnableExtensions
cd /d "%~dp0.."
where git >nul 2>nul || (echo ERRO: Git nao encontrado.& exit /b 1)
where java >nul 2>nul || (echo ERRO: JDK 17 nao encontrado no PATH.& exit /b 1)
java -version 2>&1 | findstr /C:"17." >nul || (echo ERRO: use JDK 17.& exit /b 1)
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado no PATH.& exit /b 1)
if "%ANDROID_HOME%"=="" if "%ANDROID_SDK_ROOT%"=="" (echo ERRO: defina ANDROID_HOME ou ANDROID_SDK_ROOT.& exit /b 1)
if not exist "jarvis\src\main\cpp\llama.cpp\CMakeLists.txt" (
  set "TAG="
  set /p TAG=<scripts\LLAMA_CPP_TAG
  git clone --depth 1 --branch %TAG% https://github.com/ggml-org/llama.cpp.git jarvis\src\main\cpp\llama.cpp || exit /b 1
)
call gradlew.bat --no-daemon -PgodotVersion=4.7.2.stable :jarvis:assembleDebug :jarvis:assembleRelease || exit /b 1
if not exist "..\addons\jarvis_android\bin" mkdir "..\addons\jarvis_android\bin"
copy /Y "jarvis\build\outputs\aar\jarvis-debug.aar" "..\addons\jarvis_android\bin\jarvis-debug.aar" >nul || exit /b 1
copy /Y "jarvis\build\outputs\aar\jarvis-release.aar" "..\addons\jarvis_android\bin\jarvis-release.aar" >nul || exit /b 1
python ..\tools\verificar_aar.py "..\addons\jarvis_android\bin\jarvis-debug.aar" "..\addons\jarvis_android\bin\jarvis-release.aar"
if errorlevel 1 exit /b 1
echo JARVIS AAR compilados e copiados para addons\jarvis_android\bin.
