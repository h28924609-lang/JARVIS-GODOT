#!/usr/bin/env bash
# Compila o plugin Kotlin + motor nativo e copia os AAR para addons/jarvis_android/bin/.
# Requisitos (PC ou CI): JDK 17, Android SDK (platform 35, build-tools, NDK 27.2.12479018, CMake 3.22.1), Gradle 8.10+ (ou wrapper), git.
set -euo pipefail
cd "$(dirname "$0")/.."
command -v java >/dev/null 2>&1 || { echo "ERRO: JDK 17 nao encontrado no PATH" >&2; exit 1; }
java -version 2>&1 | grep -q '17\.' || { echo "ERRO: use JDK 17 (Java 21/8 nao e suportado por este build)" >&2; exit 1; }
command -v git >/dev/null 2>&1 || { echo "ERRO: Git nao encontrado no PATH" >&2; exit 1; }
command -v cmake >/dev/null 2>&1 || { echo "ERRO: CMake nao encontrado no PATH" >&2; exit 1; }
[ -n "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ] || { echo "ERRO: defina ANDROID_HOME ou ANDROID_SDK_ROOT" >&2; exit 1; }
bash scripts/fetch_llama_cpp.sh
GRADLE="./gradlew"
[ -x "$GRADLE" ] || GRADLE="gradle"
$GRADLE --no-daemon :jarvis:assembleDebug :jarvis:assembleRelease "$@"
OUT="../addons/jarvis_android/bin"
mkdir -p "$OUT"
cp jarvis/build/outputs/aar/jarvis-debug.aar "$OUT/jarvis-debug.aar"
cp jarvis/build/outputs/aar/jarvis-release.aar "$OUT/jarvis-release.aar"
echo "AAR copiados para $OUT"
python3 ../tools/verificar_aar.py "$OUT/jarvis-debug.aar" "$OUT/jarvis-release.aar"
unzip -l "$OUT/jarvis-release.aar" | grep -E "libjarvis_llama.so|classes.jar|AndroidManifest" || true
