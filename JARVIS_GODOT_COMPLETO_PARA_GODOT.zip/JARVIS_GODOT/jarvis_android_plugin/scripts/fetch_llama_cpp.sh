#!/usr/bin/env bash
# Baixa o llama.cpp na tag fixada para jarvis/src/main/cpp/llama.cpp (necessario para compilar o AAR).
set -euo pipefail
cd "$(dirname "$0")/.."
TAG="${1:-$(cat scripts/LLAMA_CPP_TAG)}"
DEST="jarvis/src/main/cpp/llama.cpp"
if [ -f "$DEST/CMakeLists.txt" ]; then echo "llama.cpp ja presente em $DEST"; exit 0; fi
git clone --depth 1 --branch "$TAG" https://github.com/ggml-org/llama.cpp.git "$DEST"
echo "llama.cpp $TAG pronto em $DEST"
