extends Node
# Cerebro do Jarvis: recebe texto/voz, decide entre conversa, comando direto, acao no celular (plano validado),
# memoria e consultas opcionais. Gerencia o estado exibido pelo nucleo animado.

const U = preload("res://scripts/core/util.gd")
const IR = preload("res://scripts/core/intent_router.gd")

signal state_changed(state)
signal message_added(msg)
signal message_updated(msg)
signal notice(text, kind)
signal busy_changed(busy)
signal plan_step(info)
signal voice_partial(text)

enum S { IDLE, LISTENING, THINKING, SPEAKING, ACTING, ERROR }
const STATE_NAMES := ["idle", "listening", "thinking", "speaking", "acting", "error"]
const ALLOWED_TOOLS := ["open_app", "go_home", "go_back", "recents", "notifications", "quick_settings", "open_settings",
	"click_text", "type_text", "scroll", "wait", "open_url", "compose_message", "read_screen"]

var state: int = S.IDLE
var busy := false
var acting := false
var streaming := false
var _cancel := false
var _plan_seq := 0
var _plan_final: Dictionary = {}
var _plan_id := ""
var _plan_data := ""
var _amsg: Dictionary = {}
var _full := ""
var _speak_buf := ""
var _error_until := 0.0

func _ready() -> void:
	Voice.listening_changed.connect(func(_a): _refresh())
	Voice.speaking_changed.connect(func(_a): _refresh())
	Voice.stt_final.connect(_on_stt_final)
	Voice.stt_partial.connect(func(t): voice_partial.emit(t))
	Voice.stt_error.connect(_on_stt_error)
	Voice.wake_detected.connect(_on_wake)
	Llm.state_changed.connect(_refresh)
	Bridge.evt.connect(_on_bridge_evt)

# ---------------- estado ----------------
func _refresh() -> void:
	var ns := S.IDLE
	if Time.get_ticks_msec() / 1000.0 < _error_until:
		ns = S.ERROR
	elif acting:
		ns = S.ACTING
	elif Voice.listening:
		ns = S.LISTENING
	elif Voice.speaking or (streaming and not Cfg.get_v("tts_enabled")):
		ns = S.SPEAKING
	elif busy or Llm.generating or Llm.loading:
		ns = S.THINKING
	if ns != state:
		state = ns
		state_changed.emit(state)

func state_name() -> String:
	return STATE_NAMES[state]

func _set_busy(v: bool) -> void:
	busy = v
	busy_changed.emit(v)
	_refresh()

func _flash_error() -> void:
	_error_until = Time.get_ticks_msec() / 1000.0 + 1.6
	_refresh()
	get_tree().create_timer(1.7).timeout.connect(_refresh)

# ---------------- inicializacao ----------------
func startup() -> void:
	if not Bridge.available:
		return
	Llm.refresh()
	if Llm.unclean_exit != "":
		notice.emit("O app foi encerrado durante uma operacao do modelo (%s). Se repetir, use o modelo menor ou reduza o contexto em Configuracoes." % Llm.unclean_exit, "warn")
		Bridge.api("llm_clear_crash_flags")
	var _crashed_on_load: bool = Llm.unclean_exit == "load"
	Voice.apply_settings()
	Bridge.api("set_blocked_packages", [JSON.stringify(Cfg.get_v("blocked_extra"))])
	if Cfg.get_v("keep_screen_on"):
		Bridge.plugin.keep_screen_on(true)
	if _crashed_on_load:
		notice.emit("O app fechou ao carregar o modelo na ultima vez; o carregamento automatico foi pulado. Reduza o contexto em Configuracoes ou use o modelo 0.5B e carregue manualmente em Modelos de IA.", "warn")
	elif Cfg.get_v("model_auto_load") and not Llm.loaded and not Llm.loading:
		var st := Llm.auto_prepare()
		if st == "none":
			notice.emit("Nenhum modelo GGUF encontrado. Abra Modelos de IA e selecione o arquivo qwen2.5-1.5b-instruct-q4_k_m.gguf.", "warn")
	if Cfg.get_v("wake_enabled"):
		Voice.apply_wake_settings()

func model_exists(filename: String) -> bool:
	var r = Bridge.api("llm_list_models")
	if typeof(r) == TYPE_DICTIONARY:
		for m in r.get("models", []):
			if m.get("name", "") == filename and not m.get("partial", false):
				return true
	return false

# ---------------- entrada ----------------
func interrupt() -> void:
	_cancel = true
	Llm.cancel()
	Voice.stop_speaking()
	Voice.cancel_listening()
	if acting:
		Bridge.api("plan_cancel")
	_refresh()

func repeat_response() -> void:
	var msgs: Array = Store.current["messages"]
	for i in range(msgs.size() - 1, -1, -1):
		if msgs[i]["role"] == "assistant" and String(msgs[i]["text"]).strip_edges() != "":
			Voice.stop_speaking()
			Voice.speak(String(msgs[i]["text"]), false)
			return
	notice.emit("Ainda nao ha nada para repetir.", "info")

func toggle_listening() -> void:
	if Voice.listening:
		Voice.stop_listening()
	elif not busy:
		Voice.start_listening()

func _on_wake() -> void:
	if not busy and not Voice.listening:
		Voice.start_listening()

func _on_stt_final(text: String) -> void:
	if text.strip_edges() == "":
		notice.emit("Nao entendi o que voce disse. Tente de novo.", "info")
		return
	if Cfg.get_v("auto_send_voice"):
		submit(text, true)
	else:
		voice_partial.emit(text)

func _on_stt_error(code: String, message: String) -> void:
	var m := "Erro no reconhecimento de voz: %s" % message
	match code:
		"no_match", "timeout":
			m = "Nao ouvi nada. Toque no microfone e fale de novo."
		"permission":
			m = message
		"network":
			m = "O reconhecimento precisou de internet. Instale o pacote de idioma offline pt-BR (Configuracoes do Android > Gerenciamento geral > Idioma > Voz) ou use o motor Vosk nas configuracoes."
		"language_unavailable":
			m = "Pacote de idioma pt-BR offline indisponivel neste aparelho. Instale-o nas configuracoes do Android ou escolha o motor Vosk."
		"vosk_missing", "model_missing":
			m = "O reconhecimento Vosk nao esta disponivel (biblioteca/modelo ausente). Veja Configuracoes > Voz."
		"busy":
			m = "O reconhecimento de voz esta ocupado. Tente em instantes."
	notice.emit(m, "warn")

func submit(text: String, via_voice: bool = false) -> void:
	var t := text.strip_edges()
	if t == "":
		return
	if busy:
		notice.emit("Ainda estou ocupado. Toque em parar para interromper.", "info")
		return
	_cancel = false
	_set_busy(true)
	var um := Store.add_message("user", t)
	message_added.emit(um)
	await _handle(t, via_voice)
	Store.save_current()
	_set_busy(false)
	if via_voice and Cfg.get_v("continuous_conversation") and not _cancel:
		await _wait_speech_done(30.0)
		if not _cancel and not busy:
			Voice.start_listening()

func _wait_speech_done(timeout: float) -> void:
	var t0 := Time.get_ticks_msec() / 1000.0
	while Voice.speaking and Time.get_ticks_msec() / 1000.0 - t0 < timeout and not _cancel:
		await get_tree().create_timer(0.25).timeout

# ---------------- respostas locais ----------------
func say_local(text: String, speak: bool = true) -> void:
	var m := Store.add_message("assistant", text, {"local": true})
	message_added.emit(m)
	if speak:
		Voice.begin_utterance_group()
		Voice.speak(text, false)

func _handle(t: String, via_voice: bool) -> void:
	var intent: Dictionary = IR.parse(t)
	match String(intent.get("kind", "chat")):
		"stop":
			interrupt()
			notice.emit("Ok, parei.", "info")
		"repeat":
			repeat_response()
		"time":
			var d := Time.get_time_dict_from_system()
			say_local("Sao %02d:%02d." % [d["hour"], d["minute"]])
		"date":
			var dd := Time.get_date_dict_from_system()
			var dias := ["domingo", "segunda-feira", "terca-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sabado"]
			say_local("Hoje e %s, %02d/%02d/%04d." % [dias[dd["weekday"]], dd["day"], dd["month"], dd["year"]])
		"volume":
			_volume(intent)
		"memory_add":
			await _memory_add(String(intent["text"]))
		"memory_forget":
			await _memory_forget(String(intent["query"]))
		"memory_list":
			_memory_list()
		"wikipedia":
			await _wikipedia(String(intent["query"]), t)
		"weather":
			await _weather(String(intent["city"]))
		"plan":
			await _run_plan(intent["steps"], t)
		_:
			await _maybe_name(t)
			if Cfg.get_v("tools_enabled") and IR.looks_like_command(t) and Llm.loaded and Bridge.available:
				var steps: Array = await _llm_route(t)
				if not steps.is_empty() and not _cancel:
					await _run_plan(steps, t)
					return
			await _chat(t, "")

# ---------------- utilidades de intencao ----------------
func _volume(intent: Dictionary) -> void:
	if not Bridge.available:
		say_local("Preciso do plugin Android para mexer no volume.")
		return
	var cur: int = int(Bridge.plugin.get_media_volume())
	var nv: int = int(intent["set"]) if intent.has("set") else clampi(cur + int(intent.get("delta", 0)), 0, 100)
	nv = int(Bridge.plugin.set_media_volume(nv))
	say_local("Volume em %d por cento." % nv)

func _guess_category(t: String) -> String:
	var n := U.norm(t)
	if n.contains("gosto") or n.contains("prefiro") or n.contains("favorit"):
		return "preferencia"
	if n.contains("minha esposa") or n.contains("meu marido") or n.contains("meu filho") or n.contains("minha filha") or n.contains("amigo"):
		return "pessoa"
	if n.contains("todo dia") or n.contains("toda") or n.contains("acordo") or n.contains("trabalho as"):
		return "rotina"
	return "fato"

func _memory_add(text: String) -> void:
	if not Cfg.get_v("memory_enabled"):
		say_local("A memoria esta desativada nas configuracoes.")
		return
	var chk: Dictionary = Store.check_sensitive(text)
	if chk["level"] == "never":
		say_local("Por seguranca eu nao guardo senhas, numeros de cartao ou CPF.")
		return
	if chk["level"] == "consent" or Cfg.get_v("memory_ask_before_save"):
		var lines: Array = ["\"%s\"" % text]
		if chk["level"] == "consent":
			lines.append("Atencao: %s. Fica somente neste aparelho." % chk["reason"])
		else:
			lines.append("Fica somente neste aparelho. Voce pode editar ou apagar depois.")
		var yes: bool = await Safety.ask("Salvar na memoria?", lines, "Salvar", "Nao salvar", chk["level"] == "consent")
		if not yes:
			say_local("Tudo bem, nao guardei.")
			return
	var r: Dictionary = Store.add_memory(text, _guess_category(text))
	say_local("Anotado." if r["ok"] else "Nao consegui guardar: %s." % r.get("error", "erro"))

func _memory_forget(query: String) -> void:
	var found: Array = Store.search_memories(query, 1)
	if found.is_empty():
		say_local("Nao encontrei nada na memoria sobre isso.")
		return
	var yes: bool = await Safety.ask("Apagar da memoria?", ["\"%s\"" % found[0]["text"]], "Apagar", "Manter", true)
	if yes:
		Store.remove_memory(found[0]["id"])
		say_local("Pronto, esqueci.")
	else:
		say_local("Ok, mantive.")

func _memory_list() -> void:
	var n: int = Store.memories.size()
	if n == 0:
		say_local("Ainda nao guardei nada sobre voce. Diga \"lembre que...\" para eu anotar.")
		return
	var parts: Array = []
	for i in range(mini(n, 5)):
		parts.append(String(Store.memories[Store.memories.size() - 1 - i]["text"]))
	say_local("Tenho %d lembranca%s. As mais recentes: %s. Voce pode ver e editar tudo na tela de Memoria." % [n, "" if n == 1 else "s", "; ".join(parts)])

func _maybe_name(t: String) -> void:
	if String(Cfg.get_v("user_name")) != "":
		return
	var m := RegEx.create_from_string("(?i)\\b(?:meu nome (?:e|é)|me chamo|pode me chamar de)\\s+([A-Za-zÀ-ú]{2,20})").search(t)
	if m != null:
		var nm: String = m.get_string(1)
		var yes: bool = await Safety.ask("Guardar seu nome?", ["Posso chamar voce de \"%s\"?" % nm], "Sim", "Nao")
		if yes:
			Cfg.set_v("user_name", nm)

func _wikipedia(q: String, original: String) -> void:
	if not Net.allowed("wikipedia"):
		say_local("A consulta a Wikipedia esta desligada. Ative a internet opcional nas configuracoes se quiser.")
		return
	if not Bridge.is_online():
		say_local("Estou sem internet agora.")
		return
	var ok: bool = await Net.authorize("wikipedia", q)
	if not ok:
		say_local("Certo, nao fiz a consulta.")
		return
	var r: Dictionary = await Net.wikipedia(q)
	if not r["ok"]:
		say_local(String(r["error"]))
		return
	var extract := String(r["extract"])
	if Llm.loaded:
		await _chat("Explique de forma simples e curta: %s" % q, "Trecho da Wikipedia sobre %s: %s" % [r["title"], extract.substr(0, 900)])
	else:
		say_local(extract.substr(0, 400))

func _weather(city: String) -> void:
	if not Net.allowed("weather"):
		say_local("A consulta de clima esta desligada. Ative a internet opcional nas configuracoes se quiser.")
		return
	if not Bridge.is_online():
		say_local("Estou sem internet agora.")
		return
	var ok: bool = await Net.authorize("weather", city)
	if not ok:
		say_local("Certo, nao fiz a consulta.")
		return
	var r: Dictionary = await Net.weather(city)
	say_local(String(r["text"]) if r["ok"] else String(r["error"]))

# ---------------- conversa com o modelo ----------------
func _ensure_model() -> bool:
	if not Bridge.available:
		say_local("O motor de IA nativo nao esta disponivel nesta execucao (plugin Android nao carregado). No APK instalado ele e carregado automaticamente; veja Configuracoes > Diagnostico.", false)
		_flash_error()
		return false
	if Llm.loaded:
		return true
	if Llm.importing:
		notice.emit("Copiando o arquivo do modelo, aguarde...", "info")
		var tc := Time.get_ticks_msec() / 1000.0
		while Llm.importing and Time.get_ticks_msec() / 1000.0 - tc < 900.0 and not _cancel:
			await get_tree().create_timer(0.4).timeout
	if not Llm.loading and not Llm.loaded:
		var st := Llm.auto_prepare()
		if st == "importing":
			var ti := Time.get_ticks_msec() / 1000.0
			while Llm.importing and Time.get_ticks_msec() / 1000.0 - ti < 900.0 and not _cancel:
				await get_tree().create_timer(0.4).timeout
		elif st == "none":
			say_local("Ainda nao ha um modelo de IA no aparelho. Abra Modelos de IA e toque em Selecionar arquivo GGUF (qwen2.5-1.5b-instruct-q4_k_m.gguf) ou baixe o modelo.", false)
			_flash_error()
			return false
	notice.emit("Carregando o modelo, so um instante...", "info")
	var t0 := Time.get_ticks_msec() / 1000.0
	while (Llm.loading or Llm.importing) and Time.get_ticks_msec() / 1000.0 - t0 < 240.0 and not _cancel:
		await get_tree().create_timer(0.3).timeout
	if not Llm.loaded:
		say_local("Nao consegui carregar o modelo: %s" % Llm.last_error, false)
		_flash_error()
		return false
	return true

func _context_block(user_text: String, extra: String) -> String:
	var parts: Array = []
	var d := Time.get_time_dict_from_system()
	parts.append("Hora atual: %02d:%02d." % [d["hour"], d["minute"]])
	var mem: Array = Store.search_memories(user_text, 4)
	if not mem.is_empty():
		var lines: Array = []
		for m in mem:
			lines.append("- " + String(m["text"]))
		parts.append("Memorias autorizadas do usuario:\n" + "\n".join(lines))
	if extra != "":
		parts.append(extra)
	return "\n".join(parts)

func _on_token(_id, text: String) -> void:
	_full += text
	_amsg["text"] = _full
	message_updated.emit(_amsg)
	if not streaming:
		streaming = true
		_refresh()
	if Cfg.get_v("tts_enabled") and Cfg.get_v("speak_sentences"):
		_speak_buf += text
		var r: Array = Voice.take_sentences(_speak_buf)
		for s in r[0]:
			Voice.speak(String(s), true)
		_speak_buf = r[1]

func _chat(user_text: String, extra: String) -> void:
	if not await _ensure_model():
		return
	if _cancel:
		return
	var family := Persona.family_for(Llm.model_name)
	var hist: Array = Store.chat_messages(24)
	var ctx := _context_block(user_text, extra)
	if hist.size() > 0:
		hist[hist.size() - 1] = {"role": "user", "text": "[Contexto confiavel: %s]\n%s" % [ctx, user_text]}
	var msgs: Array = Persona.fewshot() + hist
	var fit: Dictionary = Llm.fit_prompt(Persona.build_system(), msgs, family)
	_amsg = Store.add_message("assistant", "")
	message_added.emit(_amsg)
	_full = ""
	_speak_buf = ""
	streaming = false
	Voice.begin_utterance_group()
	Llm.token.connect(_on_token)
	var info: Dictionary = await Llm.generate_wait(fit["prompt"], {"stop": Persona.stop_sequences(family)})
	Llm.token.disconnect(_on_token)
	streaming = false
	var final_text := String(info.get("text", _full)).strip_edges()
	var reason := String(info.get("reason", ""))
	if reason == "error" or reason == "prompt_too_long":
		var why := String(info.get("error", reason))
		if final_text == "":
			final_text = "Tive um problema ao gerar a resposta: %s" % why
		_flash_error()
	elif reason == "cancelled" and final_text == "":
		final_text = "(resposta interrompida)"
	_amsg["text"] = final_text
	message_updated.emit(_amsg)
	if Cfg.get_v("tts_enabled") and reason != "cancelled":
		if Cfg.get_v("speak_sentences"):
			if _speak_buf.strip_edges() != "":
				Voice.speak(_speak_buf, true)
		else:
			Voice.speak(final_text, false)
	_speak_buf = ""
	_refresh()

# ---------------- interpretacao por IA (JSON restrito por gramatica) ----------------
func _llm_route(t: String) -> Array:
	var grammar := U.read_text("res://data/grammar/plan.gbnf")
	if grammar == "":
		return []
	var family := Persona.family_for(Llm.model_name)
	var prompt := Persona.format_prompt(Persona.router_system(), [{"role": "user", "text": "Pedido: " + t}], family)
	var info: Dictionary = await Llm.generate_wait(prompt, {"grammar": grammar, "temperature": 0.0, "max_tokens": 160, "repeat_penalty": 1.0, "stop": []})
	if String(info.get("reason", "")) == "error":
		return []
	var p = JSON.parse_string(String(info.get("text", "")))
	if typeof(p) != TYPE_DICTIONARY or typeof(p.get("steps", null)) != TYPE_ARRAY:
		return []
	var out: Array = []
	for s in p["steps"]:
		if typeof(s) != TYPE_DICTIONARY or not ALLOWED_TOOLS.has(String(s.get("tool", ""))):
			return []
		var args: Dictionary = {}
		if typeof(s.get("args", null)) == TYPE_DICTIONARY:
			for k in s["args"]:
				args[String(k)] = s["args"][k] if typeof(s["args"][k]) != TYPE_STRING else String(s["args"][k]).substr(0, 300)
		out.append({"tool": s["tool"], "args": args})
	return out

# ---------------- execucao de planos (acoes no Android) ----------------
func _on_bridge_evt(ev: String, d: Dictionary) -> void:
	if ev != "plan_progress" or String(d.get("plan_id", "")) != _plan_id:
		return
	plan_step.emit(d)
	if String(d.get("data", "")) != "":
		_plan_data = String(d["data"])
	var st := String(d.get("status", ""))
	if int(d.get("step", 0)) >= int(d.get("total", 1)) and st in ["done", "failed", "blocked", "cancelled"]:
		_plan_final = d

func _run_plan(steps: Array, original: String) -> void:
	if not Cfg.get_v("tools_enabled"):
		say_local("As acoes no celular estao desativadas nas configuracoes.")
		return
	if not Bridge.available:
		say_local("Para controlar o Android preciso do plugin do Jarvis instalado no app.")
		return
	var ev: Dictionary = Safety.evaluate(steps)
	if not ev.get("ok", false):
		say_local("Nao consegui validar a acao: %s" % ev.get("error", "erro"))
		return
	if ev.get("blocked", false):
		say_local("Nao posso fazer isso: %s." % ", ".join(ev.get("blocked_reasons", ["bloqueado por seguranca"])))
		_flash_error()
		return
	var lines: Array = []
	var needs_acc := false
	for s in ev["steps"]:
		lines.append(("! " if s["level"] == "confirm" else "- ") + String(s["human"]))
		if ["click_text", "type_text", "scroll", "go_back", "recents", "notifications", "quick_settings", "read_screen"].has(s["tool"]):
			needs_acc = true
	if needs_acc and not ev.get("accessibility", false):
		say_local("Para isso preciso do servico de acessibilidade do Jarvis. Abra Configuracoes > Seguranca e permissoes e ative.")
		return
	if ev.get("needs_confirmation", false) or Cfg.get_v("confirm_all_actions"):
		var yes: bool = await Safety.ask("Confirmar acao", lines, "Executar", "Cancelar", ev.get("needs_confirmation", false))
		if not yes:
			say_local("Certo, cancelei.")
			return
	_plan_seq += 1
	_plan_id = "p%d_%d" % [Time.get_ticks_msec(), _plan_seq]
	_plan_final = {}
	_plan_data = ""
	var r = Bridge.api("plan_execute", [JSON.stringify({"plan_id": _plan_id, "steps": steps, "approved": true})])
	if typeof(r) != TYPE_DICTIONARY or not r.get("ok", false):
		say_local("Nao consegui iniciar a acao: %s" % (r.get("error", "erro") if typeof(r) == TYPE_DICTIONARY else "erro"))
		return
	acting = true
	_refresh()
	var t0 := Time.get_ticks_msec() / 1000.0
	while _plan_final.is_empty() and Time.get_ticks_msec() / 1000.0 - t0 < 120.0:
		await get_tree().create_timer(0.3).timeout
	acting = false
	_refresh()
	var st := String(_plan_final.get("status", "unknown"))
	var msg := String(_plan_final.get("message", ""))
	if st == "done":
		if _plan_data != "":
			var sc = JSON.parse_string(_plan_data)
			if typeof(sc) == TYPE_DICTIONARY and Llm.loaded:
				var items: Array = sc.get("items", [])
				await _chat("Descreva em poucas frases o que aparece na tela.", "Texto visivel na tela (lido com autorizacao, app %s): %s" % [sc.get("package", "?"), " | ".join(items)])
				return
		say_local("Pronto.")
	elif st == "unknown":
		say_local("Enviei a acao, mas nao recebi a confirmacao final. Verifique o aparelho.")
	else:
		say_local("%s" % (msg if msg != "" else "A acao nao foi concluida."))
		if st == "failed" or st == "blocked":
			_flash_error()
