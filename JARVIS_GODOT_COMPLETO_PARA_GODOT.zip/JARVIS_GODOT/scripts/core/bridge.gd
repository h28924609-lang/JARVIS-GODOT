extends Node
# Ponte Godot <-> plugin Android (Kotlin). Singleton "JarvisPlugin"; eventos chegam pelo sinal "jarvis_event".
# Sem o plugin (editor/PC) o app abre normalmente, mas SEM IA: nada e simulado.

const U = preload("res://scripts/core/util.gd")
signal evt(ev_name, data)
signal availability_changed()

var plugin = null
var available := false
var ping_info: Dictionary = {}
var device: Dictionary = {}
var _device_age := -100.0
var _signal_connected := false

# Estado da integracao (para mensagens reais de diagnostico, sem valores falsos):
#   env: "android_apk" (rodando como app Android), "editor" (Godot Editor) ou "desktop"
#   plugin_state: "loaded" | "missing_in_apk" | "not_android"
var env := "desktop"
var plugin_state := "not_android"

func _ready() -> void:
	detect()

# Detecta ambiente e plugin. Pode ser chamada de novo (ex.: botao "Verificar de novo" no Diagnostico).
func detect() -> void:
	if OS.has_feature("editor"):
		env = "editor"
	elif OS.has_feature("android"):
		env = "android_apk"
	else:
		env = "desktop"
	available = false
	plugin = null
	if Engine.has_singleton("JarvisPlugin"):
		plugin = Engine.get_singleton("JarvisPlugin")
		available = true
		plugin_state = "loaded"
		if not _signal_connected:
			plugin.connect("jarvis_event", _on_plugin_event)
			_signal_connected = true
		var r = ping("godot")
		if typeof(r) == TYPE_DICTIONARY:
			ping_info = r
		_device_age = -100.0
		refresh_device(0.0)
	elif env == "android_apk":
		plugin_state = "missing_in_apk"
		push_error("[Jarvis] APK Android SEM o plugin: o AAR nao foi incluido na exportacao (veja README, secao 'Gerar o AAR').")
	else:
		plugin_state = "not_android"
		push_warning("[Jarvis] Fora do Android (%s): sem plugin, sem IA/voz/controle do Android." % env)
	availability_changed.emit()

# Texto curto e verdadeiro sobre o estado do plugin, para telas e banners.
func status_text() -> String:
	match plugin_state:
		"loaded":
			return "Plugin Android carregado (v%s, motor llama.cpp: %s)." % [str(ping_info.get("plugin_version", "?")), "OK" if bool(ping_info.get("native_llm", false)) else "FALHOU: " + str(ping_info.get("native_error", "?"))]
		"missing_in_apk":
			return "Este APK foi exportado SEM o plugin Android (jarvis-debug.aar / jarvis-release.aar ausente em addons/jarvis_android/bin). Gere o AAR e exporte de novo."
		_:
			return "Executando fora do Android (%s): o plugin Android so existe no APK instalado." % env

func _on_plugin_event(ev_name: String, payload: String) -> void:
	var d = JSON.parse_string(payload)
	if typeof(d) != TYPE_DICTIONARY:
		d = {"raw": payload}
	evt.emit(ev_name, d)

# Chama um metodo do plugin e tenta interpretar o retorno JSON.
func api(method: String, args: Array = []):
	if not available:
		return {"ok": false, "error": "plugin_missing"}
	var r = plugin.callv(method, args)
	if typeof(r) == TYPE_STRING:
		var p = JSON.parse_string(r)
		if p != null:
			return p
	return r

func ping(echo: String):
	return api("ping", [echo])

func refresh_device(max_age: float = 4.0) -> Dictionary:
	var now := Time.get_ticks_msec() / 1000.0
	if now - _device_age >= max_age:
		_device_age = now
		if available:
			var r = api("get_device_status")
			if typeof(r) == TYPE_DICTIONARY and r.has("ram_total_mb"):
				device = r
				device["source"] = "plugin"
				return device
		device = native_device()
	return device

# Leitura direta pelo Godot (RAM e armazenamento reais do aparelho). Chaves ausentes = dado indisponivel (nunca 0 falso).
func native_device() -> Dictionary:
	var d := {"source": "godot", "online": false}
	var mem: Dictionary = OS.get_memory_info()
	var total := float(mem.get("physical", -1))
	var avail := float(mem.get("available", mem.get("free", -1)))
	if total > 0.0:
		d["ram_total_mb"] = int(total / 1048576.0)
	if avail > 0.0:
		d["ram_avail_mb"] = int(avail / 1048576.0)
	var da := DirAccess.open("user://")
	if da != null:
		var left := float(da.get_space_left())
		if left > 0.0:
			d["storage_free_mb"] = int(left / 1048576.0)
	d["cores"] = OS.get_processor_count()
	d["device"] = OS.get_model_name()
	return d

func is_online() -> bool:
	return bool(refresh_device(6.0).get("online", false))

func has_permission(name: String) -> bool:
	if not available:
		return false
	return bool(plugin.has_permission(name))

func request_permissions(names: Array) -> void:
	if available:
		plugin.request_permissions(JSON.stringify(names))
