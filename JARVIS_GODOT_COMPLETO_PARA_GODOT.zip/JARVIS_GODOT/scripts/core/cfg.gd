extends Node
# Configuracoes persistentes (user://settings.json). Acesso: Cfg.get_v("chave") / Cfg.set_v("chave", valor).

const U = preload("res://scripts/core/util.gd")
signal changed(key)

const PATH := "user://settings.json"
const DEFAULTS := {
	"assistant_name": "Jarvis", "user_name": "", "formality": "voce", "response_len": "media", "custom_instructions": "",
	"model_id": "qwen2.5-1.5b-q4", "model_file": "", "model_family": "chatml", "model_auto_load": true,
	"n_ctx": 3072, "threads": 4, "temperature": 0.7, "top_p": 0.9, "top_k": 40, "min_p": 0.05, "repeat_penalty": 1.1,
	"max_tokens": 320, "idle_unload_min": 10, "thermal_guard": true, "eco_mode": true, "custom_models": [],
	"tts_enabled": true, "tts_voice": "", "tts_rate": 1.0, "tts_pitch": 1.0, "tts_volume": 1.0, "speak_sentences": true,
	"stt_engine": "android", "stt_prefer_offline": true, "stt_on_device_only": false, "auto_send_voice": true,
	"continuous_conversation": false, "wake_enabled": false, "wake_background": false, "keep_screen_on": false,
	"memory_enabled": true, "memory_ask_before_save": false, "save_history": true,
	"tools_enabled": true, "confirm_all_actions": false, "blocked_extra": [],
	"internet_enabled": false, "internet_wikipedia": false, "internet_weather": false, "internet_always_ask": true,
	"first_run_done": false
}

var data: Dictionary = {}
var _dirty := false

func _ready() -> void:
	load_file()

func load_file() -> void:
	data = DEFAULTS.duplicate(true)
	var p = U.read_json(PATH, {})
	if typeof(p) == TYPE_DICTIONARY:
		for k in p:
			data[k] = p[k]

func get_v(key: String):
	return data.get(key, DEFAULTS.get(key))

func set_v(key: String, value) -> void:
	if data.has(key) and data[key] == value:
		return
	data[key] = value
	changed.emit(key)
	_schedule_save()

func _schedule_save() -> void:
	if _dirty:
		return
	_dirty = true
	get_tree().create_timer(0.6).timeout.connect(_flush)

func _flush() -> void:
	_dirty = false
	save_now()

func save_now() -> void:
	U.write_json(PATH, data)

func reset_all() -> void:
	data = DEFAULTS.duplicate(true)
	save_now()
	changed.emit("*")
