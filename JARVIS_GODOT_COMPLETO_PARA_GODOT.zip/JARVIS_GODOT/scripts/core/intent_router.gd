extends RefCounted
# Roteador de intencoes por regras (PT-BR) para comandos DIRETOS e inequivocos: rapido, sem custo de IA.
# Pedidos ambiguos sao interpretados pelo proprio modelo (JSON restrito por gramatica GBNF) no Agent.
# Retorna {"kind": "chat"} quando nao reconhece um comando.

const U = preload("res://scripts/core/util.gd")

static var _cache: Dictionary = {}

static func _re(p: String) -> RegEx:
	if not _cache.has(p):
		_cache[p] = RegEx.create_from_string(p)
	return _cache[p]

static func _rx(n: String, p: String) -> RegExMatch:
	return _re(p).search(n)

static func _cap(t: String, m: RegExMatch, name: String) -> String:
	var s: int = m.get_start(name)
	if s < 0:
		return ""
	var e: int = m.get_end(name)
	var out := t.substr(s, e - s).strip_edges()
	while out.length() > 0 and ".,!?;:".contains(out[out.length() - 1]):
		out = out.substr(0, out.length() - 1)
	return out.strip_edges()

const COMMAND_VERBS := ["abra", "abre", "abrir", "inicie", "iniciar", "execute", "volte", "volta", "voltar", "va", "vai", "ir",
	"clique", "clica", "toque", "toca", "aperte", "pressione", "digite", "escreva", "role", "rola", "desca", "suba", "sobe",
	"mande", "manda", "envie", "envia", "pesquise", "busque", "procure", "mostre", "mostra", "ligue", "desligue", "ative",
	"desative", "feche", "fecha", "leia", "le", "compartilhe", "grave", "entre", "acesse", "troque", "alterne", "lance"]

static func looks_like_command(text: String) -> bool:
	var w: PackedStringArray = U.norm(text).split(" ", false)
	return w.size() > 0 and COMMAND_VERBS.has(w[0])

static func parse(text: String) -> Dictionary:
	var t := text.strip_edges()
	var n := U.norm_len(t)
	var nn := U.norm(t)
	if nn == "":
		return {"kind": "chat"}

	if _rx(nn, "^(para|pare|parar|chega|silencio|cala a boca|calado|cancela|cancele|cancelar)( de falar| tudo| isso)?$") != null:
		return {"kind": "stop"}
	if _rx(nn, "^(repete|repita|repetir|fala de novo|fale de novo|diz de novo|diga de novo)") != null:
		return {"kind": "repeat"}

	var m := _rx(n, "^\\s*(lembre|lembra|lembrar|anote|anota|guarde|guarda|memorize|salve)( ai| isso| na memoria)?( que| de que|:)?\\s+(?<t>.+)$")
	if m != null:
		return {"kind": "memory_add", "text": _cap(t, m, "t")}
	m = _rx(n, "^\\s*(esqueca|esquece|esquecer)( da memoria)?( que| sobre| o que| isso:?)?\\s+(?<t>.+)$")
	if m != null:
		return {"kind": "memory_forget", "query": _cap(t, m, "t")}
	if _rx(nn, "(o que voce (sabe|lembra) (sobre|de) mim|minhas memorias|mostre a memoria|listar memorias|o que voce guardou)") != null:
		return {"kind": "memory_list"}

	if _rx(nn, "(aumente|aumentar|suba|subir) (o )?volume") != null:
		return {"kind": "volume", "delta": 15}
	if _rx(nn, "(diminua|diminuir|abaixe|abaixar|baixe|baixar) (o )?volume") != null:
		return {"kind": "volume", "delta": -15}
	m = _rx(nn, "volume (em|para|no|a) (?<v>\\d{1,3})")
	if m != null:
		return {"kind": "volume", "set": clampi(int(m.get_string("v")), 0, 100)}

	if _rx(nn, "^(que horas sao|que hora e|me diga as horas|me diz as horas|horas)( agora)?$") != null:
		return {"kind": "time"}
	if _rx(nn, "^(que dia e hoje|qual e a data|qual a data|data de hoje|que data e hoje)") != null:
		return {"kind": "date"}

	m = _rx(n, "^\\s*(pesquis[ae]r?|busque|buscar|procure|procurar|consulte)\\s+(na|no)\\s+wikipedia\\s+(sobre\\s+|por\\s+)?(?<q>.+)$")
	if m != null:
		return {"kind": "wikipedia", "query": _cap(t, m, "q")}
	m = _rx(n, "(previsao do tempo|clima|temperatura|o tempo)\\s+(em|para|de|na|no)\\s+(?<c>[^?]+)")
	if m != null:
		return {"kind": "weather", "city": _cap(t, m, "c")}

	var plan := _parse_sequence(t, n)
	if not plan.is_empty():
		return {"kind": "plan", "steps": plan}
	return {"kind": "chat"}

static func _parse_sequence(t: String, n: String) -> Array:
	var conn := _re("\\s+(e depois|e entao|e em seguida|depois|entao|em seguida|e)\\s+(?=(abr|vol|clic|toqu|apert|digit|escrev|role|rol|desc|sub|sob|mand|envi|pesquis|va |vai |ir |entr|acess|feche|fech|mostr))")
	var cuts: Array = []
	var last := 0
	for mt in conn.search_all(n):
		cuts.append([last, mt.get_start()])
		last = mt.get_end()
	cuts.append([last, n.length()])
	if cuts.size() > 1:
		var steps: Array = []
		var ok := true
		for c in cuts:
			var piece_t: String = t.substr(c[0], c[1] - c[0])
			var piece_n: String = n.substr(c[0], c[1] - c[0])
			var one := _parse_one(piece_t, piece_n)
			if one.is_empty():
				ok = false
				break
			steps.append_array(one)
		if ok and steps.size() <= 8:
			return steps
	return _parse_one(t, n)

static func _settings_section(s: String) -> String:
	var x := U.norm(s)
	if x.contains("wi") or x.contains("internet") or x.contains("rede"):
		return "wifi"
	if x.contains("bluetooth"):
		return "bluetooth"
	if x.contains("tela") or x.contains("brilho"):
		return "tela"
	if x.contains("som") or x.contains("volume") or x.contains("audio"):
		return "som"
	if x.contains("bateria"):
		return "bateria"
	if x.contains("app") or x.contains("aplicativo"):
		return "apps"
	if x.contains("acessib"):
		return "acessibilidade"
	if x.contains("armazen") or x.contains("memoria"):
		return "armazenamento"
	if x.contains("data") or x.contains("hora"):
		return "data"
	if x.contains("idioma") or x.contains("lingua"):
		return "idioma"
	if x.contains("local"):
		return "localizacao"
	if x.contains("avi"):
		return "aviao"
	return "principal"

static func _fix_url(u: String) -> String:
	var x := u.strip_edges()
	if x.begins_with("http://") or x.begins_with("https://"):
		return x
	return "https://" + x

# Retorna lista de passos ([] se nao reconhecer).
static func _parse_one(t: String, n: String) -> Array:
	var m: RegExMatch
	m = _rx(n, "^\\s*(abr[ae]r?|mostr[ae]r?|va para|vai para|ir para)\\s+(as\\s+|a\\s+|o\\s+)?(configuracoes?|ajustes|config)(\\s+(de|do|da|dos|das)\\s+(?<s>.+))?\\s*$")
	if m != null:
		return [{"tool": "open_settings", "args": {"section": _settings_section(m.get_string("s"))}}]
	if _rx(n, "^\\s*(volt[ae]r?|va|vai|ir)?\\s*(para|pra|a|ao)?\\s*(a\\s+)?(tela inicial|inicio|home)\\s*$") != null:
		return [{"tool": "go_home"}]
	if _rx(n, "^\\s*(volt[ae]r?|retroced[ae]r?)(\\s+uma\\s+tela|\\s+atras|\\s+a\\s+tela\\s+anterior)?\\s*$") != null:
		return [{"tool": "go_back"}]
	if _rx(n, "(apps recentes|aplicativos recentes|alternar (entre )?apps|trocar de app)") != null:
		return [{"tool": "recents"}]
	if _rx(n, "^\\s*(abr[ae]r?|mostr[ae]r?|ver)\\s+(as\\s+)?notificacoes") != null:
		return [{"tool": "notifications"}]
	if _rx(n, "^\\s*(role|rolar|rola|desca|descer|sobe|suba|subir)\\b") != null:
		var up: bool = n.contains("cima") or _rx(n, "^\\s*(sobe|suba|subir)") != null
		return [{"tool": "scroll", "args": {"direction": "up" if up else "down"}}]
	m = _rx(n, "^\\s*(clique|clica|clicar|toque|toca|tocar|aperte|aperta|apertar|pressione|selecione)\\s+(no|na|em|sobre|nos|nas)?\\s*(botao|item|opcao|aba|icone)?\\s*(de\\s+|do\\s+|da\\s+)?(?<x>.+)$")
	if m != null:
		return [{"tool": "click_text", "args": {"text": _cap(t, m, "x")}}]
	m = _rx(n, "^\\s*(digite|digita|digitar|escreva|escreve|escrever)\\s+(?<x>.+)$")
	if m != null:
		return [{"tool": "type_text", "args": {"text": _cap(t, m, "x")}}]
	if _rx(n, "(o que (tem|esta|aparece|ha) na tela|ler a tela|leia a tela|descreva a tela|le a tela)") != null:
		return [{"tool": "read_screen"}]
	m = _rx(n, "^\\s*(abr[ae]r?|va para|vai para|entre em|acesse)\\s+(o\\s+)?(site|pagina|endereco)\\s+(?<u>\\S+)")
	if m != null:
		return [{"tool": "open_url", "args": {"url": _fix_url(_cap(t, m, "u"))}}]
	m = _rx(n, "^\\s*(pesquis[ae]r?|busque|buscar|procure|procurar)\\s+(no\\s+google|na\\s+internet|no\\s+navegador)\\s+(por\\s+|sobre\\s+)?(?<q>.+)$")
	if m != null:
		return [{"tool": "open_url", "args": {"url": "https://www.google.com/search?q=" + _cap(t, m, "q").uri_encode()}}]
	m = _rx(n, "^\\s*(mand[ae]r?|envi[ae]r?)\\s+(uma\\s+|um\\s+)?(?<v>mensagem|msg|zap|whats|whatsapp|sms)(\\s+(no|pelo|via|por)\\s+(?<c>whatsapp|zap|sms|email))?(\\s+(para|pro|pra)\\s+(?<d>.+?))?\\s+(dizendo|falando|escrevendo|com o texto|que diz|:)\\s*(?<x>.+)$")
	if m != null:
		var ch_word := m.get_string("c") if m.get_string("c") != "" else m.get_string("v")
		var channel := "whatsapp" if (ch_word.contains("zap") or ch_word.contains("whats")) else ("email" if ch_word == "email" else "sms")
		var dest := _cap(t, m, "d")
		var digits := ""
		for ch in dest:
			if ch.is_valid_int() or ch == "+":
				digits += ch
		return [{"tool": "compose_message", "args": {"channel": channel, "to": digits, "text": _cap(t, m, "x")}}]
	m = _rx(n, "^\\s*(abr[ae]r?|inici[ae]r?|execut[ae]r?|lanc[ae]r?|va para|vai para|ir para|entre no|entra no)\\s+(o\\s+|a\\s+|os\\s+|as\\s+|no\\s+|na\\s+|meu\\s+|minha\\s+)?(app\\s+|aplicativo\\s+|programa\\s+)?(?<a>.+)$")
	if m != null:
		return [{"tool": "open_app", "args": {"name": _cap(t, m, "a")}}]
	return []
