extends Node
# Cliente do motor de IA local (llama.cpp via plugin Kotlin). Gerencia carga/descarga, geracao em streaming,
# cancelamento, orcamento de contexto, liberacao por inatividade e protecao termica.

signal state_changed()
signal token(req_id, text)
signal generation_done(req_id, info)
signal import_changed()

var loaded := false
var loading := false
var generating := false
var model_name := ""
var last_error := ""
var n_ctx := 0
var last_stats: Dictionary = {}
var unclean_exit := ""
# Importacao do arquivo GGUF (seletor de arquivos ou pasta externa do app)
var importing := false
var import_state: Dictionary = {}
var _autoload_after_import := true

var _seq := 0
var _active := ""
var _last_activity := 0.0
var _check_acc := 0.0
var _thermal_acc := 0.0
var _load_started_ms := 0

func _ready() -> void:
	Bridge.evt.connect(_on_evt)
	_last_activity = Time.get_ticks_msec() / 1000.0
	if Bridge.available:
		refresh()

func refresh() -> void:
	var r = Bridge.api("llm_status")
	if typeof(r) == TYPE_DICTIONARY and r.get("ok", false):
		loaded = bool(r.get("loaded", false))
		loading = bool(r.get("loading", false))
		model_name = String(r.get("model", ""))
		n_ctx = int(r.get("n_ctx", 0))
		unclean_exit = String(r.get("unclean_exit", ""))
		last_error = String(r.get("last_error", ""))
		state_changed.emit()

func touch() -> void:
	_last_activity = Time.get_ticks_msec() / 1000.0

func _on_evt(ev: String, d: Dictionary) -> void:
	match ev:
		"llm_load":
			var st := String(d.get("state", ""))
			if st == "loading":
				loading = true
			elif st == "ready":
				loading = false
				loaded = true
				model_name = String(d.get("model", ""))
				n_ctx = int(d.get("n_ctx", Cfg.get_v("n_ctx")))
				last_error = ""
				touch()
				_notify("Modelo %s carregado e pronto (100%% offline)." % model_name, "info")
			elif st == "error":
				loading = false
				loaded = false
				last_error = String(d.get("error", "erro desconhecido"))
				_notify("Nao consegui carregar o modelo: %s" % last_error, "error")
			elif st == "unloaded":
				loaded = false
				model_name = ""
			state_changed.emit()
		"llm_token":
			if String(d.get("id", "")) == _active:
				token.emit(_active, String(d.get("text", "")))
		"llm_done":
			var id := String(d.get("id", ""))
			if id == _active:
				generating = false
				_active = ""
				last_stats = d.get("stats", {})
				touch()
				if Bridge.available:
					Bridge.plugin.llm_set_throttle(0)
				generation_done.emit(id, d)
				state_changed.emit()
		"model_import":
			_on_import_event(d)
		"memory_trim":
			loaded = false
			model_name = ""
			last_error = "Modelo descarregado: o Android pediu memoria."
			state_changed.emit()

func load_model(filename: String) -> bool:
	if not Bridge.available:
		last_error = "Plugin Android ausente."
		state_changed.emit()
		return false
	var params := {"n_ctx": int(Cfg.get_v("n_ctx")), "threads": int(Cfg.get_v("threads")), "n_batch": 256, "mmap": true}
	var r = Bridge.api("llm_load", [filename, JSON.stringify(params)])
	if typeof(r) == TYPE_DICTIONARY and r.get("ok", false):
		loading = true
		last_error = ""
		state_changed.emit()
		return true
	last_error = "Falha ao iniciar carga: %s" % str(r.get("error", "?") if typeof(r) == TYPE_DICTIONARY else r)
	state_changed.emit()
	return false

func unload() -> void:
	if Bridge.available:
		Bridge.api("llm_unload")

func cancel() -> void:
	if Bridge.available and generating:
		Bridge.api("llm_cancel")

func count_tokens(text: String) -> int:
	if Bridge.available and loaded:
		var n: int = int(Bridge.plugin.llm_count_tokens(text))
		if n >= 0:
			return n
	return int(ceil(text.length() / 3.3))

# Ajusta o historico ao orcamento de contexto, descartando as mensagens mais antigas.
func fit_prompt(system: String, msgs: Array, family: String) -> Dictionary:
	var budget: int = int(n_ctx if n_ctx > 0 else Cfg.get_v("n_ctx")) - int(Cfg.get_v("max_tokens")) - 48
	var m: Array = msgs.duplicate()
	var dropped := 0
	var p := ""
	var n := 0
	while true:
		p = Persona.format_prompt(system, m, family)
		n = count_tokens(p)
		if n <= budget or m.size() <= 1:
			break
		m.pop_front()
		dropped += 1
	return {"prompt": p, "tokens": n, "dropped": dropped}

func default_opts() -> Dictionary:
	return {
		"max_tokens": int(Cfg.get_v("max_tokens")), "temperature": float(Cfg.get_v("temperature")),
		"top_p": float(Cfg.get_v("top_p")), "top_k": int(Cfg.get_v("top_k")), "min_p": float(Cfg.get_v("min_p")),
		"repeat_penalty": float(Cfg.get_v("repeat_penalty")), "stop": []
	}

# Inicia uma geracao; retorna o id. O resultado chega por token(...) e generation_done(...).
func generate(prompt: String, opts: Dictionary = {}) -> String:
	_seq += 1
	var id := "g%d" % _seq
	var req := default_opts()
	for k in opts:
		req[k] = opts[k]
	req["id"] = id
	req["prompt"] = prompt
	if not loaded:
		_fail_later(id, "Modelo nao carregado.")
		return id
	var r = Bridge.api("llm_generate", [JSON.stringify(req)])
	if typeof(r) == TYPE_DICTIONARY and r.get("ok", false):
		_active = id
		generating = true
		touch()
		state_changed.emit()
	else:
		_fail_later(id, "Falha ao iniciar geracao: %s" % str(r.get("error", "?") if typeof(r) == TYPE_DICTIONARY else r))
	return id

func _fail_later(id: String, msg: String) -> void:
	last_error = msg
	await get_tree().process_frame
	generation_done.emit(id, {"id": id, "reason": "error", "error": msg, "text": ""})

# Atalho aguardavel: retorna o dicionario "info" final.
func generate_wait(prompt: String, opts: Dictionary = {}) -> Dictionary:
	var id := generate(prompt, opts)
	while true:
		var r = await generation_done
		if r[0] == id:
			return r[1]
	return {}

func _process(delta: float) -> void:
	if not Bridge.available:
		return
	_check_acc += delta
	if _check_acc >= 20.0:
		_check_acc = 0.0
		var idle_min: float = float(Cfg.get_v("idle_unload_min"))
		var now := Time.get_ticks_msec() / 1000.0
		if loaded and not generating and idle_min > 0.0 and now - _last_activity > idle_min * 60.0:
			unload()
	if generating and Cfg.get_v("thermal_guard"):
		_thermal_acc += delta
		if _thermal_acc >= 4.0:
			_thermal_acc = 0.0
			var dev := Bridge.refresh_device(3.0)
			var th: int = int(dev.get("thermal", -1))
			if th >= 4:
				cancel()
			elif th >= 3:
				Bridge.plugin.llm_set_throttle(120)
			elif th >= 2:
				Bridge.plugin.llm_set_throttle(40)
			else:
				Bridge.plugin.llm_set_throttle(0)


# ---------------- localizar / importar o arquivo GGUF ----------------
func _notify(text: String, kind: String) -> void:
	if is_instance_valid(Agent):
		Agent.notice.emit(text, kind)

# Abre o seletor de arquivos do Android. O resultado chega pelo evento "model_import".
func pick_file() -> bool:
	if not Bridge.available:
		last_error = "Plugin Android ausente."
		state_changed.emit()
		return false
	var r = Bridge.api("llm_pick_model_file")
	if typeof(r) == TYPE_DICTIONARY and r.get("ok", false):
		_autoload_after_import = true
		return true
	last_error = "Nao foi possivel abrir o seletor de arquivos: %s" % str(r.get("detail", r.get("error", "?")) if typeof(r) == TYPE_DICTIONARY else r)
	state_changed.emit()
	return false

# Retorna {"dir": String, "found": Array} com os .gguf da pasta externa "models" do app.
func scan_external() -> Dictionary:
	if not Bridge.available:
		return {"dir": "", "found": []}
	var r = Bridge.api("llm_scan_external")
	if typeof(r) == TYPE_DICTIONARY and r.get("ok", false):
		return {"dir": String(r.get("dir", "")), "found": r.get("found", [])}
	return {"dir": "", "found": []}

func import_external(name: String, delete_source: bool = false) -> bool:
	if not Bridge.available:
		return false
	_autoload_after_import = true
	Bridge.api("llm_import_external", [name, delete_source])
	return true

func cancel_import() -> void:
	if Bridge.available:
		Bridge.api("llm_import_cancel")

func _on_import_event(d: Dictionary) -> void:
	import_state = d
	var st := String(d.get("state", ""))
	importing = (st == "copying")
	if st == "done":
		var fn := String(d.get("name", ""))
		_notify("Modelo %s copiado para o armazenamento do app." % fn, "info")
		if _autoload_after_import and not loaded and not loading and fn != "":
			Cfg.set_v("model_file", fn)
			Cfg.set_v("model_family", Persona.family_for(fn))
			load_model(fn)
	elif st == "error":
		last_error = "Importacao do modelo falhou: %s %s" % [String(d.get("error", "")), String(d.get("detail", ""))]
		_notify(last_error, "error")
	import_changed.emit()
	state_changed.emit()

# Escolhe e carrega um modelo sem intervencao: (1) o configurado, (2) qualquer GGUF ja no armazenamento do app
# (preferindo Qwen2.5 1.5B), (3) GGUF na pasta externa "models" do app, que e copiado para o armazenamento privado.
# Retorna "loading", "importing" ou "none" (nenhum arquivo encontrado: o usuario deve selecionar o GGUF).
func auto_prepare() -> String:
	if not Bridge.available or loaded or loading:
		return "loading" if loading else ("none" if not Bridge.available else "ready")
	var names: Array = []
	var r = Bridge.api("llm_list_models")
	if typeof(r) == TYPE_DICTIONARY:
		for m in r.get("models", []):
			if not m.get("partial", false):
				names.append(String(m.get("name", "")))
	var want := String(Cfg.get_v("model_file"))
	if want == "" or not names.has(want):
		want = ""
		for n in names:
			if n.to_lower().contains("qwen2.5-1.5b"):
				want = n
				break
		if want == "" and not names.is_empty():
			want = String(names[0])
	if want != "":
		Cfg.set_v("model_file", want)
		Cfg.set_v("model_family", Persona.family_for(want))
		return "loading" if load_model(want) else "none"
	var ext := scan_external()
	var found: Array = ext["found"]
	if not found.is_empty():
		var pick := String(found[0].get("name", ""))
		for f in found:
			if String(f.get("name", "")).to_lower().contains("qwen2.5-1.5b"):
				pick = String(f.get("name", ""))
				break
		_notify("Encontrei %s na pasta models do app. Copiando para o armazenamento privado..." % pick, "info")
		return "importing" if import_external(pick, false) else "none"
	return "none"
