extends Node
# Internet OPCIONAL: so consultas explicitas e autorizadas (Wikipedia pt e Open-Meteo, ambos gratuitos e sem chave).
# Nunca envia o historico da conversa: apenas o termo pesquisado, e somente apos autorizacao.

const WEATHER_CODES := {
	0: "ceu limpo", 1: "predominantemente limpo", 2: "parcialmente nublado", 3: "nublado", 45: "neblina", 48: "neblina com geada",
	51: "garoa fraca", 53: "garoa", 55: "garoa forte", 61: "chuva fraca", 63: "chuva", 65: "chuva forte",
	80: "pancadas de chuva fracas", 81: "pancadas de chuva", 82: "pancadas de chuva fortes", 95: "trovoadas", 96: "trovoadas com granizo", 99: "trovoadas fortes"
}

func allowed(provider: String) -> bool:
	if not Cfg.get_v("internet_enabled"):
		return false
	if provider == "wikipedia":
		return bool(Cfg.get_v("internet_wikipedia"))
	if provider == "weather":
		return bool(Cfg.get_v("internet_weather"))
	return false

func authorize(provider: String, detail: String) -> bool:
	if not allowed(provider):
		return false
	if not Cfg.get_v("internet_always_ask"):
		return true
	var host := "pt.wikipedia.org" if provider == "wikipedia" else "open-meteo.com"
	return await Safety.ask("Consulta na internet", ["Enviar apenas este termo para %s:" % host, "\"%s\"" % detail, "Sua conversa nao sera enviada."], "Permitir", "Negar")

func _get_json(url: String):
	var req := HTTPRequest.new()
	req.timeout = 12.0
	add_child(req)
	var err := req.request(url, PackedStringArray(["User-Agent: JarvisAssistant/1.0 (uso pessoal)", "Accept: application/json"]))
	if err != OK:
		req.queue_free()
		return null
	var res = await req.request_completed
	req.queue_free()
	if res[0] != HTTPRequest.RESULT_SUCCESS or res[1] != 200:
		return null
	return JSON.parse_string((res[3] as PackedByteArray).get_string_from_utf8())

func wikipedia(query: String) -> Dictionary:
	var s = await _get_json("https://pt.wikipedia.org/w/api.php?action=query&list=search&srsearch=%s&format=json&srlimit=1&utf8=1" % query.uri_encode())
	if typeof(s) != TYPE_DICTIONARY:
		return {"ok": false, "error": "Sem resposta da Wikipedia."}
	var hits: Array = s.get("query", {}).get("search", [])
	if hits.is_empty():
		return {"ok": false, "error": "Nada encontrado na Wikipedia sobre isso."}
	var title: String = hits[0]["title"]
	var sum = await _get_json("https://pt.wikipedia.org/api/rest_v1/page/summary/%s" % title.replace(" ", "_").uri_encode())
	if typeof(sum) != TYPE_DICTIONARY:
		return {"ok": false, "error": "Nao consegui ler o resumo."}
	return {"ok": true, "title": title, "extract": String(sum.get("extract", "")), "source": "Wikipedia (pt)"}

func weather(city: String) -> Dictionary:
	var g = await _get_json("https://geocoding-api.open-meteo.com/v1/search?name=%s&count=1&language=pt&format=json" % city.uri_encode())
	if typeof(g) != TYPE_DICTIONARY or not g.has("results") or g["results"].is_empty():
		return {"ok": false, "error": "Nao encontrei a cidade \"%s\"." % city}
	var p: Dictionary = g["results"][0]
	var url := "https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=1" % [str(p["latitude"]), str(p["longitude"])]
	var w = await _get_json(url)
	if typeof(w) != TYPE_DICTIONARY or not w.has("current"):
		return {"ok": false, "error": "Sem resposta do servico de clima."}
	var c: Dictionary = w["current"]
	var dly: Dictionary = w.get("daily", {})
	var desc: String = WEATHER_CODES.get(int(c.get("weather_code", -1)), "tempo variavel")
	var text := "Em %s agora: %s, %.0f graus (sensacao de %.0f). Maxima de %.0f e minima de %.0f hoje" % [
		String(p.get("name", city)), desc, float(c.get("temperature_2m", 0)), float(c.get("apparent_temperature", 0)),
		float(dly.get("temperature_2m_max", [0])[0]), float(dly.get("temperature_2m_min", [0])[0])]
	var pp = dly.get("precipitation_probability_max", [null])[0]
	if pp != null:
		text += ", chance de chuva de %d por cento" % int(pp)
	return {"ok": true, "text": text + ".", "source": "Open-Meteo"}
