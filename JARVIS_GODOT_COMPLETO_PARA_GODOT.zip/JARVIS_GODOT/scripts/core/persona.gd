extends Node
# Personalidade do assistente (independente do modelo) + adaptadores de template de chat por familia de modelo.

const U = preload("res://scripts/core/util.gd")

var persona: Dictionary = {}
var catalog: Array = []

func _ready() -> void:
	reload()

func reload() -> void:
	var p = U.read_json("res://data/persona/jarvis_persona.json", {})
	persona = p if typeof(p) == TYPE_DICTIONARY else {}
	var override = U.read_json("user://persona_override.json", {})
	if typeof(override) == TYPE_DICTIONARY:
		for k in override:
			persona[k] = override[k]
	var cat = U.read_json("res://data/models.json", {})
	catalog = cat.get("models", []) if typeof(cat) == TYPE_DICTIONARY else []

func assistant_name() -> String:
	var n := String(Cfg.get_v("assistant_name")).strip_edges()
	return n if n != "" else "Jarvis"

func user_name() -> String:
	return String(Cfg.get_v("user_name")).strip_edges()

# Prompt de sistema ESTAVEL entre turnos (mantem o cache de prefixo do KV). Contexto variavel vai na mensagem do usuario.
func build_system() -> String:
	var lines: Array = []
	var who := user_name()
	var ident := String(persona.get("identity", "Voce e {assistant}, um assistente pessoal."))
	ident = ident.replace("{assistant}", assistant_name()).replace("{user}", who if who != "" else "seu usuario")
	lines.append(ident)
	for s in persona.get("style", []):
		lines.append("- " + String(s))
	lines.append(String(persona.get("capabilities", "")))
	lines.append(String(persona.get("formality", {}).get(Cfg.get_v("formality"), "")))
	lines.append(String(persona.get("length", {}).get(Cfg.get_v("response_len"), "")))
	var custom := String(Cfg.get_v("custom_instructions")).strip_edges()
	if custom != "":
		lines.append("Instrucoes do usuario: " + custom)
	var d := Time.get_date_dict_from_system()
	lines.append("Data de hoje: %02d/%02d/%04d." % [d["day"], d["month"], d["year"]])
	return "\n".join(lines.filter(func(x): return String(x) != ""))

func fewshot() -> Array:
	var out: Array = []
	for ex in persona.get("fewshot", []):
		out.append({"role": "user", "text": ex["u"]})
		out.append({"role": "assistant", "text": ex["a"]})
	return out

func router_system() -> String:
	return "\n".join(persona.get("router", []))

func family_for(filename: String) -> String:
	for m in catalog:
		if m.get("filename", "") == filename:
			return String(m.get("family", "chatml"))
	for m in Cfg.get_v("custom_models"):
		if typeof(m) == TYPE_DICTIONARY and m.get("filename", "") == filename:
			return String(m.get("family", "chatml"))
	var f := filename.to_lower()
	if f.contains("llama-3") or f.contains("llama3"):
		return "llama3"
	if f.contains("gemma"):
		return "gemma"
	return "chatml"

func stop_sequences(family: String) -> Array:
	match family:
		"llama3":
			return ["<|eot_id|>", "\nUsuario:"]
		"gemma":
			return ["<end_of_turn>", "\nUsuario:"]
		_:
			return ["<|im_end|>", "<|im_start|>", "\nUsuario:"]

# msgs: [{role: "user"|"assistant", text}] ; termina abrindo o turno do assistente.
func format_prompt(system: String, msgs: Array, family: String) -> String:
	var s := ""
	match family:
		"llama3":
			s = "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n%s<|eot_id|>" % system
			for m in msgs:
				s += "<|start_header_id|>%s<|end_header_id|>\n\n%s<|eot_id|>" % [m["role"], m["text"]]
			s += "<|start_header_id|>assistant<|end_header_id|>\n\n"
		"gemma":
			s = "<bos>"
			var first := true
			for m in msgs:
				var role: String = "user" if m["role"] == "user" else "model"
				var text: String = m["text"]
				if first and role == "user":
					text = system + "\n\n" + text
					first = false
				s += "<start_of_turn>%s\n%s<end_of_turn>\n" % [role, text]
			s += "<start_of_turn>model\n"
		_:
			s = "<|im_start|>system\n%s<|im_end|>\n" % system
			for m in msgs:
				s += "<|im_start|>%s\n%s<|im_end|>\n" % [m["role"], m["text"]]
			s += "<|im_start|>assistant\n"
	return s
