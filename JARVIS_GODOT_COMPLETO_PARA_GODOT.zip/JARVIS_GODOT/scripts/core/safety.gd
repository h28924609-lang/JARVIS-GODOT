extends Node
# Camada de seguranca do lado Godot: avaliacao de planos (politica unica no Kotlin) e dialogos de confirmacao.
# O modelo NUNCA executa comandos: ele so propoe passos estruturados, que passam por validacao + confirmacao.

signal confirm_requested(req)
signal _answered(id, yes)

var _seq := 0

func evaluate(steps: Array) -> Dictionary:
	if not Bridge.available:
		return {"ok": false, "error": "plugin_missing"}
	var r = Bridge.api("plan_evaluate", [JSON.stringify(steps)])
	return r if typeof(r) == TYPE_DICTIONARY else {"ok": false, "error": "invalid_response"}

# Mostra um dialogo (na tela principal) e aguarda a resposta. lines: Array de textos. Retorna true se confirmou.
func ask(title: String, lines: Array, confirm_text: String = "Confirmar", cancel_text: String = "Cancelar", danger: bool = false) -> bool:
	_seq += 1
	var id := _seq
	confirm_requested.emit({"id": id, "title": title, "lines": lines, "confirm": confirm_text, "cancel": cancel_text, "danger": danger})
	while true:
		var r = await _answered
		if r[0] == id:
			return bool(r[1])
	return false

func answer(id: int, yes: bool) -> void:
	_answered.emit(id, yes)
