extends Node
# Historico de conversas e memoria local do usuario (tudo em user://, nada sai do aparelho).
# Memoria != treinamento do modelo: sao fatos textuais que o usuario autoriza e que podem ser consultados, editados e apagados.

const U = preload("res://scripts/core/util.gd")
signal conversation_changed()
signal memory_changed()

const HIST_DIR := "user://history"
const INDEX_PATH := "user://history/index.json"
const MEM_PATH := "user://memory.json"
const CATEGORIES := ["preferencia", "pessoa", "rotina", "fato", "outro"]

var current: Dictionary = {}
var memories: Array = []
var _index: Array = []

func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(HIST_DIR)
	var idx = U.read_json(INDEX_PATH, [])
	_index = idx if typeof(idx) == TYPE_ARRAY else []
	var m = U.read_json(MEM_PATH, {})
	if typeof(m) == TYPE_DICTIONARY and m.has("items") and typeof(m["items"]) == TYPE_ARRAY:
		memories = m["items"]
	new_conversation()

func _new_id() -> String:
	return "%d_%04d" % [int(Time.get_unix_time_from_system()), randi() % 10000]

# ---------------- conversas ----------------
func new_conversation() -> void:
	current = {"id": _new_id(), "title": "Nova conversa", "created": U.now_iso(), "updated": U.now_iso(), "messages": []}
	conversation_changed.emit()

func add_message(role: String, text: String, meta: Dictionary = {}) -> Dictionary:
	var msg := {"role": role, "text": text, "ts": U.now_iso()}
	for k in meta:
		msg[k] = meta[k]
	current["messages"].append(msg)
	if role == "user" and current["title"] == "Nova conversa":
		current["title"] = text.substr(0, 42)
	current["updated"] = U.now_iso()
	return msg

func chat_messages(max_n: int = 40) -> Array:
	var out: Array = []
	for m in current["messages"]:
		if m["role"] == "user" or m["role"] == "assistant":
			if String(m["text"]).strip_edges() != "":
				out.append({"role": m["role"], "text": m["text"]})
	if out.size() > max_n:
		out = out.slice(out.size() - max_n)
	return out

func save_current() -> void:
	if not Cfg.get_v("save_history"):
		return
	if current["messages"].size() == 0:
		return
	U.write_json("%s/%s.json" % [HIST_DIR, current["id"]], current)
	var found := false
	for e in _index:
		if e["id"] == current["id"]:
			e["title"] = current["title"]
			e["updated"] = current["updated"]
			e["count"] = current["messages"].size()
			found = true
	if not found:
		_index.append({"id": current["id"], "title": current["title"], "created": current["created"],
			"updated": current["updated"], "count": current["messages"].size()})
	U.write_json(INDEX_PATH, _index)

func list_conversations() -> Array:
	var arr := _index.duplicate()
	arr.sort_custom(func(a, b): return String(a["updated"]) > String(b["updated"]))
	return arr

func load_conversation(id: String) -> bool:
	var c = U.read_json("%s/%s.json" % [HIST_DIR, id], null)
	if typeof(c) != TYPE_DICTIONARY or not c.has("messages"):
		return false
	current = c
	conversation_changed.emit()
	return true

func delete_conversation(id: String) -> void:
	DirAccess.remove_absolute("%s/%s.json" % [HIST_DIR, id])
	for i in range(_index.size() - 1, -1, -1):
		if _index[i]["id"] == id:
			_index.remove_at(i)
	U.write_json(INDEX_PATH, _index)
	if current["id"] == id:
		new_conversation()

func clear_history() -> void:
	for e in _index:
		DirAccess.remove_absolute("%s/%s.json" % [HIST_DIR, e["id"]])
	_index = []
	U.write_json(INDEX_PATH, _index)
	new_conversation()

# ---------------- memoria ----------------
func save_memories() -> void:
	U.write_json(MEM_PATH, {"version": 1, "items": memories})
	memory_changed.emit()

# Classifica o texto: "never" (nunca guardar), "consent" (so com autorizacao explicita) ou "ok".
func check_sensitive(text: String) -> Dictionary:
	var t := U.norm(text)
	var never_words := ["senha", "password", "token", "cvv", "codigo de seguranca", "pin do cartao", "chave pix", "numero do cartao", "cartao de credito"]
	for w in never_words:
		if (" " + t + " ").contains(" " + w + " "):
			return {"level": "never", "reason": "credenciais e dados de pagamento nunca sao guardados"}
	var card := RegEx.create_from_string("\\d{4}[ -]?\\d{4}[ -]?\\d{4}[ -]?\\d{3,4}")
	var cpf := RegEx.create_from_string("\\d{3}\\.?\\d{3}\\.?\\d{3}-?\\d{2}")
	if card.search(text) != null or cpf.search(text) != null:
		return {"level": "never", "reason": "numeros de cartao/CPF nunca sao guardados"}
	var consent_words := ["diagnostico", "doenca", "remedio", "medicamento", "exame", "depressao", "ansiedade", "endereco", "moro na", "moro no", "religiao", "partido", "voto", "salario", "divida", "rg", "passaporte"]
	for w in consent_words:
		if (" " + t + " ").contains(" " + w + " "):
			return {"level": "consent", "reason": "parece uma informacao pessoal sensivel"}
	var mail := RegEx.create_from_string("[\\w.+-]+@[\\w-]+\\.[\\w.]+")
	var phone := RegEx.create_from_string("\\(?\\d{2}\\)?\\s?9?\\d{4}[-\\s]?\\d{4}")
	if mail.search(text) != null or phone.search(text) != null:
		return {"level": "consent", "reason": "contem e-mail ou telefone"}
	return {"level": "ok", "reason": ""}

func add_memory(text: String, category: String = "fato", source: String = "usuario") -> Dictionary:
	var t := text.strip_edges()
	if t == "":
		return {"ok": false, "error": "vazio"}
	if memories.size() >= 300:
		return {"ok": false, "error": "limite de 300 memorias atingido"}
	var item := {"id": _new_id(), "text": t.substr(0, 400), "category": category if CATEGORIES.has(category) else "fato",
		"created": U.now_iso(), "source": source}
	memories.append(item)
	save_memories()
	return {"ok": true, "id": item["id"]}

func update_memory(id: String, text: String, category: String) -> bool:
	for m in memories:
		if m["id"] == id:
			m["text"] = text.strip_edges().substr(0, 400)
			m["category"] = category if CATEGORIES.has(category) else "fato"
			save_memories()
			return true
	return false

func remove_memory(id: String) -> void:
	for i in range(memories.size() - 1, -1, -1):
		if memories[i]["id"] == id:
			memories.remove_at(i)
	save_memories()

func clear_memories() -> void:
	memories = []
	save_memories()

# Busca lexical simples (sem embeddings): sobreposicao de termos + leve bonus de recencia.
func search_memories(query: String, k: int = 4) -> Array:
	if not Cfg.get_v("memory_enabled") or memories.is_empty():
		return []
	var q: Array = U.tokens(query)
	if q.is_empty():
		return []
	var scored: Array = []
	var n := memories.size()
	for i in range(n):
		var mt: Array = U.tokens(memories[i]["text"])
		var score := 0.0
		for w in q:
			if mt.has(w):
				score += 1.0
			else:
				for x in mt:
					if x.length() >= 5 and w.length() >= 5 and (x.begins_with(w.substr(0, 5)) or w.begins_with(x.substr(0, 5))):
						score += 0.5
						break
		if score > 0.0:
			scored.append({"m": memories[i], "s": score + float(i) / float(maxi(n, 1)) * 0.2})
	scored.sort_custom(func(a, b): return a["s"] > b["s"])
	var out: Array = []
	for j in range(mini(k, scored.size())):
		out.append(scored[j]["m"])
	return out
