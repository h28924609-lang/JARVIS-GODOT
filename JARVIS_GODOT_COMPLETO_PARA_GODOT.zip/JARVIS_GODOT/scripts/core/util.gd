extends RefCounted
# Utilitarios estaticos: texto (normalizacao PT-BR), arquivos JSON atomicos.

const ACCENTS := {
	"á": "a", "à": "a", "â": "a", "ã": "a", "ä": "a", "é": "e", "è": "e", "ê": "e", "ë": "e",
	"í": "i", "ì": "i", "î": "i", "ï": "i", "ó": "o", "ò": "o", "ô": "o", "õ": "o", "ö": "o",
	"ú": "u", "ù": "u", "û": "u", "ü": "u", "ç": "c", "ñ": "n"
}

const STOPWORDS := [
	"a", "o", "as", "os", "um", "uma", "uns", "umas", "de", "do", "da", "dos", "das", "em", "no", "na", "nos", "nas",
	"por", "para", "pra", "com", "sem", "e", "ou", "que", "se", "eu", "voce", "meu", "minha", "meus", "minhas",
	"me", "te", "lhe", "mais", "muito", "ja", "ao", "aos", "isso", "isto", "esse", "essa", "este", "esta",
	"qual", "quais", "como", "onde", "quando", "sobre", "foi", "ser", "ter", "tem", "sou", "es", "eh"
]

static func norm(s: String) -> String:
	var t: String = s.to_lower()
	var res := ""
	for ch in t:
		var c: String = ACCENTS.get(ch, ch)
		var code: int = c.unicode_at(0)
		if (code >= 97 and code <= 122) or (code >= 48 and code <= 57):
			res += c
		else:
			res += " "
	var parts: PackedStringArray = res.split(" ", false)
	return " ".join(parts)

# Igual a norm(), mas SEM colapsar espacos: o resultado tem o mesmo tamanho do original,
# entao posicoes de regex no texto normalizado valem para o texto original (acentos e maiusculas preservados).
static func norm_len(s: String) -> String:
	var res := ""
	for ch in s.to_lower():
		var c: String = ACCENTS.get(ch, ch)
		var code: int = c.unicode_at(0)
		if (code >= 97 and code <= 122) or (code >= 48 and code <= 57):
			res += c
		else:
			res += " "
	return res

static func tokens(s: String) -> Array:
	var out: Array = []
	for w in norm(s).split(" ", false):
		if w.length() > 1 and not STOPWORDS.has(w):
			out.append(w)
	return out

static func write_json(path: String, obj) -> bool:
	var tmp := path + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return false
	f.store_string(JSON.stringify(obj, "\t"))
	f.close()
	return DirAccess.rename_absolute(tmp, path) == OK

static func read_json(path: String, default_value = null):
	if not FileAccess.file_exists(path):
		return default_value
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return default_value
	var parsed = JSON.parse_string(f.get_as_text())
	f.close()
	if parsed == null:
		return default_value
	return parsed

static func read_text(path: String) -> String:
	if not FileAccess.file_exists(path):
		return ""
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return ""
	var t: String = f.get_as_text()
	f.close()
	return t

static func fmt_bytes(b: float) -> String:
	if b >= 1073741824.0:
		return "%.2f GB" % (b / 1073741824.0)
	if b >= 1048576.0:
		return "%.0f MB" % (b / 1048576.0)
	if b >= 1024.0:
		return "%.0f KB" % (b / 1024.0)
	return "%d B" % int(b)

static func now_iso() -> String:
	return Time.get_datetime_string_from_system(false, true)
