extends Node
# Orquestra reconhecimento (STT) e sintese (TTS) de voz via plugin Android.

signal stt_partial(text)
signal stt_final(text)
signal stt_error(code, message)
signal stt_level(level)
signal listening_changed(active)
signal speaking_changed(active)
signal wake_detected()
signal tts_ready_changed()

var listening := false
var speaking := false
var tts_ready := false
var tts_error := ""
var voices: Array = []
var _pending := 0
var _utt := 0
var _last_spoken := ""

func _ready() -> void:
	Bridge.evt.connect(_on_evt)
	Cfg.changed.connect(_on_cfg)
	if Bridge.available:
		Bridge.api("tts_init")

func _on_cfg(key) -> void:
	if str(key).begins_with("tts_") or key == "*":
		apply_settings()

func apply_settings() -> void:
	if not Bridge.available:
		return
	Bridge.plugin.tts_configure(float(Cfg.get_v("tts_rate")), float(Cfg.get_v("tts_pitch")), float(Cfg.get_v("tts_volume")))
	var v := String(Cfg.get_v("tts_voice"))
	if v != "":
		Bridge.plugin.tts_set_voice(v)

func refresh_voices() -> void:
	var r = Bridge.api("tts_list_voices")
	if typeof(r) == TYPE_DICTIONARY and r.get("ok", false):
		voices = r.get("voices", [])

func _on_evt(ev: String, d: Dictionary) -> void:
	match ev:
		"tts_ready":
			tts_ready = bool(d.get("ready", false))
			tts_error = String(d.get("error", ""))
			if tts_ready:
				apply_settings()
				refresh_voices()
			tts_ready_changed.emit()
		"tts_state":
			var st := String(d.get("state", ""))
			if st == "start":
				_set_speaking(true)
			else:
				_pending = int(d.get("pending", 0))
				if _pending <= 0:
					_pending = 0
					_set_speaking(false)
		"stt_state":
			var s := String(d.get("state", ""))
			if s == "end" or s == "cancelled":
				pass
		"stt_partial":
			stt_partial.emit(String(d.get("text", "")))
		"stt_final":
			_set_listening(false)
			stt_final.emit(String(d.get("text", "")))
		"stt_error":
			_set_listening(false)
			stt_error.emit(String(d.get("code", "")), String(d.get("message", "")))
		"stt_rms":
			stt_level.emit(float(d.get("level", 0.0)))
		"wake_word":
			wake_detected.emit()

func _set_speaking(v: bool) -> void:
	if speaking != v:
		speaking = v
		speaking_changed.emit(v)

func _set_listening(v: bool) -> void:
	if listening != v:
		listening = v
		listening_changed.emit(v)

func clean_for_speech(text: String) -> String:
	var t := text
	for ch in ["*", "#", "`", "_", "~", "|"]:
		t = t.replace(ch, "")
	var url := RegEx.create_from_string("https?://\\S+")
	t = url.sub(t, "", true)
	var out := ""
	for c in t:
		if c.unicode_at(0) < 0x1F000:
			out += c
	return out.strip_edges()

func speak(text: String, queue: bool = true) -> bool:
	if not Cfg.get_v("tts_enabled") or not Bridge.available or not tts_ready:
		return false
	var t := clean_for_speech(text)
	if t == "":
		return false
	_utt += 1
	_last_spoken = t if not queue else _last_spoken + " " + t
	_pending += 1
	var ok: bool = bool(Bridge.plugin.tts_speak(t, queue, "u%d" % _utt))
	if not ok:
		_pending = maxi(0, _pending - 1)
	else:
		_set_speaking(true)
	return ok

func begin_utterance_group() -> void:
	_last_spoken = ""

func repeat_last() -> bool:
	if _last_spoken.strip_edges() == "":
		return false
	var t := _last_spoken
	stop_speaking()
	var keep := t
	var ok := speak(keep, false)
	_last_spoken = keep
	return ok

func stop_speaking() -> void:
	_pending = 0
	if Bridge.available:
		Bridge.api("tts_stop")
	_set_speaking(false)

# Divide texto em frases completas para falar enquanto o modelo ainda gera. Retorna [frases, resto].
func take_sentences(buffer: String, min_len: int = 14) -> Array:
	var sentences: Array = []
	var start := 0
	var i := 0
	var n := buffer.length()
	while i < n:
		var c: String = buffer[i]
		var is_end := (c == "." or c == "!" or c == "?" or c == "\n" or c == ":")
		if is_end and i - start + 1 >= min_len:
			var nxt: String = buffer[i + 1] if i + 1 < n else " "
			if nxt == " " or nxt == "\n" or i + 1 >= n:
				if not (c == "." and i > 0 and buffer[i - 1].is_valid_int() and nxt.is_valid_int()):
					sentences.append(buffer.substr(start, i - start + 1).strip_edges())
					start = i + 1
		i += 1
	return [sentences, buffer.substr(start)]

func start_listening() -> bool:
	if not Bridge.available:
		stt_error.emit("plugin_missing", "Plugin Android ausente: sem reconhecimento de voz.")
		return false
	if not Bridge.has_permission("RECORD_AUDIO"):
		Bridge.request_permissions(["RECORD_AUDIO"])
		stt_error.emit("permission", "Conceda a permissao de microfone e toque novamente.")
		return false
	stop_speaking()
	var opts := {"engine": Cfg.get_v("stt_engine"), "prefer_offline": Cfg.get_v("stt_prefer_offline"),
		"on_device_only": Cfg.get_v("stt_on_device_only")}
	var r = Bridge.api("stt_start", [JSON.stringify(opts)])
	if typeof(r) == TYPE_DICTIONARY and r.get("ok", false):
		_set_listening(true)
		return true
	stt_error.emit("start_failed", "Nao foi possivel iniciar o reconhecimento.")
	return false

func stop_listening() -> void:
	if Bridge.available:
		Bridge.api("stt_stop")

func cancel_listening() -> void:
	if Bridge.available:
		Bridge.api("stt_cancel")
	_set_listening(false)

func apply_wake_settings() -> Dictionary:
	if not Bridge.available:
		return {"ok": false, "error": "plugin_missing"}
	var r = Bridge.api("wake_set", [JSON.stringify({"enabled": Cfg.get_v("wake_enabled"), "background": Cfg.get_v("wake_background")})])
	return r if typeof(r) == TYPE_DICTIONARY else {"ok": false}
