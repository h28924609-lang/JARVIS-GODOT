extends Control
# Tela principal do Jarvis: nucleo animado, estado, conversa, entrada por texto/voz, banners e dialogos de confirmacao.

const UIK = preload("res://scripts/ui/ui_kit.gd")
const OrbS = preload("res://scripts/ui/orb.gd")
const BgS = preload("res://scripts/ui/bg_fx.gd")

const SCREENS := {
	"settings": "res://scenes/screens/settings.tscn",
	"models": "res://scenes/screens/models.tscn",
	"memory": "res://scenes/screens/memory.tscn",
	"history": "res://scenes/screens/history.tscn",
	"diagnostics": "res://scenes/screens/diagnostics.tscn"
}
const CAPTIONS := {"idle": "PRONTO", "listening": "OUVINDO", "thinking": "PENSANDO", "speaking": "FALANDO", "acting": "EXECUTANDO", "error": "ERRO"}

var bg
var orb
var caption: Label
var sub_caption: Label
var chip: Label
var title_lbl: Label
var chat_scroll: ScrollContainer
var chat_box: VBoxContainer
var input: LineEdit
var btn_mic
var btn_send
var banner: PanelContainer
var banner_label: Label
var banner_btn: Button
var screen_layer: Control
var dialog_layer: Control
var root_margin: MarginContainer
var _bubbles: Array = []
var _stack: Array = []
var _base_bottom := 12.0
var _last_input := 0.0
var _eco_on := false
var _chip_acc := 0.0
var _insets := Vector2(24, 12)

func _ready() -> void:
	theme = UIK.make_theme()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	get_tree().set_auto_accept_quit(false)
	_insets = UIK.safe_insets(self)
	_base_bottom = _insets.y + 10.0
	_build_ui()
	_connect_signals()
	_rebuild_chat()
	_update_chip()
	_update_banner()
	_last_input = Time.get_ticks_msec() / 1000.0
	await get_tree().process_frame
	Agent.startup()
	_first_run()

func _build_ui() -> void:
	bg = BgS.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	root_margin = MarginContainer.new()
	root_margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	root_margin.add_theme_constant_override("margin_left", 24)
	root_margin.add_theme_constant_override("margin_right", 24)
	root_margin.add_theme_constant_override("margin_top", int(_insets.x) + 6)
	root_margin.add_theme_constant_override("margin_bottom", int(_base_bottom))
	add_child(root_margin)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	root_margin.add_child(v)

	# barra superior
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 10)
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_theme_constant_override("separation", 0)
	title_lbl = UIK.label(Persona.assistant_name().to_upper(), 38, UIK.TEXT)
	left.add_child(title_lbl)
	chip = UIK.label("", 21, UIK.CYAN)
	left.add_child(chip)
	top.add_child(left)
	var b_hist := UIK.IconBtn.new("clock", 68)
	b_hist.pressed.connect(open_screen.bind("history"))
	var b_mem := UIK.IconBtn.new("chip", 68)
	b_mem.pressed.connect(open_screen.bind("memory"))
	var b_set := UIK.IconBtn.new("gear", 68)
	b_set.pressed.connect(open_screen.bind("settings"))
	for b in [b_hist, b_mem, b_set]:
		b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		top.add_child(b)
	v.add_child(top)

	# banner de avisos
	banner = PanelContainer.new()
	banner.add_theme_stylebox_override("panel", UIK.sb(Color(0.25, 0.16, 0.02, 0.9), UIK.AMBER, 14, 2, 12))
	var bh := HBoxContainer.new()
	banner_label = UIK.label("", 22, UIK.AMBER)
	banner_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bh.add_child(banner_label)
	banner_btn = UIK.button("Abrir", "primary")
	banner_btn.custom_minimum_size = Vector2(190, 60)
	banner_btn.pressed.connect(open_screen.bind("models"))
	bh.add_child(banner_btn)
	banner.add_child(bh)
	banner.visible = false
	v.add_child(banner)

	# nucleo
	var holder := Control.new()
	holder.size_flags_vertical = Control.SIZE_EXPAND_FILL
	holder.size_flags_stretch_ratio = 1.0
	holder.custom_minimum_size = Vector2(0, 280)
	orb = OrbS.new()
	orb.set_anchors_preset(Control.PRESET_FULL_RECT)
	orb.tapped.connect(func(): Agent.toggle_listening())
	holder.add_child(orb)
	v.add_child(holder)
	caption = UIK.label("PRONTO", 30, UIK.CYAN)
	caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(caption)
	sub_caption = UIK.label("Toque no nucleo ou no microfone para falar.", 22, UIK.DIM)
	sub_caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub_caption.custom_minimum_size = Vector2(0, 56)
	v.add_child(sub_caption)

	# conversa
	chat_scroll = ScrollContainer.new()
	chat_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	chat_scroll.size_flags_stretch_ratio = 1.15
	chat_scroll.custom_minimum_size = Vector2(0, 260)
	chat_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	chat_box = VBoxContainer.new()
	chat_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	chat_box.add_theme_constant_override("separation", 10)
	chat_scroll.add_child(chat_box)
	v.add_child(chat_scroll)

	# entrada
	var bar := HBoxContainer.new()
	bar.add_theme_constant_override("separation", 10)
	input = LineEdit.new()
	input.placeholder_text = "Digite uma mensagem..."
	input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	input.custom_minimum_size = Vector2(0, 80)
	input.text_submitted.connect(func(_t): _send())
	bar.add_child(input)
	var b_rep := UIK.IconBtn.new("repeat", 64)
	b_rep.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	b_rep.pressed.connect(func(): Agent.repeat_response())
	bar.add_child(b_rep)
	btn_mic = UIK.IconBtn.new("mic", 88)
	btn_mic.tint = UIK.CYAN
	btn_mic.pressed.connect(func(): Agent.toggle_listening())
	bar.add_child(btn_mic)
	btn_send = UIK.IconBtn.new("send", 88)
	btn_send.tint = UIK.GREEN
	btn_send.pressed.connect(_on_send_pressed)
	bar.add_child(btn_send)
	v.add_child(bar)

	screen_layer = Control.new()
	screen_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	screen_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(screen_layer)
	dialog_layer = Control.new()
	dialog_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	dialog_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(dialog_layer)

func _connect_signals() -> void:
	Agent.state_changed.connect(_on_state)
	Agent.busy_changed.connect(func(_b): _update_send_icon())
	Agent.message_added.connect(_on_message_added)
	Agent.message_updated.connect(_on_message_updated)
	Agent.notice.connect(_on_notice)
	Agent.plan_step.connect(_on_plan_step)
	Agent.voice_partial.connect(_on_voice_partial)
	Voice.stt_level.connect(func(l): orb.level = l)
	Voice.stt_error.connect(func(_c, _m): orb.level = 0.0)
	Store.conversation_changed.connect(_rebuild_chat)
	Safety.confirm_requested.connect(_show_confirm)
	Llm.state_changed.connect(_update_banner)
	Cfg.changed.connect(_on_cfg)

func _on_cfg(key) -> void:
	if key == "assistant_name" or key == "*":
		title_lbl.text = Persona.assistant_name().to_upper()
	_update_chip()

func _first_run() -> void:
	if Cfg.get_v("first_run_done"):
		return
	Cfg.set_v("first_run_done", true)
	Agent.say_local("Ola! Eu sou %s, seu assistente pessoal. Eu penso aqui no celular, sem enviar suas conversas para a internet. Para comecar, abra Modelos de IA (engrenagem, depois Modelos) e baixe um modelo. Depois e so conversar por texto ou voz." % Persona.assistant_name(), false)
	Store.save_current()
	if Bridge.available and not Llm.loaded:
		await get_tree().create_timer(0.8).timeout
		open_screen("models")

# ---------------- estado / indicadores ----------------
func _on_state(s: int) -> void:
	var n: String = Agent.state_name()
	orb.set_state(n)
	caption.text = CAPTIONS.get(n, "PRONTO")
	var col := UIK.CYAN
	match n:
		"thinking": col = UIK.AMBER
		"listening": col = UIK.GREEN
		"error": col = UIK.RED
		"acting": col = Color(0.8, 0.52, 1.0)
		"speaking": col = Color(0.45, 0.72, 1.0)
	caption.add_theme_color_override("font_color", col)
	btn_mic.pulse = (n == "listening")
	btn_mic.tint = UIK.GREEN if n == "listening" else UIK.CYAN
	btn_mic.queue_redraw()
	if n != "listening":
		orb.level = 0.0
	_update_send_icon()
	_wake_from_eco()

func _update_send_icon() -> void:
	var busy_now: bool = Agent.busy or Agent.state == Agent.S.SPEAKING or Agent.state == Agent.S.LISTENING
	btn_send.set_icon("stop" if busy_now else "send")
	btn_send.tint = UIK.RED if busy_now else UIK.GREEN

func _on_send_pressed() -> void:
	if Agent.busy or Agent.state == Agent.S.SPEAKING or Agent.state == Agent.S.LISTENING:
		Agent.interrupt()
	else:
		_send()

func _send() -> void:
	var t := input.text.strip_edges()
	if t == "":
		return
	input.text = ""
	input.release_focus()
	Agent.submit(t)

func _update_chip() -> void:
	if not Bridge.available:
		chip.text = "SEM PLUGIN NO APK" if Bridge.plugin_state == "missing_in_apk" else "SEM PLUGIN - FORA DO ANDROID"
		chip.add_theme_color_override("font_color", UIK.AMBER)
	elif Cfg.get_v("internet_enabled") and Bridge.is_online():
		chip.text = "ONLINE - consultas autorizadas"
		chip.add_theme_color_override("font_color", UIK.GREEN)
	else:
		chip.text = "OFFLINE - IA LOCAL"
		chip.add_theme_color_override("font_color", UIK.CYAN)

func _update_banner() -> void:
	banner.visible = true
	banner_btn.visible = false
	if not Bridge.available:
		banner_label.text = Bridge.status_text() + " IA, voz e controle do Android so funcionam com o plugin (veja o README)."
	elif Llm.loading:
		banner_label.text = "Carregando o modelo de IA..."
	elif not Llm.loaded:
		banner_label.text = "Nenhum modelo carregado."
		if Llm.last_error != "":
			banner_label.text += " " + Llm.last_error
		banner_btn.visible = true
		banner_btn.text = "Modelos de IA"
	else:
		banner.visible = false
	_update_chip()

func _on_notice(text: String, kind: String) -> void:
	var col := UIK.DIM
	if kind == "warn":
		col = UIK.AMBER
	elif kind == "error":
		col = UIK.RED
	sub_caption.text = text
	sub_caption.add_theme_color_override("font_color", col)

func _on_voice_partial(t: String) -> void:
	sub_caption.text = t
	sub_caption.add_theme_color_override("font_color", UIK.TEXT)

func _on_plan_step(d: Dictionary) -> void:
	var st := String(d.get("status", ""))
	if st == "running":
		sub_caption.text = "Passo %d/%d: %s" % [int(d.get("step", 0)) + 1, int(d.get("total", 1)), String(d.get("human", ""))]
		sub_caption.add_theme_color_override("font_color", UIK.TEXT)

# ---------------- conversa ----------------
func _rebuild_chat() -> void:
	for c in chat_box.get_children():
		c.queue_free()
	_bubbles.clear()
	var msgs: Array = Store.current["messages"]
	var start := maxi(0, msgs.size() - 60)
	for i in range(start, msgs.size()):
		_add_bubble(msgs[i])
	_scroll_bottom()

func _on_message_added(msg: Dictionary) -> void:
	_add_bubble(msg)
	_scroll_bottom()

func _on_message_updated(msg: Dictionary) -> void:
	for i in range(_bubbles.size() - 1, -1, -1):
		if is_same(_bubbles[i]["m"], msg):
			_bubbles[i]["l"].text = String(msg["text"])
			break
	_scroll_bottom()

func _add_bubble(msg: Dictionary) -> void:
	var role: String = msg["role"]
	var is_user := role == "user"
	var wrap := MarginContainer.new()
	wrap.add_theme_constant_override("margin_left", 70 if is_user else 0)
	wrap.add_theme_constant_override("margin_right", 0 if is_user else 70)
	var pc := PanelContainer.new()
	pc.add_theme_stylebox_override("panel", UIK.sb(
		Color(0.05, 0.24, 0.32, 0.6) if is_user else Color(0.05, 0.09, 0.15, 0.92),
		UIK.CYAN if is_user else UIK.LINE, 16, 2, 14))
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 4)
	vb.add_child(UIK.label("VOCE" if is_user else Persona.assistant_name().to_upper(), 18, UIK.GREEN if is_user else UIK.CYAN))
	var rt := RichTextLabel.new()
	rt.fit_content = true
	rt.bbcode_enabled = false
	rt.scroll_active = false
	rt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rt.mouse_filter = Control.MOUSE_FILTER_PASS
	rt.text = String(msg["text"])
	vb.add_child(rt)
	pc.add_child(vb)
	wrap.add_child(pc)
	chat_box.add_child(wrap)
	_bubbles.append({"m": msg, "l": rt})

func _scroll_bottom() -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	var bar := chat_scroll.get_v_scroll_bar()
	chat_scroll.scroll_vertical = int(bar.max_value)

# ---------------- dialogo de confirmacao ----------------
func _show_confirm(req: Dictionary) -> void:
	for c in dialog_layer.get_children():
		c.queue_free()
	dialog_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.72)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dialog_layer.add_child(dim)
	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	dialog_layer.add_child(cc)
	var pc := PanelContainer.new()
	var danger: bool = bool(req.get("danger", false))
	pc.add_theme_stylebox_override("panel", UIK.sb(Color(0.03, 0.06, 0.10, 0.99), UIK.AMBER if danger else UIK.CYAN, 20, 3, 22))
	pc.custom_minimum_size = Vector2(620, 0)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	vb.add_child(UIK.label(String(req["title"]), 32, UIK.AMBER if danger else UIK.CYAN))
	for line in req["lines"]:
		vb.add_child(UIK.label(String(line), 24, UIK.TEXT))
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	var bc := UIK.button(String(req["cancel"]), "ghost")
	bc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var bo := UIK.button(String(req["confirm"]), "danger" if danger else "primary")
	bo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var rid: int = int(req["id"])
	bc.pressed.connect(func(): _close_dialog(rid, false))
	bo.pressed.connect(func(): _close_dialog(rid, true))
	hb.add_child(bc)
	hb.add_child(bo)
	vb.add_child(UIK.spacer(6))
	vb.add_child(hb)
	pc.add_child(vb)
	cc.add_child(pc)

func _close_dialog(id: int, yes: bool) -> void:
	for c in dialog_layer.get_children():
		c.queue_free()
	dialog_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	Safety.answer(id, yes)

# ---------------- navegacao entre telas ----------------
func open_screen(sname: String) -> void:
	if not SCREENS.has(sname):
		return
	var ps: PackedScene = load(SCREENS[sname])
	var sc: Control = ps.instantiate()
	sc.close_requested.connect(func(): _close_screen(sc))
	sc.navigate.connect(open_screen)
	screen_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	screen_layer.add_child(sc)
	_stack.append(sc)
	sc.modulate.a = 0.0
	sc.position.x = 70.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(sc, "modulate:a", 1.0, 0.18)
	tw.tween_property(sc, "position:x", 0.0, 0.18)

func _close_screen(sc: Control) -> void:
	if not is_instance_valid(sc):
		return
	_stack.erase(sc)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(sc, "modulate:a", 0.0, 0.14)
	tw.tween_property(sc, "position:x", 60.0, 0.14)
	tw.chain().tween_callback(sc.queue_free)
	if _stack.is_empty():
		screen_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_update_banner()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if dialog_layer.get_child_count() > 0:
			return
		if not _stack.is_empty():
			_close_screen(_stack[_stack.size() - 1])
		elif Bridge.available:
			Bridge.api("minimize_app")
		else:
			get_tree().quit()
	elif what == NOTIFICATION_WM_CLOSE_REQUEST:
		Store.save_current()
		Cfg.save_now()
		get_tree().quit()
	elif what == NOTIFICATION_APPLICATION_FOCUS_IN or what == NOTIFICATION_APPLICATION_RESUMED:
		_update_chip()
		_update_banner()
	elif what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		Store.save_current()
		Cfg.save_now()

# ---------------- economia de energia ----------------
func _input(e: InputEvent) -> void:
	if e is InputEventMouseButton or e is InputEventScreenTouch or e is InputEventKey:
		_last_input = Time.get_ticks_msec() / 1000.0
		_wake_from_eco()

func _wake_from_eco() -> void:
	if _eco_on:
		_eco_on = false
		Engine.max_fps = 60
		orb.quality = 1.0
		bg.enabled_anim = true

func _process(delta: float) -> void:
	var kb := DisplayServer.virtual_keyboard_get_height()
	if kb > 0:
		var ws := DisplayServer.window_get_size()
		var k := size.y / maxf(1.0, float(ws.y))
		root_margin.add_theme_constant_override("margin_bottom", int(_base_bottom + kb * k))
	else:
		root_margin.add_theme_constant_override("margin_bottom", int(_base_bottom))
	var now := Time.get_ticks_msec() / 1000.0
	if Cfg.get_v("eco_mode") and not _eco_on and Agent.state == Agent.S.IDLE and now - _last_input > 25.0:
		_eco_on = true
		Engine.max_fps = 30
		orb.quality = 0.5
		bg.enabled_anim = false
	_chip_acc += delta
	if _chip_acc > 6.0:
		_chip_acc = 0.0
		_update_chip()
