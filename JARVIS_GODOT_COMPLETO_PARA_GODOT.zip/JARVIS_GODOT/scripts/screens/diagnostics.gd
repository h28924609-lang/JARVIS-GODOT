extends "res://scripts/screens/screen_base.gd"
# Diagnostico e AUTOTESTE no proprio aparelho: executa os testes reais (integracao Godot/Kotlin, modelo, conversa em
# portugues, memoria de conversa, voz, seguranca, permissoes, RAM) e gera um relatorio que voce pode compartilhar.

var _status: Label
var _out: VBoxContainer
var _lines: Array = []
var _running := false

func _init() -> void:
	title_text = "Diagnostico"

func build() -> void:
	_status = UIK.label("", 21, UIK.DIM)
	body.add_child(_status)
	var b := UIK.button("Executar autoteste completo", "primary")
	b.pressed.connect(run_all)
	body.add_child(b)
	var bb := UIK.button("Medir velocidade (threads)")
	bb.pressed.connect(_bench)
	body.add_child(bb)
	var bo := UIK.button("Testar abrir app Configuracoes (sai do Jarvis)")
	bo.pressed.connect(_open_settings_test)
	body.add_child(bo)
	var bs := UIK.button("Compartilhar relatorio")
	bs.pressed.connect(_share)
	body.add_child(bs)
	var bl := UIK.button("Ver logs do plugin")
	bl.pressed.connect(_logs)
	body.add_child(bl)
	_out = VBoxContainer.new()
	_out.add_theme_constant_override("separation", 8)
	body.add_child(_out)
	_show_status()

func _show_status() -> void:
	var t := "Godot %s - ambiente: %s - plugin: %s\n%s\n" % [Engine.get_version_info().get("string", "?"), Bridge.env, "OK" if Bridge.available else "AUSENTE", Bridge.status_text()]
	if not Bridge.available:
		var nd := Bridge.refresh_device(0.0)
		t += "Leitura direta do Godot - RAM: %s MB de %s MB; armazenamento livre: %s MB" % [str(nd.get("ram_avail_mb", "indisponivel")), str(nd.get("ram_total_mb", "indisponivel")), str(nd.get("storage_free_mb", "indisponivel"))]
	if Bridge.available:
		var d := Bridge.refresh_device(0.0)
		t += "%s - Android SDK %s\nRAM livre %s MB de %s MB (app: %s MB) - termico: %s - bateria %s%% %s C\nArmazenamento livre %s MB - online: %s\n" % [
			str(d.get("device", "?")), str(d.get("sdk", "?")), str(d.get("ram_avail_mb", "?")), str(d.get("ram_total_mb", "?")),
			str(d.get("app_pss_mb", "?")), str(d.get("thermal", "?")), str(d.get("battery_pct", "?")), str(d.get("battery_temp_c", "?")),
			str(d.get("storage_free_mb", "?")), str(d.get("online", "?"))]
		t += "Modelo: %s | contexto: %d | motor nativo: %s" % [Llm.model_name if Llm.loaded else "nao carregado", Llm.n_ctx, str(Bridge.ping_info.get("native_llm", "?"))]
	_status.text = t

func _add(name: String, status: String, detail: String) -> void:
	var col := UIK.GREEN if status == "OK" else (UIK.RED if status == "FALHOU" else UIK.AMBER)
	var l := UIK.label("[%s] %s\n%s" % [status, name, detail], 21, col)
	_out.add_child(l)
	_lines.append("| %s | %s | %s |" % [name, status, detail.replace("\n", " ").replace("|", "/")])

func _wait_event(ev_name: String, timeout: float, key: String = "", val = null) -> Dictionary:
	var box := {"got": false, "data": {}}
	var cb := func(ev, d):
		if ev == ev_name and (key == "" or d.get(key, null) == val):
			box["got"] = true
			box["data"] = d
	Bridge.evt.connect(cb)
	var t0 := Time.get_ticks_msec() / 1000.0
	while not box["got"] and Time.get_ticks_msec() / 1000.0 - t0 < timeout:
		await get_tree().create_timer(0.1).timeout
	Bridge.evt.disconnect(cb)
	return box["data"] if box["got"] else {}

func _gen(msgs: Array, max_tokens: int) -> Dictionary:
	var family := Persona.family_for(Llm.model_name)
	var fit: Dictionary = Llm.fit_prompt(Persona.build_system(), msgs, family)
	return await Llm.generate_wait(fit["prompt"], {"max_tokens": max_tokens, "temperature": 0.2, "stop": Persona.stop_sequences(family)})

func run_all() -> void:
	if _running:
		return
	_running = true
	_lines = []
	for c in _out.get_children():
		c.queue_free()
	var now := Time.get_datetime_string_from_system()
	_add("1. Inicializacao do app", "OK", "Godot %s em execucao; autoloads carregados (%s)." % [Engine.get_version_info().get("string", "?"), now])
	if not Bridge.available:
		for n in ["2. Integracao Godot/Kotlin", "3. Carregamento do modelo", "4. Conversa em portugues", "5. Memoria de conversa", "6. Reconhecimento de voz", "7. Resposta falada", "8. Funcionamento sem internet", "9. Abertura de aplicativos", "10. Permissoes Android", "11. Consumo de memoria"]:
			_add(n, "NAO TESTADO", Bridge.status_text())
		_finish()
		return
	# 2. integracao Godot <-> Kotlin (chamada, retorno JSON e sinal)
	var echo := "ola \u00e1\u00e9\u00ed \"q\" 123"
	var r = Bridge.ping(echo)
	var pong: Dictionary = await _wait_event("pong", 3.0)
	var ok_call: bool = typeof(r) == TYPE_DICTIONARY and r.get("echo", "") == echo
	_add("2. Integracao Godot/Kotlin", "OK" if (ok_call and not pong.is_empty()) else "FALHOU", "chamada+JSON: %s; sinal Kotlin->Godot: %s; plugin %s API %s" % [str(ok_call), str(not pong.is_empty()), str(r.get("plugin_version", "?")) if typeof(r) == TYPE_DICTIONARY else "?", str(r.get("api", "?")) if typeof(r) == TYPE_DICTIONARY else "?"])
	# 3. modelo
	var pss0 := int(Bridge.refresh_device(0.0).get("app_pss_mb", 0))
	var model_ok := Llm.loaded
	var load_ms := 0
	if not model_ok:
		var f := String(Cfg.get_v("model_file"))
		if f != "" and Agent.model_exists(f):
			var t0 := Time.get_ticks_msec()
			Llm.load_model(f)
			var t1 := Time.get_ticks_msec() / 1000.0
			while Llm.loading and Time.get_ticks_msec() / 1000.0 - t1 < 180.0:
				await get_tree().create_timer(0.3).timeout
			model_ok = Llm.loaded
			load_ms = Time.get_ticks_msec() - t0
	var pss1 := int(Bridge.refresh_device(0.0).get("app_pss_mb", 0))
	_add("3. Carregamento do modelo", "OK" if model_ok else "FALHOU", ("%s carregado (%d ms nesta execucao)" % [Llm.model_name, load_ms]) if model_ok else ("Sem modelo carregado: %s" % (Llm.last_error if Llm.last_error != "" else "baixe/carregue em Modelos de IA")))
	var ans_ok := false
	if model_ok:
		# 4. conversa em portugues
		var i4: Dictionary = await _gen([{"role": "user", "text": "Responda em uma frase: qual e a capital do Brasil?"}], 48)
		var txt4 := String(i4.get("text", "")).strip_edges()
		ans_ok = U.norm(txt4).contains("brasilia")
		var tps := float(i4.get("stats", {}).get("tps", 0))
		_add("4. Conversa em portugues", "OK" if ans_ok else "FALHOU", "Resposta: \"%s\" (%.1f tokens/s)" % [txt4.substr(0, 160), tps])
		# 5. memoria de conversa
		var i5: Dictionary = await _gen([{"role": "user", "text": "Meu nome e Teodoro. Guarde isso."}, {"role": "assistant", "text": "Certo, Teodoro. Vou lembrar."}, {"role": "user", "text": "Qual e o meu nome?"}], 40)
		var txt5 := String(i5.get("text", "")).strip_edges()
		_add("5. Memoria de conversa", "OK" if U.norm(txt5).contains("teodoro") else "FALHOU", "Resposta: \"%s\"" % txt5.substr(0, 160))
	else:
		_add("4. Conversa em portugues", "NAO TESTADO", "Depende do modelo carregado.")
		_add("5. Memoria de conversa", "NAO TESTADO", "Depende do modelo carregado.")
	# 6. STT
	var st = Bridge.api("stt_status")
	if typeof(st) == TYPE_DICTIONARY:
		_add("6. Reconhecimento de voz", "MANUAL", "Disponivel: %s | no aparelho: %s | permissao microfone: %s | Vosk: lib %s, modelo %s. Falar no microfone e confirmar a transcricao exige teste manual." % [str(st.get("available")), str(st.get("on_device_available")), str(st.get("permission")), str(st.get("vosk_library")), str(st.get("vosk_model"))])
	# 7. TTS
	Voice.apply_settings()
	var spoke := Voice.speak("Teste de voz do Jarvis.", false)
	var done: Dictionary = {}
	if spoke:
		done = await _wait_event("tts_state", 15.0, "state", "done")
	_add("7. Resposta falada", "OK" if not done.is_empty() else "FALHOU", "TTS pronto: %s; erro: %s; vozes pt: %d. (Se nao ouviu nada, confira o volume e as vozes do Android.)" % [str(Voice.tts_ready), Voice.tts_error, Voice.voices.size()])
	# 8. offline
	var online := Bridge.is_online()
	if online:
		_add("8. Funcionamento sem internet", "MANUAL", "O aparelho esta ONLINE. Ative o modo aviao e rode o autoteste de novo: os testes 4 e 5 provam o uso offline.")
	else:
		_add("8. Funcionamento sem internet", "OK" if ans_ok else "FALHOU", "Aparelho OFFLINE durante os testes 4 e 5 (IA local respondeu: %s)." % str(ans_ok))
	# 9. apps + seguranca (avaliacao; abrir de verdade tem botao proprio)
	var apps = Bridge.api("apps_list", [""])
	var n_apps: int = apps.get("apps", []).size() if typeof(apps) == TYPE_DICTIONARY else 0
	var ev_bank := Safety.evaluate([{"tool": "open_app", "args": {"name": "Nubank"}}])
	var ev_send := Safety.evaluate([{"tool": "click_text", "args": {"text": "Enviar"}}])
	var ev_cfg := Safety.evaluate([{"tool": "open_settings", "args": {"section": "wifi"}}])
	var sec_ok: bool = ev_bank.get("blocked", false) and ev_send.get("needs_confirmation", false) and not ev_cfg.get("blocked", true)
	_add("9. Aplicativos e seguranca", "OK" if (n_apps > 0 and sec_ok) else "FALHOU", "apps instalados detectados: %d; banco bloqueado: %s; Enviar exige confirmacao: %s; abrir Wi-Fi permitido: %s" % [n_apps, str(ev_bank.get("blocked")), str(ev_send.get("needs_confirmation")), str(not ev_cfg.get("blocked", true))])
	# 10. permissoes
	var acc = Bridge.api("accessibility_status")
	_add("10. Permissoes Android", "OK" if Bridge.has_permission("RECORD_AUDIO") else "MANUAL", "microfone: %s; notificacoes: %s; acessibilidade ativa: %s" % [str(Bridge.has_permission("RECORD_AUDIO")), str(Bridge.has_permission("POST_NOTIFICATIONS")), str(acc.get("connected")) if typeof(acc) == TYPE_DICTIONARY else "?"])
	# 11. memoria
	var d := Bridge.refresh_device(0.0)
	_add("11. Consumo de memoria", "OK" if model_ok else "MANUAL", "PSS do app: %d MB antes -> %d MB depois do modelo; RAM livre %s MB de %s MB; pouca memoria: %s" % [pss0, pss1, str(d.get("ram_avail_mb")), str(d.get("ram_total_mb")), str(d.get("low_memory"))])
	_add("12. Exportacao do APK", "MANUAL", "Feita fora do app (Godot no PC ou GitHub Actions). Este app so prova que o APK instalado funciona.")
	_finish()

func _finish() -> void:
	_running = false
	var head := "# Relatorio de testes no aparelho\n\n%s\n\n| Teste | Resultado | Detalhe |\n|---|---|---|\n" % _status.text.replace("\n", "  \n")
	U.write_json("user://relatorio_testes.json", {"when": Time.get_datetime_string_from_system(), "lines": _lines})
	var f := FileAccess.open("user://relatorio_testes.md", FileAccess.WRITE)
	if f != null:
		f.store_string(head + "\n".join(_lines) + "\n")
		f.close()
	_show_status()

func _share() -> void:
	var t := U.read_text("user://relatorio_testes.md")
	if t == "":
		toast("Rode o autoteste primeiro.")
		return
	if Bridge.available:
		Bridge.plugin.share_text("Relatorio de testes do Jarvis", t)

func _logs() -> void:
	if not Bridge.available:
		return
	var l := UIK.label(String(Bridge.plugin.get_logs()).right(3000), 17, UIK.DIM)
	_out.add_child(l)

func _bench() -> void:
	if not Llm.loaded:
		toast("Carregue um modelo primeiro.")
		return
	toast("Medindo... pode levar um minuto.")
	Bridge.api("llm_benchmark")
	var d: Dictionary = await _wait_event("llm_bench", 180.0)
	if d.is_empty() or not d.get("ok", false):
		toast("Benchmark falhou.")
		return
	var parts: Array = []
	for r in d.get("results", []):
		parts.append("%d threads: %.1f tok/s" % [int(r["threads"]), float(r["tps"])])
	Cfg.set_v("threads", int(d.get("best", 4)))
	_add("Benchmark", "OK", "; ".join(parts) + " -> melhor: %d threads (aplicado)." % int(d.get("best", 4)))

func _open_settings_test() -> void:
	var r := Safety.evaluate([{"tool": "open_settings", "args": {"section": "principal"}}])
	if not r.get("ok", false) or r.get("blocked", false):
		toast("Bloqueado ou indisponivel.")
		return
	Bridge.api("plan_execute", [JSON.stringify({"plan_id": "teste_apps", "steps": [{"tool": "open_settings", "args": {"section": "principal"}}], "approved": true})])
