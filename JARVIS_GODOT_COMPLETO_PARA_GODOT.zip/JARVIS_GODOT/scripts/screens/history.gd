extends "res://scripts/screens/screen_base.gd"
# Historico de conversas salvas neste aparelho.

func _init() -> void:
	title_text = "Historico"

func build() -> void:
	var bn := UIK.button("Nova conversa", "primary")
	bn.pressed.connect(func():
		Agent.interrupt()
		Store.new_conversation()
		close())
	body.add_child(bn)
	var list := Store.list_conversations()
	if list.is_empty():
		body.add_child(UIK.label("Nenhuma conversa salva ainda.", 24, UIK.DIM))
	for e in list:
		var v := UIK.card(body)
		var is_cur: bool = e["id"] == Store.current["id"]
		v.add_child(UIK.label(String(e["title"]) + ("  (atual)" if is_cur else ""), 26, UIK.GREEN if is_cur else UIK.TEXT))
		v.add_child(UIK.label("%s - %d mensagens" % [String(e.get("updated", "")).replace("T", " ").substr(0, 16), int(e.get("count", 0))], 20, UIK.DIM))
		var row := HBoxContainer.new()
		var bo := UIK.button("Abrir")
		bo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var id: String = e["id"]
		bo.pressed.connect(func():
			Agent.interrupt()
			if Store.load_conversation(id):
				close())
		var bd := UIK.button("Apagar", "danger")
		bd.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		bd.pressed.connect(func():
			Store.delete_conversation(id)
			clear_body()
			build())
		row.add_child(bo)
		row.add_child(bd)
		v.add_child(row)
	if not list.is_empty():
		var ba := UIK.button("Apagar todo o historico", "danger")
		ba.pressed.connect(_clear_all)
		body.add_child(ba)
	body.add_child(UIK.spacer(40))

func _clear_all() -> void:
	var yes: bool = await Safety.ask("Apagar todo o historico?", ["As conversas salvas serao removidas deste aparelho."], "Apagar tudo", "Cancelar", true)
	if yes:
		Store.clear_history()
		clear_body()
		build()
