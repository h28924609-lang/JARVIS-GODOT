extends "res://scripts/screens/screen_base.gd"
# Gerenciador de memoria: consultar, editar e apagar o que o usuario autorizou guardar.

var _list: VBoxContainer
var _new_text: LineEdit

func _init() -> void:
	title_text = "Memoria"

func _ready() -> void:
	super._ready()
	Store.memory_changed.connect(_render)

func _exit_tree() -> void:
	if Store.memory_changed.is_connected(_render):
		Store.memory_changed.disconnect(_render)

func build() -> void:
	var c := UIK.card(body)
	c.add_child(UIK.label("Aqui ficam as informacoes que voce autorizou o Jarvis a lembrar. Elas ficam so neste aparelho e NAO treinam o modelo: sao notas consultadas quando forem relevantes. Senhas, cartoes e CPF nunca sao guardados.", 21, UIK.DIM))
	UIK.row_toggle(c, "Memoria ativada", "", "memory_enabled")
	_new_text = LineEdit.new()
	_new_text.placeholder_text = "Ex.: Gosto de cafe sem acucar"
	_new_text.custom_minimum_size = Vector2(0, 68)
	_new_text.text_submitted.connect(func(_t): _add())
	c.add_child(_new_text)
	var b := UIK.button("Guardar na memoria", "primary")
	b.pressed.connect(_add)
	c.add_child(b)
	_list = VBoxContainer.new()
	_list.add_theme_constant_override("separation", 12)
	body.add_child(_list)
	var bd := UIK.button("Apagar toda a memoria", "danger")
	bd.pressed.connect(_clear_all)
	body.add_child(bd)
	body.add_child(UIK.spacer(40))
	_render()

func _add() -> void:
	var t := _new_text.text.strip_edges()
	if t == "":
		return
	var chk: Dictionary = Store.check_sensitive(t)
	if chk["level"] == "never":
		toast("Nao guardo isso: %s." % chk["reason"])
		return
	if chk["level"] == "consent":
		var yes: bool = await Safety.ask("Informacao sensivel", ["\"%s\"" % t, "Atencao: %s. Fica somente neste aparelho." % chk["reason"]], "Guardar", "Cancelar", true)
		if not yes:
			return
	Store.add_memory(t, "fato", "usuario")
	_new_text.text = ""

func _render() -> void:
	if _list == null:
		return
	for c in _list.get_children():
		c.queue_free()
	if Store.memories.is_empty():
		_list.add_child(UIK.label("Nada guardado ainda.", 24, UIK.DIM))
		return
	for i in range(Store.memories.size() - 1, -1, -1):
		var m: Dictionary = Store.memories[i]
		var v := UIK.card(_list)
		var le := LineEdit.new()
		le.text = String(m["text"])
		le.custom_minimum_size = Vector2(0, 64)
		v.add_child(le)
		var row := HBoxContainer.new()
		var ob := OptionButton.new()
		var cats: Array = Store.CATEGORIES
		for k in range(cats.size()):
			ob.add_item(String(cats[k]).capitalize(), k)
			if cats[k] == m["category"]:
				ob.select(k)
		ob.custom_minimum_size = Vector2(240, 60)
		row.add_child(ob)
		var sp := Control.new()
		sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(sp)
		var id: String = m["id"]
		var bs := UIK.button("Salvar", "primary")
		bs.custom_minimum_size = Vector2(150, 60)
		bs.pressed.connect(func(): Store.update_memory(id, le.text, cats[ob.selected]))
		row.add_child(bs)
		var bx := UIK.button("Apagar", "danger")
		bx.custom_minimum_size = Vector2(150, 60)
		bx.pressed.connect(func(): Store.remove_memory(id))
		row.add_child(bx)
		v.add_child(row)
		v.add_child(UIK.label("%s - %s" % [String(m.get("created", "")).substr(0, 10), String(m.get("source", ""))], 18, UIK.DIM))

func _clear_all() -> void:
	var yes: bool = await Safety.ask("Apagar toda a memoria?", ["Isso remove todas as %d lembrancas." % Store.memories.size()], "Apagar tudo", "Cancelar", true)
	if yes:
		Store.clear_memories()
