extends "res://scripts/screens/screen_base.gd"
# Gerenciador de modelos: tamanho, espaco livre, download com progresso/retomada, carregar, testar, apagar e baixar de novo.

var _info: Label
var _list: VBoxContainer
var _test_out: Label
var _local: Dictionary = {}
var _downloads: Dictionary = {}
var _cards: Dictionary = {}
var _custom_url: LineEdit
var _custom_family := "chatml"
var _imp_label: Label
var _imp_bar: ProgressBar
var _imp_cancel: Button

func _init() -> void:
	title_text = "Modelos de IA"

func _ready() -> void:
	super._ready()
	Bridge.evt.connect(_on_evt)
	Llm.state_changed.connect(_refresh)
	Llm.import_changed.connect(_update_import)

func _exit_tree() -> void:
	if Bridge.evt.is_connected(_on_evt):
		Bridge.evt.disconnect(_on_evt)
	if Llm.state_changed.is_connected(_refresh):
		Llm.state_changed.disconnect(_refresh)
	if Llm.import_changed.is_connected(_update_import):
		Llm.import_changed.disconnect(_update_import)

func build() -> void:
	_info = UIK.label("", 22, UIK.DIM)
	body.add_child(_info)
	if not Bridge.available:
		var why := UIK.label("%s\nNao e possivel baixar, selecionar nem executar modelos sem o plugin." % Bridge.status_text(), 22, UIK.AMBER)
		why.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		body.add_child(why)
	if Bridge.available:
		_build_import()
	_list = VBoxContainer.new()
	_list.add_theme_constant_override("separation", 14)
	body.add_child(_list)
	_test_out = UIK.label("", 22, UIK.TEXT)
	body.add_child(_test_out)
	_build_custom()
	_refresh()

func _all_models() -> Array:
	var arr: Array = Persona.catalog.duplicate()
	for m in Cfg.get_v("custom_models"):
		if typeof(m) == TYPE_DICTIONARY:
			arr.append(m)
	# Arquivos .gguf que ja estao no aparelho mas nao constam no catalogo (ex.: escolhidos pelo seletor de arquivos)
	var known := {}
	for m in arr:
		known[String(m.get("filename", ""))] = true
	for fn in _local:
		if not known.has(fn):
			arr.append({"id": "local_" + String(fn), "name": String(fn), "filename": String(fn), "size_bytes": float(_local[fn].get("size", 0)),
				"license": "?", "family": Persona.family_for(String(fn)), "note": "Arquivo local (importado)", "local_only": true})
	return arr

func _refresh() -> void:
	if not is_inside_tree() or _list == null:
		return
	_local = {}
	if Bridge.available:
		var r = Bridge.api("llm_list_models")
		if typeof(r) == TYPE_DICTIONARY:
			for m in r.get("models", []):
				_local[String(m["name"])] = m
	var dev := Bridge.refresh_device(0.0)
	_info.text = "Espaco livre: %s   RAM livre: %s de %s\nModelo ativo: %s%s" % [
		_mb_txt(dev, "storage_free_mb"), _mb_txt(dev, "ram_avail_mb"), _mb_txt(dev, "ram_total_mb"),
		Llm.model_name if Llm.loaded else "nenhum", ("  (carregando...)" if Llm.loading else "")]
	_info.text += "\nFonte dos dados: %s" % ("plugin Android" if String(dev.get("source", "")) == "plugin" else "leitura direta do Godot (plugin ausente)")
	_render()

# Mostra "indisponivel" quando o dado nao pode ser lido (nunca um 0 falso).
func _mb_txt(dev: Dictionary, key: String) -> String:
	if not dev.has(key):
		return "indisponivel"
	return U.fmt_bytes(float(dev[key]) * 1048576.0)

func _render() -> void:
	for c in _list.get_children():
		c.queue_free()
	_cards.clear()
	for m in _all_models():
		_make_card(m)

func _make_card(m: Dictionary) -> void:
	var fn := String(m["filename"])
	var loc: Dictionary = _local.get(fn, {})
	var dl: Dictionary = _downloads.get(fn, {})
	var downloading: bool = dl.get("state", "") in ["starting", "downloading", "verifying"]
	var active := Llm.loaded and Llm.model_name == fn
	var v := UIK.card(_list)
	v.add_child(UIK.label(String(m["name"]), 28, UIK.GREEN if active else UIK.CYAN))
	if String(m.get("note", "")) != "":
		v.add_child(UIK.label(String(m["note"]), 21, UIK.DIM))
	var size_txt := "~" + U.fmt_bytes(float(m.get("size_bytes", 0))) if float(m.get("size_bytes", 0)) > 0 else "tamanho informado ao iniciar"
	if m.get("local_only", false):
		v.add_child(UIK.label("Tamanho: %s   Formato de chat: %s" % [U.fmt_bytes(float(m.get("size_bytes", 0))), String(m.get("family", "chatml"))], 21, UIK.DIM))
	else:
		v.add_child(UIK.label("Download: %s   Licenca: %s   Formato: %s" % [size_txt, String(m.get("license", "?")), String(m.get("family", "chatml"))], 21, UIK.DIM))
	var st := UIK.label("", 23, UIK.TEXT)
	v.add_child(st)
	var bar := ProgressBar.new()
	bar.show_percentage = false
	bar.custom_minimum_size = Vector2(0, 14)
	bar.add_theme_stylebox_override("background", UIK.sb(Color(1, 1, 1, 0.08), Color(0, 0, 0, 0), 6, 0, 0))
	bar.add_theme_stylebox_override("fill", UIK.sb(UIK.CYAN, Color(0, 0, 0, 0), 6, 0, 0))
	bar.visible = downloading
	v.add_child(bar)
	_cards[fn] = {"status": st, "bar": bar}
	_set_status(fn)
	var fl := HFlowContainer.new()
	fl.add_theme_constant_override("h_separation", 10)
	fl.add_theme_constant_override("v_separation", 10)
	v.add_child(fl)
	var have: bool = loc.has("name") and not loc.get("partial", false)
	var partial: bool = loc.has("name") and loc.get("partial", false)
	if not Bridge.available:
		return
	if downloading:
		_btn(fl, "Pausar", func(): Bridge.api("llm_download_cancel", [fn, false]))
		_btn(fl, "Cancelar", func(): Bridge.api("llm_download_cancel", [fn, true]), "danger")
	elif have:
		if active:
			_btn(fl, "Descarregar", func(): Llm.unload())
			_btn(fl, "Testar resposta", func(): _test(m), "primary")
		else:
			_btn(fl, "Carregar", func(): _load(m), "primary")
		if not m.get("local_only", false):
			_btn(fl, "Baixar de novo", func(): _redownload(m))
		_btn(fl, "Apagar", func(): _delete(m), "danger")
	elif partial:
		_btn(fl, "Continuar download", func(): _download(m), "primary")
		_btn(fl, "Apagar parcial", func(): _delete(m), "danger")
	else:
		_btn(fl, "Baixar", func(): _download(m), "primary")

func _btn(parent: Node, text: String, cb: Callable, kind: String = "ghost") -> void:
	var b := UIK.button(text, kind)
	b.custom_minimum_size = Vector2(0, 64)
	b.pressed.connect(cb)
	parent.add_child(b)

func _set_status(fn: String) -> void:
	if not _cards.has(fn):
		return
	var st: Label = _cards[fn]["status"]
	var bar: ProgressBar = _cards[fn]["bar"]
	var loc: Dictionary = _local.get(fn, {})
	var dl: Dictionary = _downloads.get(fn, {})
	var s := String(dl.get("state", ""))
	if s == "downloading" or s == "starting":
		var total := float(dl.get("total", 0))
		var done := float(dl.get("downloaded", 0))
		var pct := (done / total * 100.0) if total > 0.0 else 0.0
		bar.visible = true
		bar.value = pct
		st.text = "Baixando %.0f%% - %s de %s - %s/s" % [pct, U.fmt_bytes(done), U.fmt_bytes(total), U.fmt_bytes(float(dl.get("speed_bps", 0)))] if total > 0.0 else "Iniciando download..."
		st.add_theme_color_override("font_color", UIK.AMBER)
	elif s == "verifying":
		bar.visible = true
		bar.value = 100
		st.text = "Verificando integridade do arquivo..."
	elif s == "error":
		st.text = "Erro no download: %s" % _err_text(String(dl.get("error", "")), String(dl.get("detail", "")))
		st.add_theme_color_override("font_color", UIK.RED)
	elif Llm.loaded and Llm.model_name == fn:
		st.text = "ATIVO - carregado na memoria (contexto %d)" % Llm.n_ctx
		st.add_theme_color_override("font_color", UIK.GREEN)
	elif Llm.loading and Cfg.get_v("model_file") == fn:
		st.text = "Carregando na memoria..."
		st.add_theme_color_override("font_color", UIK.AMBER)
	elif loc.has("name") and not loc.get("partial", false):
		st.text = "Baixado (%s). Pronto para carregar." % U.fmt_bytes(float(loc.get("size", 0)))
	elif loc.has("name"):
		st.text = "Download parcial: %s (pode continuar)" % U.fmt_bytes(float(loc.get("size", 0)))
		st.add_theme_color_override("font_color", UIK.AMBER)
	else:
		st.text = "Nao baixado"
		st.add_theme_color_override("font_color", UIK.DIM)
	if Llm.last_error != "" and not Llm.loaded and Cfg.get_v("model_file") == fn and not Llm.loading:
		st.text += "\nErro ao carregar: " + Llm.last_error
		st.add_theme_color_override("font_color", UIK.RED)

func _err_text(code: String, detail: String) -> String:
	match code:
		"no_space":
			return "espaco insuficiente (%s)" % detail
		"io_error":
			return "falha de rede ou arquivo. Toque em Continuar para retomar."
		"checksum", "corrupt":
			return "arquivo corrompido; baixe de novo."
		"incomplete":
			return "download incompleto; toque em Continuar."
	if code.begins_with("http_"):
		return "servidor respondeu " + code.substr(5)
	return code + " " + detail

func _on_evt(ev: String, d: Dictionary) -> void:
	if ev == "model_import" and String(d.get("state", "")) in ["done", "error", "cancelled"]:
		_refresh()
		return
	if ev != "download":
		return
	var id := String(d.get("id", ""))
	_downloads[id] = d
	var st := String(d.get("state", ""))
	if st in ["done", "error", "cancelled"]:
		_refresh()
	elif _cards.has(id):
		_set_status(id)

func _free_bytes() -> float:
	return float(Bridge.refresh_device(0.0).get("storage_free_mb", 0)) * 1048576.0

func _download(m: Dictionary) -> void:
	if not Bridge.available or not m.has("url"):
		return
	var fn := String(m["filename"])
	var part := float(_local.get(fn, {}).get("size", 0)) if _local.get(fn, {}).get("partial", false) else 0.0
	var need := maxf(0.0, float(m.get("size_bytes", 0)) * 1.05 - part) + 100.0 * 1048576.0
	var free := _free_bytes()
	if float(m.get("size_bytes", 0)) > 0.0 and free < need:
		_downloads[fn] = {"state": "error", "error": "no_space", "detail": "livre %s, necessario %s" % [U.fmt_bytes(free), U.fmt_bytes(need)]}
		_render()
		return
	if not Bridge.is_online():
		_downloads[fn] = {"state": "error", "error": "io_error", "detail": "sem internet"}
		_render()
		return
	var lines: Array = ["%s" % String(m["name"]),
		"Tamanho: %s" % (("~" + U.fmt_bytes(float(m.get("size_bytes", 0)))) if float(m.get("size_bytes", 0)) > 0 else "informado pelo servidor"),
		"Espaco livre: %s" % U.fmt_bytes(free), "Fonte: %s" % String(m["url"]).get_slice("/", 2)]
	if bool(Bridge.refresh_device(0.0).get("metered", false)):
		lines.append("Atencao: voce parece estar em dados moveis.")
	var yes: bool = await Safety.ask("Baixar modelo?", lines, "Baixar", "Cancelar")
	if not yes:
		return
	_downloads.erase(fn)
	Bridge.api("llm_download", [JSON.stringify({"id": fn, "url": m["url"], "filename": fn, "expected_bytes": int(m.get("size_bytes", 0)), "sha256": String(m.get("sha256", ""))})])
	_downloads[fn] = {"state": "starting", "downloaded": 0, "total": float(m.get("size_bytes", 0))}
	_render()

func _load(m: Dictionary) -> void:
	var fn := String(m["filename"])
	var dev := Bridge.refresh_device(0.0)
	var size := float(_local.get(fn, {}).get("size", 0))
	if float(dev.get("ram_avail_mb", 99999)) * 1048576.0 < size * 0.9:
		var go: bool = await Safety.ask("Pouca memoria livre", ["A RAM livre (%s) parece menor que o modelo (%s). Pode travar ou fechar outros apps." % [U.fmt_bytes(float(dev.get("ram_avail_mb", 0)) * 1048576.0), U.fmt_bytes(size)], "Carregar mesmo assim?"], "Carregar", "Cancelar", true)
		if not go:
			return
	Cfg.set_v("model_file", fn)
	Cfg.set_v("model_family", String(m.get("family", "chatml")))
	if int(m.get("n_ctx", 0)) > 0:
		Cfg.set_v("n_ctx", int(m["n_ctx"]))
	Llm.load_model(fn)
	_refresh()

func _delete(m: Dictionary) -> void:
	var yes: bool = await Safety.ask("Apagar modelo?", ["%s sera removido do aparelho. Voce pode baixar de novo depois." % String(m["name"])], "Apagar", "Cancelar", true)
	if not yes:
		return
	var fn := String(m["filename"])
	if Llm.model_name == fn:
		Llm.unload()
	Bridge.api("llm_download_cancel", [fn, true])
	Bridge.api("llm_delete_model", [fn])
	_downloads.erase(fn)
	if Cfg.get_v("model_file") == fn:
		Cfg.set_v("model_file", "")
	await get_tree().create_timer(0.4).timeout
	_refresh()

func _redownload(m: Dictionary) -> void:
	if not m.has("url"):
		return
	var yes: bool = await Safety.ask("Baixar de novo?", ["O arquivo atual sera apagado e baixado novamente."], "Continuar", "Cancelar", true)
	if not yes:
		return
	var fn := String(m["filename"])
	if Llm.model_name == fn:
		Llm.unload()
	Bridge.api("llm_delete_model", [fn])
	_local.erase(fn)
	await get_tree().create_timer(0.5).timeout
	_download(m)

func _test(m: Dictionary) -> void:
	_test_out.text = "Testando o modelo..."
	var family := Persona.family_for(Llm.model_name)
	var prompt := Persona.format_prompt("Voce e um assistente. Responda sempre em portugues do Brasil, de forma curta.", [{"role": "user", "text": "Diga ola e explique em uma frase o que voce faz."}], family)
	var info: Dictionary = await Llm.generate_wait(prompt, {"max_tokens": 64, "temperature": 0.3, "stop": Persona.stop_sequences(family)})
	var stats: Dictionary = info.get("stats", {})
	if String(info.get("reason", "")) == "error":
		_test_out.text = "Falhou: %s" % String(info.get("error", "erro"))
	else:
		_test_out.text = "Resposta: %s\n[%.1f tokens/s, prompt %d tokens, %d reaproveitados]" % [String(info.get("text", "")).strip_edges(), float(stats.get("tps", 0)), int(stats.get("n_prompt", 0)), int(stats.get("n_reused", 0))]

func _build_custom() -> void:
	UIK.section(body, "Adicionar modelo (GGUF)")
	var c := UIK.card(body)
	c.add_child(UIK.label("Cole o link https direto de um arquivo .gguf (instrucao/chat, ate ~2 GB). Confira a licenca do modelo antes de usar.", 21, UIK.DIM))
	_custom_url = LineEdit.new()
	_custom_url.placeholder_text = "https://.../modelo-q4_k_m.gguf"
	_custom_url.custom_minimum_size = Vector2(0, 68)
	c.add_child(_custom_url)
	var ob := OptionButton.new()
	ob.add_item("Formato de chat: ChatML (Qwen e similares)", 0)
	ob.add_item("Formato de chat: Llama 3", 1)
	ob.add_item("Formato de chat: Gemma", 2)
	ob.custom_minimum_size = Vector2(0, 64)
	ob.item_selected.connect(func(i): _custom_family = ["chatml", "llama3", "gemma"][i])
	c.add_child(ob)
	var b := UIK.button("Adicionar a lista", "primary")
	b.pressed.connect(_add_custom)
	c.add_child(b)

func _add_custom() -> void:
	var url := _custom_url.text.strip_edges()
	var path: String = url.split("?")[0]
	if not url.begins_with("https://") or not path.to_lower().ends_with(".gguf"):
		toast("Use um link https que termine em .gguf")
		return
	var fn := path.get_file()
	var list: Array = Cfg.get_v("custom_models").duplicate()
	list.append({"id": "custom_" + fn, "name": fn, "filename": fn, "url": url, "size_bytes": 0, "license": "definida pelo autor", "family": _custom_family, "note": "Modelo personalizado"})
	Cfg.set_v("custom_models", list)
	_custom_url.text = ""
	_refresh()

# ---------------- usar um arquivo GGUF ja existente no aparelho ----------------
func _build_import() -> void:
	UIK.section(body, "Usar arquivo GGUF do aparelho")
	var c := UIK.card(body)
	c.add_child(UIK.label("Ja tem o arquivo qwen2.5-1.5b-instruct-q4_k_m.gguf? Toque em Selecionar e escolha o arquivo no seletor do Android (Downloads, cartao SD, etc.). Ele e copiado para o armazenamento privado do Jarvis e carregado automaticamente.", 21, UIK.DIM))
	var fl := HFlowContainer.new()
	fl.add_theme_constant_override("h_separation", 10)
	fl.add_theme_constant_override("v_separation", 10)
	c.add_child(fl)
	_btn(fl, "Selecionar arquivo GGUF", func(): _pick(), "primary")
	_btn(fl, "Procurar na pasta models do app", func(): _scan_external())
	_imp_label = UIK.label("", 22, UIK.TEXT)
	c.add_child(_imp_label)
	_imp_bar = ProgressBar.new()
	_imp_bar.show_percentage = false
	_imp_bar.custom_minimum_size = Vector2(0, 14)
	_imp_bar.add_theme_stylebox_override("background", UIK.sb(Color(1, 1, 1, 0.08), Color(0, 0, 0, 0), 6, 0, 0))
	_imp_bar.add_theme_stylebox_override("fill", UIK.sb(UIK.CYAN, Color(0, 0, 0, 0), 6, 0, 0))
	_imp_bar.visible = false
	c.add_child(_imp_bar)
	_imp_cancel = UIK.button("Cancelar copia", "danger")
	_imp_cancel.custom_minimum_size = Vector2(0, 64)
	_imp_cancel.pressed.connect(func(): Llm.cancel_import())
	_imp_cancel.visible = false
	c.add_child(_imp_cancel)
	var info = Bridge.api("llm_info")
	if typeof(info) == TYPE_DICTIONARY and String(info.get("external_models_dir", "")) != "":
		c.add_child(UIK.label("Pasta alternativa (USB/gerenciador de arquivos): %s" % String(info["external_models_dir"]), 19, UIK.DIM))
	_update_import()

func _pick() -> void:
	if Llm.importing:
		toast("Ja existe uma copia em andamento.")
		return
	if not Llm.pick_file():
		toast(Llm.last_error)

func _scan_external() -> void:
	if Llm.importing:
		toast("Ja existe uma copia em andamento.")
		return
	var r := Llm.scan_external()
	var found: Array = r["found"]
	if found.is_empty():
		toast("Nenhum .gguf em %s" % String(r["dir"]))
		return
	var pick := String(found[0].get("name", ""))
	for f in found:
		if String(f.get("name", "")).to_lower().contains("qwen2.5-1.5b"):
			pick = String(f.get("name", ""))
			break
	Llm.import_external(pick, false)

func _update_import() -> void:
	if _imp_label == null or not is_instance_valid(_imp_label):
		return
	var d: Dictionary = Llm.import_state
	var st := String(d.get("state", ""))
	_imp_bar.visible = st == "copying"
	_imp_cancel.visible = st == "copying"
	match st:
		"copying":
			var total := float(d.get("total", 0))
			var done := float(d.get("copied", 0))
			_imp_bar.value = (done / total * 100.0) if total > 0.0 else 0.0
			_imp_label.text = "Copiando %s: %s de %s (%s/s)" % [String(d.get("name", "")), U.fmt_bytes(done), U.fmt_bytes(total), U.fmt_bytes(float(d.get("speed_bps", 0)))]
			_imp_label.add_theme_color_override("font_color", UIK.AMBER)
		"done":
			_imp_label.text = "Arquivo %s copiado." % String(d.get("name", ""))
			_imp_label.add_theme_color_override("font_color", UIK.GREEN)
		"error":
			_imp_label.text = "Falha: %s" % _import_err(String(d.get("error", "")), String(d.get("detail", "")))
			_imp_label.add_theme_color_override("font_color", UIK.RED)
		"cancelled":
			_imp_label.text = "Selecao cancelada."
			_imp_label.add_theme_color_override("font_color", UIK.DIM)
		_:
			_imp_label.text = ""

func _import_err(code: String, detail: String) -> String:
	match code:
		"not_gguf":
			return "o arquivo escolhido nao e um modelo GGUF."
		"no_space":
			return "espaco insuficiente (%s)." % detail
		"in_use":
			return "esse modelo esta carregado; descarregue-o antes de substituir."
		"incomplete":
			return "copia incompleta (%s). Tente de novo." % detail
		"busy":
			return "ja existe uma copia em andamento."
	return "%s %s" % [code, detail]
