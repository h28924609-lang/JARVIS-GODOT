extends Control
# Base das telas secundarias: fundo, cabecalho com botao voltar, area rolavel (body).

const UIK = preload("res://scripts/ui/ui_kit.gd")
const U = preload("res://scripts/core/util.gd")
signal close_requested
signal navigate(screen_name)

var title_text := "Tela"
var body: VBoxContainer
var header: HBoxContainer
var _scroll: ScrollContainer

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.03, 0.06, 0.99)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var insets := UIK.safe_insets(self)
	var mg := MarginContainer.new()
	mg.set_anchors_preset(Control.PRESET_FULL_RECT)
	mg.add_theme_constant_override("margin_left", 24)
	mg.add_theme_constant_override("margin_right", 24)
	mg.add_theme_constant_override("margin_top", int(insets.x) + 8)
	mg.add_theme_constant_override("margin_bottom", int(insets.y) + 8)
	add_child(mg)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 16)
	mg.add_child(v)
	header = HBoxContainer.new()
	header.add_theme_constant_override("separation", 14)
	var back := UIK.IconBtn.new("back", 72)
	back.pressed.connect(close)
	header.add_child(back)
	var tl := UIK.label(title_text.to_upper(), 32, UIK.CYAN)
	tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	header.add_child(tl)
	v.add_child(header)
	_scroll = ScrollContainer.new()
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(_scroll)
	body = VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 14)
	_scroll.add_child(body)
	build()

# Sobrescreva nas telas.
func build() -> void:
	pass

func close() -> void:
	close_requested.emit()

func clear_body() -> void:
	for c in body.get_children():
		c.queue_free()

func toast(text: String) -> void:
	var l := UIK.label(text, 22, UIK.AMBER)
	body.add_child(l)
	body.move_child(l, 0)
	get_tree().create_timer(5.0).timeout.connect(func(): if is_instance_valid(l): l.queue_free())
