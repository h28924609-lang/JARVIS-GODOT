extends "res://scripts/screens/screen_base.gd"
# Configuracoes: assistente, IA, voz, memoria/privacidade, seguranca/controle do Android, internet opcional, sistema.

var _acc_label: Label
var _vosk_label: Label
var _voice_opt_holder: VBoxContainer
var _wake_label: Label

func _init() -> void:
	title_text = "Configuracoes"

func _ready() -> void:
	super._ready()
	Bridge.evt.connect(_on_evt)
	Voice.tts_ready_changed.connect(_fill_voices)

func _exit_tree() -> void:
	if Bridge.evt.is_connected(_on_evt):
		Bridge.evt.disconnect(_on_evt)

func build() -> void:
	var c: VBoxContainer
	# ---- Assistente ----
	UIK.section(body, "Assistente")
	c = UIK.card(body)
	UIK.row_text(c, "Nome do assistente", "assistant_name", "Jarvis", "A personalidade e independente do modelo de IA.")
	UIK.row_text(c, "Seu nome", "user_name", "Como devo chamar voce?")
	UIK.row_option(c, "Tratamento", "formality", [["Voce", "voce"], ["Senhor(a)", "senhor"]])
	UIK.row_option(c, "Tamanho das respostas", "response_len", [["Curta", "curta"], ["Media", "media"], ["Longa", "longa"]])
	UIK.row_text(c, "Instrucoes extras", "custom_instructions", "Ex.: seja bem-humorado", "Somadas a personalidade padrao.")

	# ---- IA ----
	UIK.section(body, "Inteligencia artificial local")
	c = UIK.card(body)
	var bm := UIK.button("Modelos de IA (baixar, carregar, apagar)", "primary")
	bm.pressed.connect(func(): navigate.emit("models"))
	c.add_child(bm)
	UIK.row_slider(c, "Criatividade (temperatura)", "temperature", 0.0, 1.2, 0.05, "%.2f")
	UIK.row_slider(c, "Maximo de palavras-pedaco por resposta", "max_tokens", 64, 800, 16, "%d")
	UIK.row_option(c, "Tamanho do contexto", "n_ctx", [["2048 (leve)", 2048], ["3072 (padrao)", 3072], ["4096 (mais memoria)", 4096]],
		func(_v): toast("Recarregue o modelo para aplicar."))
	UIK.row_option(c, "Threads de CPU", "threads", [["2", 2], ["3", 3], ["4 (padrao)", 4], ["5", 5], ["6", 6]],
		func(v): if Bridge.available: Bridge.plugin.llm_set_threads(int(v)))
	UIK.row_option(c, "Descarregar apos inatividade", "idle_unload_min", [["Nunca", 0], ["5 min", 5], ["10 min", 10], ["30 min", 30]])
	UIK.row_toggle(c, "Protecao termica", "Reduz a velocidade ou para se o aparelho esquentar.", "thermal_guard")
	UIK.row_toggle(c, "Modo economia", "Reduz animacoes quando o app fica parado.", "eco_mode")

	# ---- Voz ----
	UIK.section(body, "Voz")
	c = UIK.card(body)
	UIK.row_toggle(c, "Falar as respostas", "", "tts_enabled")
	UIK.row_toggle(c, "Falar por frases", "Comeca a falar enquanto a resposta ainda esta sendo gerada.", "speak_sentences")
	_voice_opt_holder = VBoxContainer.new()
	c.add_child(_voice_opt_holder)
	_fill_voices()
	UIK.row_slider(c, "Velocidade da voz", "tts_rate", 0.6, 1.6, 0.05, "%.2f")
	UIK.row_slider(c, "Tom da voz", "tts_pitch", 0.6, 1.6, 0.05, "%.2f")
	UIK.row_slider(c, "Volume da voz do Jarvis", "tts_volume", 0.0, 1.0, 0.05, "%.2f")
	_media_volume_row(c)
	UIK.row_button(c, "Testar voz", "Falar", func():
		Voice.apply_settings()
		Voice.speak("Ola, eu sou %s. Esta e a minha voz." % Persona.assistant_name(), false))
	UIK.row_button(c, "Vozes do Android", "Abrir", _open_tts_settings, "ghost", "Instale vozes pt-BR offline nas configuracoes de texto para fala.")
	UIK.row_option(c, "Reconhecimento de voz", "stt_engine", [["Android (Google/Samsung)", "android"], ["Vosk (offline embutido)", "vosk"]])
	UIK.row_toggle(c, "Preferir offline", "Usa o pacote de idioma pt-BR instalado, sem internet.", "stt_prefer_offline")
	UIK.row_toggle(c, "Somente no aparelho", "Exige reconhecimento 100% local (Android 13+, pacote pt-BR instalado).", "stt_on_device_only")
	UIK.row_toggle(c, "Enviar ao terminar de falar", "", "auto_send_voice")
	UIK.row_toggle(c, "Conversa continua", "Volta a ouvir depois de responder.", "continuous_conversation")
	UIK.row_toggle(c, "Palavra de ativacao \"Jarvis\"", "Experimental. Usa Vosk offline e mantem o microfone ligado.", "wake_enabled", _apply_wake)
	UIK.row_toggle(c, "Escutar em segundo plano", "Servico com notificacao. O Android pode limitar; nao funciona de forma irrestrita com a tela bloqueada.", "wake_background", _apply_wake)
	_vosk_label = UIK.label("", 21, UIK.DIM)
	c.add_child(_vosk_label)
	_wake_label = UIK.label("", 21, UIK.DIM)
	c.add_child(_wake_label)
	UIK.row_button(c, "Modelo de voz offline (Vosk, ~31 MB)", "Baixar", _vosk_download)
	_refresh_vosk()

	# ---- Memoria e privacidade ----
	UIK.section(body, "Memoria e privacidade")
	c = UIK.card(body)
	UIK.row_toggle(c, "Memoria ativada", "Fatos que voce autorizar, guardados so neste aparelho.", "memory_enabled")
	UIK.row_toggle(c, "Sempre perguntar antes de salvar", "", "memory_ask_before_save")
	UIK.row_toggle(c, "Salvar historico de conversas", "", "save_history")
	var b1 := UIK.button("Gerenciar memoria")
	b1.pressed.connect(func(): navigate.emit("memory"))
	c.add_child(b1)
	var b2 := UIK.button("Ver historico")
	b2.pressed.connect(func(): navigate.emit("history"))
	c.add_child(b2)

	# ---- Seguranca e Android ----
	UIK.section(body, "Controle do Android e seguranca")
	c = UIK.card(body)
	UIK.row_toggle(c, "Permitir acoes no celular", "Abrir apps, tocar, digitar e rolar, sempre por ferramentas controladas.", "tools_enabled")
	UIK.row_toggle(c, "Confirmar TODAS as acoes", "Pede confirmacao ate para acoes simples.", "confirm_all_actions")
	c.add_child(UIK.label("Apps bancarios e financeiros, campos de senha e telas de permissao sao sempre bloqueados.", 21, UIK.DIM))
	_acc_label = UIK.label("", 22, UIK.TEXT)
	c.add_child(_acc_label)
	UIK.row_button(c, "Servico de acessibilidade", "Abrir", func(): if Bridge.available: Bridge.plugin.open_accessibility_settings())
	c.add_child(UIK.label("Se o botao de ativar estiver cinza: Configuracoes do Android > Apps > Jarvis > menu de 3 pontos > Permitir configuracoes restritas.", 20, UIK.DIM))
	var blocked := ", ".join(Cfg.get_v("blocked_extra"))
	var le := LineEdit.new()
	le.text = blocked
	le.placeholder_text = "Apps extras bloqueados (nomes ou pacotes, separados por virgula)"
	le.custom_minimum_size = Vector2(0, 68)
	le.text_changed.connect(_on_blocked_changed)
	c.add_child(le)
	UIK.row_button(c, "Microfone", "Permitir", func(): Bridge.request_permissions(["RECORD_AUDIO"]))
	UIK.row_button(c, "Notificacoes (confirmacoes)", "Permitir", func(): Bridge.request_permissions(["POST_NOTIFICATIONS"]))
	UIK.row_button(c, "Ajustes do app no Android", "Abrir", func(): if Bridge.available: Bridge.plugin.open_app_details())
	_refresh_acc()

	# ---- Internet ----
	UIK.section(body, "Internet (opcional)")
	c = UIK.card(body)
	c.add_child(UIK.label("A IA funciona 100% offline. Aqui voce libera consultas pontuais; o historico nunca e enviado.", 21, UIK.DIM))
	UIK.row_toggle(c, "Permitir consultas externas", "", "internet_enabled")
	UIK.row_toggle(c, "Wikipedia (pt)", "Envia apenas o termo pesquisado.", "internet_wikipedia")
	UIK.row_toggle(c, "Clima (Open-Meteo)", "Envia apenas o nome da cidade.", "internet_weather")
	UIK.row_toggle(c, "Perguntar a cada consulta", "", "internet_always_ask")

	# ---- Sistema ----
	UIK.section(body, "Sistema")
	c = UIK.card(body)
	UIK.row_toggle(c, "Manter tela ligada", "", "keep_screen_on", func(v): if Bridge.available: Bridge.plugin.keep_screen_on(bool(v)))
	var bd := UIK.button("Diagnostico e autoteste", "primary")
	bd.pressed.connect(func(): navigate.emit("diagnostics"))
	c.add_child(bd)
	var br := UIK.button("Restaurar configuracoes padrao", "danger")
	br.pressed.connect(_reset)
	c.add_child(br)
	body.add_child(UIK.spacer(40))

func _open_tts_settings() -> void:
	if Bridge.available:
		Bridge.plugin.open_tts_settings()

func _fill_voices() -> void:
	if _voice_opt_holder == null:
		return
	for ch in _voice_opt_holder.get_children():
		ch.queue_free()
	var opts: Array = [["Automatica", ""]]
	for v in Voice.voices:
		opts.append(["%s%s" % [String(v.get("name", "")), "" if v.get("offline", true) else " (online)"], String(v.get("name", ""))])
	if opts.size() == 1:
		_voice_opt_holder.add_child(UIK.label("Nenhuma voz pt-BR encontrada. Instale uma em \"Vozes do Android\".", 21, UIK.AMBER))
	UIK.row_option(_voice_opt_holder, "Voz", "tts_voice", opts)

func _media_volume_row(c: VBoxContainer) -> void:
	c.add_child(UIK.label("Volume do aparelho (midia)", 26))
	var s := HSlider.new()
	s.min_value = 0
	s.max_value = 100
	s.step = 1
	s.custom_minimum_size = Vector2(0, 48)
	if Bridge.available:
		s.value = float(Bridge.plugin.get_media_volume())
	s.value_changed.connect(func(v): if Bridge.available: Bridge.plugin.set_media_volume(int(v)))
	c.add_child(s)

func _apply_wake(_v) -> void:
	var r: Dictionary = Voice.apply_wake_settings()
	if r.get("ok", false):
		_wake_label.text = "Palavra de ativacao: " + ("ligada" if Cfg.get_v("wake_enabled") else "desligada")
	else:
		_wake_label.text = "Palavra de ativacao indisponivel: %s %s" % [str(r.get("error", "")), str(r.get("detail", ""))]
		if Cfg.get_v("wake_enabled"):
			Cfg.set_v("wake_enabled", false)

func _refresh_vosk() -> void:
	if not Bridge.available:
		_vosk_label.text = "Plugin ausente."
		return
	var r = Bridge.api("vosk_status")
	if typeof(r) == TYPE_DICTIONARY:
		_vosk_label.text = "Vosk: biblioteca %s, modelo %s." % ["ok" if r.get("library", false) else "ausente", "instalado" if r.get("model_ready", false) else "nao instalado"]

func _vosk_download() -> void:
	if Bridge.available:
		Bridge.api("vosk_download")
		_vosk_label.text = "Baixando modelo Vosk..."

func _on_evt(ev: String, d: Dictionary) -> void:
	if ev == "vosk_download":
		var st := String(d.get("state", ""))
		if st == "downloading":
			_vosk_label.text = "Baixando Vosk: %s / %s" % [U.fmt_bytes(float(d.get("downloaded", 0))), U.fmt_bytes(float(d.get("total", 0)))]
		elif st == "done":
			_refresh_vosk()
		elif st == "error":
			_vosk_label.text = "Falha no download do Vosk: %s" % String(d.get("error", ""))
		elif st == "installing":
			_vosk_label.text = "Instalando modelo..."
	elif ev == "wake_status" and not d.get("active", true):
		_wake_label.text = "Palavra de ativacao parou: %s" % String(d.get("message", ""))

func _refresh_acc() -> void:
	if not Bridge.available:
		_acc_label.text = "Acessibilidade: plugin ausente."
		return
	var r = Bridge.api("accessibility_status")
	if typeof(r) == TYPE_DICTIONARY:
		_acc_label.text = "Acessibilidade: %s" % ("ATIVA" if r.get("connected", false) else ("habilitada, conectando..." if r.get("enabled_in_settings", false) else "desativada"))

func _on_blocked_changed(tx: String) -> void:
	var arr: Array = []
	for p in tx.split(",", false):
		var q := String(p).strip_edges()
		if q != "":
			arr.append(q)
	Cfg.set_v("blocked_extra", arr)
	if Bridge.available:
		Bridge.api("set_blocked_packages", [JSON.stringify(arr)])

func _reset() -> void:
	var yes: bool = await Safety.ask("Restaurar padroes?", ["Todas as configuracoes voltam ao padrao. Memorias e historico nao sao apagados."], "Restaurar", "Cancelar", true)
	if yes:
		Cfg.reset_all()
		clear_body()
		build()
