extends Control
# Fundo HUD: gradiente escuro, grade sutil, linha de varredura e colchetes nos cantos.

var _t := 0.0
var _acc := 0.0
var enabled_anim := true

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta: float) -> void:
	if not enabled_anim:
		return
	_t += delta
	_acc += delta
	if _acc >= 0.05:
		_acc = 0.0
		queue_redraw()

func _draw() -> void:
	var w := size.x
	var h := size.y
	draw_rect(Rect2(0, 0, w, h), Color(0.02, 0.03, 0.06))
	var ctr := Vector2(w * 0.5, h * 0.36)
	for i in range(6):
		draw_circle(ctr, w * (0.25 + i * 0.12), Color(0.04, 0.18, 0.28, 0.05))
	var step := 72.0
	var x := 0.0
	while x < w:
		draw_line(Vector2(x, 0), Vector2(x, h), Color(0.1, 0.89, 1.0, 0.025), 1.0)
		x += step
	var y := 0.0
	while y < h:
		draw_line(Vector2(0, y), Vector2(w, y), Color(0.1, 0.89, 1.0, 0.025), 1.0)
		y += step
	var sy := fmod(_t * 70.0, h)
	draw_rect(Rect2(0, sy, w, 3), Color(0.1, 0.89, 1.0, 0.045))
	var m := 14.0
	var L := 52.0
	var cc := Color(0.1, 0.89, 1.0, 0.5)
	for corner in [[Vector2(m, m), 1, 1], [Vector2(w - m, m), -1, 1], [Vector2(m, h - m), 1, -1], [Vector2(w - m, h - m), -1, -1]]:
		var p: Vector2 = corner[0]
		var sx: float = corner[1]
		var sy2: float = corner[2]
		draw_line(p, p + Vector2(L * sx, 0), cc, 3.0)
		draw_line(p, p + Vector2(0, L * sy2), cc, 3.0)
