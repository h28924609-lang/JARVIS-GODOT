extends Control
# Nucleo de IA animado: aneis rotativos, brilho pulsante e efeitos por estado
# (idle, listening, thinking, speaking, acting, error). Desenhado por codigo (sem imagens).

signal tapped

const COLORS := {
	"idle": Color(0.10, 0.89, 1.00), "listening": Color(0.24, 1.00, 0.75), "thinking": Color(1.00, 0.69, 0.13),
	"speaking": Color(0.45, 0.72, 1.00), "acting": Color(0.80, 0.52, 1.00), "error": Color(1.00, 0.30, 0.42)
}
const SPEED_A := {"idle": 0.25, "listening": 0.55, "thinking": 1.6, "speaking": 0.7, "acting": 1.1, "error": 0.2}

var state := "idle"
var level := 0.0
var quality := 1.0   # 1.0 normal, 0.5 economia
var _t := 0.0
var _col: Color = COLORS["idle"]
var _lvl := 0.0
var _rot_a := 0.0
var _rot_b := 0.0
var _acc := 0.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP

func set_state(s: String) -> void:
	state = s if COLORS.has(s) else "idle"

func _gui_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT and e.pressed:
		tapped.emit()

func _process(delta: float) -> void:
	_t += delta
	_col = _col.lerp(COLORS[state], minf(1.0, delta * 6.0))
	_lvl = lerpf(_lvl, level, minf(1.0, delta * 10.0))
	var sp: float = SPEED_A[state]
	_rot_a += delta * sp
	_rot_b -= delta * sp * 0.6
	_acc += delta
	var step := 0.016 if quality >= 1.0 else 0.04
	if _acc >= step:
		_acc = 0.0
		queue_redraw()

func _col_a(a: float) -> Color:
	return Color(_col.r, _col.g, _col.b, a)

func _draw() -> void:
	var c := size / 2.0
	var R := minf(size.x, size.y) * 0.46
	var pulse := 1.0
	match state:
		"idle":
			pulse = 1.0 + 0.015 * sin(_t * 1.4)
		"listening":
			pulse = 1.0 + 0.06 * _lvl + 0.015 * sin(_t * 6.0)
		"thinking":
			pulse = 1.0 + 0.03 * sin(_t * 5.0)
		"speaking":
			pulse = 1.0 + 0.04 * absf(sin(_t * 7.0)) * (0.6 + 0.4 * sin(_t * 2.3))
		"acting":
			pulse = 1.0 + 0.025 * sin(_t * 4.0)
		"error":
			pulse = 1.0 + 0.05 * sin(_t * 30.0)
	# brilho de fundo
	for i in range(7):
		var r := R * (0.5 + i * 0.09) * pulse
		draw_circle(c, r, _col_a(0.055 * (1.0 - i / 7.0) + 0.01))
	# anel externo tracejado
	var segs := int(36 * quality)
	var seg_len := TAU / segs * 0.6
	for i in range(segs):
		var a0 := _rot_a + i * TAU / segs
		draw_arc(c, R * 0.98, a0, a0 + seg_len, 6, _col_a(0.85 if i % 6 != 0 else 0.35), 3.0, true)
	# arcos longos contra-rotativos
	for i in range(3):
		var a1 := _rot_b * 1.4 + i * TAU / 3.0
		draw_arc(c, R * 0.86, a1, a1 + 1.25, 20, _col_a(0.75), 5.0, true)
	# marcas (ticks)
	var ticks := int(72 * quality)
	for i in range(ticks):
		var a2 := _rot_a * 0.5 + i * TAU / ticks
		var d := Vector2(cos(a2), sin(a2))
		var long := (i % 6 == 0)
		draw_line(c + d * R * (0.72 if long else 0.75), c + d * R * 0.80, _col_a(0.6 if long else 0.28), 2.0 if long else 1.0)
	# anel interno e nucleo
	draw_arc(c, R * 0.62 * pulse, 0, TAU, 64, _col_a(0.55), 2.0, true)
	draw_circle(c, R * 0.30 * pulse, _col_a(0.22))
	draw_circle(c, R * 0.19 * pulse, _col_a(0.55))
	draw_circle(c, R * 0.09 * pulse, Color(0.9, 1.0, 1.0, 0.95))
	# efeitos por estado
	match state:
		"listening":
			for k in range(3):
				var ph := fmod(_t * 0.9 + k / 3.0, 1.0)
				draw_arc(c, R * (0.3 + 0.7 * ph) * (1.0 + 0.1 * _lvl), 0, TAU, 64, _col_a((1.0 - ph) * 0.5), 2.5, true)
		"thinking":
			for i in range(8):
				var ang := _t * 2.4 + i * TAU / 8.0
				var rad := 3.0 + 5.0 * (0.5 + 0.5 * sin(ang * 1.0 - _t * 3.0))
				draw_circle(c + Vector2(cos(ang), sin(ang)) * R * 0.70, rad, _col_a(0.9))
		"speaking":
			var pts := PackedVector2Array()
			var n := 96
			var amp := R * 0.06 * (0.35 + 0.65 * absf(sin(_t * 6.5)))
			for i in range(n + 1):
				var a3 := i * TAU / n
				var rr := R * 0.50 + amp * sin(a3 * 7.0 + _t * 9.0) * sin(a3 * 3.0 - _t * 4.0)
				pts.append(c + Vector2(cos(a3), sin(a3)) * rr)
			draw_polyline(pts, _col_a(0.95), 3.0, true)
		"acting":
			for i in range(6):
				var a4 := _t * 1.6 + i * TAU / 6.0
				var d2 := Vector2(cos(a4), sin(a4))
				draw_line(c + d2 * R * 0.30, c + d2 * R * 0.58, _col_a(0.8), 3.0)
		"error":
			draw_arc(c, R * 0.70, 0, TAU, 64, Color(1, 0.3, 0.42, 0.4 + 0.4 * sin(_t * 24.0)), 4.0, true)
