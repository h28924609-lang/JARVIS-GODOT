extends RefCounted
# Kit de interface futurista: cores, tema, componentes (icones desenhados por codigo, toggle, cartoes, linhas de configuracao).

const BG := Color("05080f")
const PANEL := Color(0.043, 0.075, 0.125, 0.90)
const PANEL2 := Color(0.06, 0.11, 0.17, 0.95)
const CYAN := Color("19e3ff")
const AMBER := Color("ffb020")
const GREEN := Color("3dffa2")
const RED := Color("ff4d6a")
const TEXT := Color("d6f6ff")
const DIM := Color("7fa3b5")
const LINE := Color(0.10, 0.89, 1.0, 0.30)

static func sb(bg: Color, border: Color = Color(0, 0, 0, 0), radius: int = 16, bw: int = 0, pad: int = 12) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(pad)
	s.anti_aliasing = true
	return s

static func circle_tex(d: int, col: Color) -> ImageTexture:
	var img := Image.create(d, d, false, Image.FORMAT_RGBA8)
	var c := Vector2(d / 2.0, d / 2.0)
	var r := d / 2.0 - 1.0
	for y in range(d):
		for x in range(d):
			var dist := Vector2(x + 0.5, y + 0.5).distance_to(c)
			var a: float = clampf(r - dist + 0.5, 0.0, 1.0)
			img.set_pixel(x, y, Color(col.r, col.g, col.b, a))
	return ImageTexture.create_from_image(img)

static func make_theme() -> Theme:
	var t := Theme.new()
	t.default_font_size = 26
	# Botoes
	t.set_stylebox("normal", "Button", sb(PANEL2, LINE, 14, 2, 14))
	t.set_stylebox("hover", "Button", sb(Color(0.08, 0.16, 0.24, 0.95), CYAN, 14, 2, 14))
	t.set_stylebox("pressed", "Button", sb(Color(0.05, 0.22, 0.30, 1.0), CYAN, 14, 2, 14))
	t.set_stylebox("disabled", "Button", sb(Color(0.05, 0.08, 0.12, 0.7), Color(1, 1, 1, 0.08), 14, 2, 14))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	for n in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		t.set_color(n, "Button", TEXT)
	t.set_color("font_disabled_color", "Button", Color(1, 1, 1, 0.3))
	t.set_font_size("font_size", "Button", 26)
	t.set_stylebox("normal", "OptionButton", sb(PANEL2, LINE, 14, 2, 14))
	t.set_stylebox("hover", "OptionButton", sb(Color(0.08, 0.16, 0.24, 0.95), CYAN, 14, 2, 14))
	t.set_stylebox("pressed", "OptionButton", sb(Color(0.05, 0.22, 0.30, 1.0), CYAN, 14, 2, 14))
	t.set_stylebox("focus", "OptionButton", StyleBoxEmpty.new())
	for n in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		t.set_color(n, "OptionButton", TEXT)
	t.set_font_size("font_size", "OptionButton", 24)
	t.set_stylebox("panel", "PopupMenu", sb(Color(0.03, 0.06, 0.10, 0.98), CYAN, 12, 2, 10))
	t.set_stylebox("hover", "PopupMenu", sb(Color(0.08, 0.2, 0.28, 1.0), Color(0, 0, 0, 0), 8, 0, 8))
	t.set_color("font_color", "PopupMenu", TEXT)
	t.set_color("font_hover_color", "PopupMenu", Color.WHITE)
	t.set_font_size("font_size", "PopupMenu", 24)
	t.set_constant("v_separation", "PopupMenu", 16)
	# Rotulos / texto
	t.set_color("font_color", "Label", TEXT)
	t.set_font_size("font_size", "Label", 26)
	t.set_color("default_color", "RichTextLabel", TEXT)
	t.set_font_size("normal_font_size", "RichTextLabel", 26)
	# Campo de texto
	t.set_stylebox("normal", "LineEdit", sb(Color(0.03, 0.06, 0.10, 0.95), LINE, 18, 2, 16))
	t.set_stylebox("focus", "LineEdit", sb(Color(0.03, 0.07, 0.12, 0.98), CYAN, 18, 2, 16))
	t.set_stylebox("read_only", "LineEdit", sb(Color(0.03, 0.06, 0.10, 0.6), LINE, 18, 2, 16))
	t.set_color("font_color", "LineEdit", TEXT)
	t.set_color("font_placeholder_color", "LineEdit", Color(0.5, 0.65, 0.72, 0.7))
	t.set_color("caret_color", "LineEdit", CYAN)
	t.set_color("selection_color", "LineEdit", Color(0.1, 0.89, 1.0, 0.35))
	t.set_font_size("font_size", "LineEdit", 26)
	# Paineis
	t.set_stylebox("panel", "PanelContainer", sb(PANEL, LINE, 18, 2, 16))
	# Slider
	var track := sb(Color(1, 1, 1, 0.10), Color(0, 0, 0, 0), 4, 0, 0)
	track.content_margin_top = 4
	track.content_margin_bottom = 4
	t.set_stylebox("slider", "HSlider", track)
	var fill := sb(Color(0.1, 0.89, 1.0, 0.55), Color(0, 0, 0, 0), 4, 0, 0)
	fill.content_margin_top = 4
	fill.content_margin_bottom = 4
	t.set_stylebox("grabber_area", "HSlider", fill)
	t.set_stylebox("grabber_area_highlight", "HSlider", fill)
	var g := circle_tex(40, CYAN)
	t.set_icon("grabber", "HSlider", g)
	t.set_icon("grabber_highlight", "HSlider", g)
	t.set_icon("grabber_disabled", "HSlider", g)
	# Barra de rolagem fina
	var sc := sb(Color(1, 1, 1, 0.03), Color(0, 0, 0, 0), 4, 0, 0)
	var gr := sb(Color(0.1, 0.89, 1.0, 0.35), Color(0, 0, 0, 0), 4, 0, 0)
	t.set_stylebox("scroll", "VScrollBar", sc)
	t.set_stylebox("grabber", "VScrollBar", gr)
	t.set_stylebox("grabber_highlight", "VScrollBar", gr)
	t.set_stylebox("grabber_pressed", "VScrollBar", gr)
	t.set_constant("separation", "VBoxContainer", 12)
	t.set_constant("separation", "HBoxContainer", 12)
	return t

# ---------------- componentes simples ----------------
static func label(text: String, size: int = 26, color: Color = TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

static func button(text: String, kind: String = "ghost") -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 76)
	b.focus_mode = Control.FOCUS_NONE
	if kind == "primary":
		b.add_theme_stylebox_override("normal", sb(Color(0.05, 0.35, 0.45, 0.95), CYAN, 14, 2, 14))
		b.add_theme_stylebox_override("hover", sb(Color(0.07, 0.45, 0.58, 1.0), CYAN, 14, 2, 14))
		b.add_theme_stylebox_override("pressed", sb(Color(0.1, 0.6, 0.75, 1.0), CYAN, 14, 2, 14))
	elif kind == "danger":
		b.add_theme_stylebox_override("normal", sb(Color(0.3, 0.07, 0.12, 0.95), RED, 14, 2, 14))
		b.add_theme_stylebox_override("hover", sb(Color(0.42, 0.09, 0.16, 1.0), RED, 14, 2, 14))
		b.add_theme_stylebox_override("pressed", sb(Color(0.55, 0.12, 0.2, 1.0), RED, 14, 2, 14))
	return b

static func spacer(h: int = 8) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	return c

# Cartao: retorna o VBox interno (o PanelContainer ja foi adicionado a parent).
static func card(parent: Node) -> VBoxContainer:
	var p := PanelContainer.new()
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	p.add_child(v)
	parent.add_child(p)
	return v

static func section(parent: Node, title: String) -> void:
	var l := label(title.to_upper(), 22, CYAN)
	parent.add_child(spacer(6))
	parent.add_child(l)

# ---------------- icone desenhado por codigo ----------------
class IconBtn extends Control:
	signal pressed
	var icon := "gear"
	var tint := Color("d6f6ff")
	var ring := true
	var fill := Color(0.06, 0.11, 0.17, 0.9)
	var pulse := false
	var _down := false
	var _t := 0.0

	func _init(icon_name: String = "gear", diameter: float = 72.0, with_ring: bool = true) -> void:
		icon = icon_name
		ring = with_ring
		custom_minimum_size = Vector2(diameter, diameter)
		mouse_filter = Control.MOUSE_FILTER_STOP

	func set_icon(n: String) -> void:
		icon = n
		queue_redraw()

	func _process(delta: float) -> void:
		if pulse:
			_t += delta
			queue_redraw()

	func _gui_input(e: InputEvent) -> void:
		if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
			if e.pressed:
				_down = true
				queue_redraw()
			else:
				var inside := Rect2(Vector2.ZERO, size).has_point(e.position)
				_down = false
				queue_redraw()
				if inside:
					pressed.emit()

	func _draw() -> void:
		var s := minf(size.x, size.y)
		var c := size / 2.0
		var k := 0.92 if _down else 1.0
		if ring:
			draw_circle(c, s * 0.5 * k, fill)
			draw_arc(c, s * 0.5 * k - 1.0, 0, TAU, 48, Color(tint.r, tint.g, tint.b, 0.55), 2.0, true)
			if pulse:
				var ph := fmod(_t * 0.9, 1.0)
				draw_arc(c, s * 0.5 * (1.0 + 0.25 * ph), 0, TAU, 48, Color(tint.r, tint.g, tint.b, 0.5 * (1.0 - ph)), 3.0, true)
		_icon(c, s * 0.62 * k, tint)

	func _icon(c: Vector2, s: float, col: Color) -> void:
		var w := maxf(2.5, s * 0.075)
		match icon:
			"mic":
				draw_rect(Rect2(c.x - 0.13 * s, c.y - 0.30 * s, 0.26 * s, 0.34 * s), col)
				draw_circle(Vector2(c.x, c.y - 0.30 * s), 0.13 * s, col)
				draw_circle(Vector2(c.x, c.y + 0.04 * s), 0.13 * s, col)
				draw_arc(Vector2(c.x, c.y + 0.02 * s), 0.25 * s, 0.0, PI, 24, col, w, true)
				draw_line(Vector2(c.x, c.y + 0.27 * s), Vector2(c.x, c.y + 0.40 * s), col, w)
				draw_line(Vector2(c.x - 0.12 * s, c.y + 0.40 * s), Vector2(c.x + 0.12 * s, c.y + 0.40 * s), col, w)
			"stop":
				draw_rect(Rect2(c.x - 0.22 * s, c.y - 0.22 * s, 0.44 * s, 0.44 * s), col)
			"send":
				draw_colored_polygon(PackedVector2Array([Vector2(c.x - 0.32 * s, c.y - 0.26 * s), Vector2(c.x + 0.36 * s, c.y), Vector2(c.x - 0.32 * s, c.y + 0.26 * s), Vector2(c.x - 0.16 * s, c.y)]), col)
			"gear":
				draw_arc(c, 0.22 * s, 0, TAU, 32, col, w * 1.3, true)
				draw_circle(c, 0.07 * s, col)
				for i in range(8):
					var a := i * TAU / 8.0
					var d := Vector2(cos(a), sin(a))
					draw_line(c + d * 0.27 * s, c + d * 0.40 * s, col, w * 1.7)
			"clock":
				draw_arc(c, 0.34 * s, 0, TAU, 40, col, w, true)
				draw_line(c, c + Vector2(0, -0.22 * s), col, w)
				draw_line(c, c + Vector2(0.15 * s, 0.08 * s), col, w)
			"chip":
				draw_rect(Rect2(c.x - 0.22 * s, c.y - 0.22 * s, 0.44 * s, 0.44 * s), col, false, w)
				draw_rect(Rect2(c.x - 0.09 * s, c.y - 0.09 * s, 0.18 * s, 0.18 * s), col)
				for i in range(3):
					var o := (i - 1) * 0.15 * s
					draw_line(Vector2(c.x + o, c.y - 0.22 * s), Vector2(c.x + o, c.y - 0.36 * s), col, w)
					draw_line(Vector2(c.x + o, c.y + 0.22 * s), Vector2(c.x + o, c.y + 0.36 * s), col, w)
					draw_line(Vector2(c.x - 0.22 * s, c.y + o), Vector2(c.x - 0.36 * s, c.y + o), col, w)
					draw_line(Vector2(c.x + 0.22 * s, c.y + o), Vector2(c.x + 0.36 * s, c.y + o), col, w)
			"back":
				draw_polyline(PackedVector2Array([Vector2(c.x + 0.12 * s, c.y - 0.28 * s), Vector2(c.x - 0.14 * s, c.y), Vector2(c.x + 0.12 * s, c.y + 0.28 * s)]), col, w * 1.3, true)
			"close":
				draw_line(c + Vector2(-0.22, -0.22) * s, c + Vector2(0.22, 0.22) * s, col, w * 1.3)
				draw_line(c + Vector2(0.22, -0.22) * s, c + Vector2(-0.22, 0.22) * s, col, w * 1.3)
			"plus":
				draw_line(c + Vector2(-0.26, 0) * s, c + Vector2(0.26, 0) * s, col, w * 1.3)
				draw_line(c + Vector2(0, -0.26) * s, c + Vector2(0, 0.26) * s, col, w * 1.3)
			"trash":
				draw_rect(Rect2(c.x - 0.18 * s, c.y - 0.12 * s, 0.36 * s, 0.42 * s), col, false, w)
				draw_line(Vector2(c.x - 0.26 * s, c.y - 0.18 * s), Vector2(c.x + 0.26 * s, c.y - 0.18 * s), col, w)
				draw_line(Vector2(c.x - 0.08 * s, c.y - 0.18 * s), Vector2(c.x - 0.08 * s, c.y - 0.28 * s), col, w)
				draw_line(Vector2(c.x + 0.08 * s, c.y - 0.18 * s), Vector2(c.x + 0.08 * s, c.y - 0.28 * s), col, w)
			"repeat":
				draw_arc(c, 0.26 * s, 0.4, TAU - 0.3, 32, col, w, true)
				draw_colored_polygon(PackedVector2Array([c + Vector2(0.30, -0.22) * s, c + Vector2(0.42, 0.0) * s, c + Vector2(0.14, -0.02) * s]), col)
			"volume":
				draw_colored_polygon(PackedVector2Array([c + Vector2(-0.30, -0.12) * s, c + Vector2(-0.14, -0.12) * s, c + Vector2(0.04, -0.28) * s, c + Vector2(0.04, 0.28) * s, c + Vector2(-0.14, 0.12) * s, c + Vector2(-0.30, 0.12) * s]), col)
				draw_arc(c + Vector2(0.04, 0) * s, 0.20 * s, -0.8, 0.8, 12, col, w, true)
				draw_arc(c + Vector2(0.04, 0) * s, 0.32 * s, -0.8, 0.8, 12, col, w, true)
			"download":
				draw_line(Vector2(c.x, c.y - 0.30 * s), Vector2(c.x, c.y + 0.14 * s), col, w * 1.3)
				draw_polyline(PackedVector2Array([Vector2(c.x - 0.16 * s, c.y), Vector2(c.x, c.y + 0.16 * s), Vector2(c.x + 0.16 * s, c.y)]), col, w * 1.3, true)
				draw_line(Vector2(c.x - 0.28 * s, c.y + 0.30 * s), Vector2(c.x + 0.28 * s, c.y + 0.30 * s), col, w * 1.3)
			"check":
				draw_polyline(PackedVector2Array([Vector2(c.x - 0.26 * s, c.y + 0.02 * s), Vector2(c.x - 0.08 * s, c.y + 0.22 * s), Vector2(c.x + 0.28 * s, c.y - 0.22 * s)]), col, w * 1.4, true)
			"wifi_off":
				draw_arc(Vector2(c.x, c.y + 0.22 * s), 0.18 * s, -2.4, -0.74, 12, col, w, true)
				draw_arc(Vector2(c.x, c.y + 0.22 * s), 0.34 * s, -2.4, -0.74, 12, col, w, true)
				draw_circle(Vector2(c.x, c.y + 0.22 * s), 0.04 * s, col)
				draw_line(c + Vector2(-0.3, -0.3) * s, c + Vector2(0.3, 0.3) * s, col, w)
			"bolt":
				draw_colored_polygon(PackedVector2Array([c + Vector2(0.06, -0.34) * s, c + Vector2(-0.16, 0.04) * s, c + Vector2(0.0, 0.04) * s, c + Vector2(-0.06, 0.34) * s, c + Vector2(0.18, -0.06) * s, c + Vector2(0.02, -0.06) * s]), col)

# ---------------- toggle (interruptor) ----------------
class Toggle extends Control:
	signal toggled(on)
	var on := false
	var _anim := 0.0

	func _init(initial: bool = false) -> void:
		on = initial
		_anim = 1.0 if initial else 0.0
		custom_minimum_size = Vector2(96, 52)
		mouse_filter = Control.MOUSE_FILTER_STOP

	func set_on(v: bool) -> void:
		on = v
		queue_redraw()

	func _process(delta: float) -> void:
		var tgt := 1.0 if on else 0.0
		if absf(_anim - tgt) > 0.01:
			_anim = lerpf(_anim, tgt, minf(1.0, delta * 14.0))
			queue_redraw()

	func _gui_input(e: InputEvent) -> void:
		if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT and not e.pressed:
			if Rect2(Vector2.ZERO, size).has_point(e.position):
				on = not on
				toggled.emit(on)
				queue_redraw()

	func _draw() -> void:
		var h := size.y
		var r := h / 2.0
		var bg := Color(0.1, 0.89, 1.0, 0.18 + 0.4 * _anim).lerp(Color(1, 1, 1, 0.1), 1.0 - _anim)
		var sbx := StyleBoxFlat.new()
		sbx.bg_color = bg
		sbx.set_corner_radius_all(int(r))
		sbx.border_color = Color(0.1, 0.89, 1.0, 0.25 + 0.6 * _anim)
		sbx.set_border_width_all(2)
		draw_style_box(sbx, Rect2(Vector2.ZERO, size))
		var cx := lerpf(r, size.x - r, _anim)
		draw_circle(Vector2(cx, r), r - 7.0, Color("19e3ff") if on else Color(0.7, 0.8, 0.85))

# ---------------- linhas de configuracao ligadas ao Cfg ----------------
static func _row(box: Node, title: String, desc: String = "") -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 2)
	col.add_child(label(title, 26))
	if desc != "":
		col.add_child(label(desc, 21, DIM))
	row.add_child(col)
	box.add_child(row)
	return row

static func row_toggle(box: Node, title: String, desc: String, key: String, on_change: Callable = Callable()) -> Toggle:
	var row := _row(box, title, desc)
	var t := Toggle.new(bool(Cfg.get_v(key)))
	t.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	t.toggled.connect(func(v):
		Cfg.set_v(key, v)
		if on_change.is_valid():
			on_change.call(v))
	row.add_child(t)
	return t

static func row_slider(box: Node, title: String, key: String, mn: float, mx: float, step: float, fmt: String = "%.2f") -> HSlider:
	var wrap := VBoxContainer.new()
	wrap.add_theme_constant_override("separation", 4)
	var head := HBoxContainer.new()
	var tl := label(title, 26)
	tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var vl := label(fmt % float(Cfg.get_v(key)), 24, CYAN)
	head.add_child(tl)
	head.add_child(vl)
	wrap.add_child(head)
	var s := HSlider.new()
	s.min_value = mn
	s.max_value = mx
	s.step = step
	s.value = float(Cfg.get_v(key))
	s.custom_minimum_size = Vector2(0, 48)
	s.value_changed.connect(func(v):
		vl.text = fmt % v
		Cfg.set_v(key, int(v) if step >= 1.0 else v))
	wrap.add_child(s)
	box.add_child(wrap)
	return s

# opts: Array de [rotulo, valor]
static func row_option(box: Node, title: String, key: String, opts: Array, on_change: Callable = Callable()) -> OptionButton:
	var row := _row(box, title)
	var ob := OptionButton.new()
	ob.custom_minimum_size = Vector2(300, 64)
	ob.focus_mode = Control.FOCUS_NONE
	var cur = Cfg.get_v(key)
	for i in range(opts.size()):
		ob.add_item(String(opts[i][0]), i)
		if opts[i][1] == cur:
			ob.select(i)
	ob.item_selected.connect(func(idx):
		Cfg.set_v(key, opts[idx][1])
		if on_change.is_valid():
			on_change.call(opts[idx][1]))
	row.add_child(ob)
	return ob

static func row_text(box: Node, title: String, key: String, placeholder: String = "", desc: String = "") -> LineEdit:
	var wrap := VBoxContainer.new()
	wrap.add_theme_constant_override("separation", 6)
	wrap.add_child(label(title, 26))
	if desc != "":
		wrap.add_child(label(desc, 21, DIM))
	var le := LineEdit.new()
	le.text = String(Cfg.get_v(key))
	le.placeholder_text = placeholder
	le.custom_minimum_size = Vector2(0, 68)
	le.text_changed.connect(func(tx): Cfg.set_v(key, tx))
	wrap.add_child(le)
	box.add_child(wrap)
	return le

static func row_button(box: Node, title: String, btn_text: String, cb: Callable, kind: String = "ghost", desc: String = "") -> Button:
	var row := _row(box, title, desc)
	var b := button(btn_text, kind)
	b.custom_minimum_size = Vector2(220, 64)
	b.pressed.connect(cb)
	row.add_child(b)
	return b

# Margens seguras (notch/barras) em unidades do viewport: retorna Vector2(topo, base).
static func safe_insets(ctrl: Control) -> Vector2:
	var vs := ctrl.get_viewport_rect().size
	var ws := Vector2(DisplayServer.window_get_size())
	if ws.y <= 1.0:
		return Vector2(24, 12)
	var k := vs.y / ws.y
	var sa := DisplayServer.get_display_safe_area()
	var top := maxf(24.0, float(sa.position.y) * k)
	var bottom := maxf(10.0, (ws.y - float(sa.end.y)) * k)
	return Vector2(top, bottom)
