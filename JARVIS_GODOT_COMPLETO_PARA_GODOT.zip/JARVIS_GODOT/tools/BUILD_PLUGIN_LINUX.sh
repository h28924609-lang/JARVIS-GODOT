#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
command -v java >/dev/null || { echo 'ERRO: JDK 17 ausente'; exit 1; }
command -v git >/dev/null || { echo 'ERRO: Git ausente'; exit 1; }
command -v cmake >/dev/null || { echo 'ERRO: CMake ausente'; exit 1; }
[ -n "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ] || { echo 'ERRO: defina ANDROID_HOME ou ANDROID_SDK_ROOT'; exit 1; }
java -version 2>&1 | grep -q '17\.' || { echo 'ERRO: use JDK 17'; exit 1; }
chmod +x jarvis_android_plugin/gradlew jarvis_android_plugin/scripts/build_aar.sh
bash jarvis_android_plugin/scripts/build_aar.sh
python3 tools/verificar_aar.py addons/jarvis_android/bin/jarvis-debug.aar addons/jarvis_android/bin/jarvis-release.aar
