@echo off
setlocal EnableExtensions
cd /d "%~dp0.."
echo ================================================
echo JARVIS - Compilacao real do plugin Android
 echo ================================================
where git >nul 2>nul || (echo ERRO: instale Git for Windows e adicione ao PATH.& pause& exit /b 1)
where java >nul 2>nul || (echo ERRO: instale JDK 17 e adicione bin ao PATH.& pause& exit /b 1)
where cmake >nul 2>nul || (echo ERRO: instale CMake 3.22.1 ou superior.& pause& exit /b 1)
if "%ANDROID_HOME%"=="" if "%ANDROID_SDK_ROOT%"=="" (echo ERRO: ANDROID_HOME/ANDROID_SDK_ROOT nao definido.& pause& exit /b 1)
java -version 2>&1 | findstr /C:"17." >nul || (echo ERRO: o Java ativo precisa ser JDK 17.& pause& exit /b 1)
if not exist "jarvis_android_plugin\gradlew.bat" (echo ERRO: Gradle Wrapper ausente.& pause& exit /b 1)
call jarvis_android_plugin\scripts\build_aar.bat
if errorlevel 1 (echo.
echo FALHA: plugin nao compilado. Leia o erro acima.
pause
exit /b 1)
echo.
echo SUCESSO: AARs reais validados em addons\jarvis_android\bin\
echo Feche e reabra o projeto no Godot e exporte novamente para Android.
pause
