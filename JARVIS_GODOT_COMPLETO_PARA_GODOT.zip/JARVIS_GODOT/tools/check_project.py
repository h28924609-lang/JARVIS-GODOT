#!/usr/bin/env python3
"""Checagens ESTATICAS de consistencia do projeto (nao compila Kotlin/C++ nem executa o Godot)."""
import re, json, pathlib, sys

root = pathlib.Path(__file__).resolve().parent.parent
err = []

# 1) caminhos res:// existentes
res_re = re.compile(r'(?:preload|load)\("res://([^"]+)"\)|"res://([^"]+\.(?:gd|tscn|json|gbnf|svg|cfg))"')
for f in list(root.rglob("*.gd")) + list(root.rglob("*.tscn")) + [root / "project.godot", root / "export_presets.cfg"]:
    if "jarvis_android_plugin" in f.parts:
        continue
    for m in re.finditer(r'res://([\w/\.\-]+)', f.read_text(encoding="utf-8")):
        p = m.group(1)
        if p.endswith("/") or "%" in p or p.endswith(".aar"):  # AAR e gerado no build
            continue
        if not (root / p).exists():
            err.append(f"{f.relative_to(root)}: caminho inexistente res://{p}")

# 2) JSON validos
for j in list(root.rglob("*.json")):
    try:
        json.loads(j.read_text(encoding="utf-8"))
    except Exception as e:
        err.append(f"{j.relative_to(root)}: JSON invalido: {e}")

# 3) metodos do plugin chamados no GDScript existem no Kotlin
kt = (root / "jarvis_android_plugin/jarvis/src/main/kotlin/com/jarvis/assistant/JarvisPlugin.kt").read_text(encoding="utf-8")
exposed = set(re.findall(r"@UsedByGodot\s+fun\s+(\w+)\(", kt))
used = set()
for f in root.rglob("*.gd"):
    t = f.read_text(encoding="utf-8")
    used |= set(re.findall(r'Bridge\.api\("(\w+)"', t))
    used |= set(re.findall(r'Bridge\.plugin\.(\w+)\(', t))
    used |= set(re.findall(r'\bplugin\.(\w+)\(', t))
used -= {"connect", "callv", "call", "get", "has_method"}
for u in sorted(used):
    if u not in exposed:
        err.append(f"GDScript chama plugin.{u}() que NAO existe no JarvisPlugin.kt")
print(f"metodos expostos no Kotlin: {len(exposed)}; usados no GDScript: {len(used)}")

# 4) eventos emitidos (Kotlin) x consumidos (GDScript)
emitted = set()
for f in (root / "jarvis_android_plugin").rglob("*.kt"):
    emitted |= set(re.findall(r'emit\("(\w+)"', f.read_text(encoding="utf-8")))
    emitted |= set(re.findall(r'eventName: String = "(\w+)"', f.read_text(encoding="utf-8")))
consumed = set()
for f in root.rglob("*.gd"):
    consumed |= set(re.findall(r'"(\w+)":\n', f.read_text(encoding="utf-8")))
    consumed |= set(re.findall(r'ev(?:_name)? [=!]= "(\w+)"', f.read_text(encoding="utf-8")))
    consumed |= set(re.findall(r'_wait_event\("(\w+)"', f.read_text(encoding="utf-8")))
need = {"llm_token", "llm_done", "llm_load", "download", "tts_state", "tts_ready", "stt_partial", "stt_final", "stt_error", "stt_rms", "plan_progress", "wake_word", "pong", "llm_bench", "vosk_download", "memory_trim"}
for n in sorted(need):
    if n not in emitted:
        err.append(f"evento '{n}' nunca e emitido pelo Kotlin")
    if n not in consumed and n not in {"stt_state"}:
        err.append(f"evento '{n}' nao e consumido no GDScript")

# 5) balanceamento de chaves/parenteses nos Kotlin e C++
for f in list((root / "jarvis_android_plugin").rglob("*.kt")) + list((root / "jarvis_android_plugin").rglob("jarvis_llama.cpp")):
    t = re.sub(r'"(?:\\.|[^"\\])*"', '""', f.read_text(encoding="utf-8"))
    t = re.sub(r"//.*", "", t)
    for a, b in ("{}", "()", "[]"):
        if t.count(a) != t.count(b):
            err.append(f"{f.relative_to(root)}: {a}{b} desbalanceado ({t.count(a)} x {t.count(b)})")

# 6) JNI: funcoes nativas Kotlin x C++
jni_kt = set(re.findall(r"external fun (\w+)\(", (root / "jarvis_android_plugin/jarvis/src/main/kotlin/com/jarvis/assistant/engine/LlamaBridge.kt").read_text(encoding="utf-8")))
jni_cpp = set(re.findall(r"Java_com_jarvis_assistant_engine_LlamaBridge_(\w+)\(", (root / "jarvis_android_plugin/jarvis/src/main/cpp/jarvis_llama.cpp").read_text(encoding="utf-8")))
if jni_kt != jni_cpp:
    err.append(f"JNI divergente: so Kotlin {jni_kt - jni_cpp}; so C++ {jni_cpp - jni_kt}")

# 7) manifest referencia classes existentes
mf = (root / "jarvis_android_plugin/jarvis/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
for cls in re.findall(r'android:(?:name|value)="(com\.jarvis\.assistant\.[\w\.]+)"', mf):
    path = root / "jarvis_android_plugin/jarvis/src/main/kotlin" / (cls.replace(".", "/") + ".kt")
    simple = cls.split(".")[-1]
    found = path.exists() or any(re.search(rf"class {simple}\b", p.read_text(encoding="utf-8")) for p in (root / "jarvis_android_plugin").rglob("*.kt"))
    if not found:
        err.append(f"manifest referencia classe inexistente: {cls}")

# 8) autoloads
pg = (root / "project.godot").read_text(encoding="utf-8")
for m in re.finditer(r'^(\w+)="\*res://([^"]+)"', pg, re.M):
    if not (root / m.group(2)).exists():
        err.append(f"autoload {m.group(1)} aponta para arquivo inexistente")

print("\n".join("ERRO " + e for e in err) if err else "check_project: sem erros")
sys.exit(1 if err else 0)
