#!/usr/bin/env bash
# Exporta o APK do Jarvis com o Godot (headless) usando build Gradle + AAR do plugin.
# Requisitos: Godot 4.7.2 + export templates 4.7.2 instalados, JDK 17, Android SDK, AAR em addons/jarvis_android/bin/.
# Variaveis: GODOT_BIN (padrao: godot), ANDROID_SDK_ROOT, JAVA_HOME, GODOT_VERSION (padrao 4.7.2), BUILD_TYPE (debug|release)
set -euo pipefail
cd "$(dirname "$0")/.."
GODOT_BIN="${GODOT_BIN:-godot}"
GODOT_VERSION="${GODOT_VERSION:-4.7.2}"
BUILD_TYPE="${BUILD_TYPE:-debug}"
TPL="$HOME/.local/share/godot/export_templates/${GODOT_VERSION}.stable"

[ -f addons/jarvis_android/bin/jarvis-${BUILD_TYPE}.aar ] || { echo "AAR ausente: rode jarvis_android_plugin/scripts/build_aar.sh"; exit 1; }
[ -f "$TPL/android_source.zip" ] || { echo "Export templates ${GODOT_VERSION} nao encontrados em $TPL"; exit 1; }

# 1) template de build Android (equivale a Projeto > Instalar template de build do Android)
if [ ! -d android/build ]; then
  mkdir -p android/build
  unzip -q -o "$TPL/android_source.zip" -d android/build
  echo "${GODOT_VERSION}.stable" > android/.build_version
  touch android/build/.gdignore
fi

# 2) keystore de debug
KS="$HOME/.android/debug.keystore"
if [ ! -f "$KS" ]; then
  mkdir -p "$HOME/.android"
  keytool -genkeypair -v -keystore "$KS" -storepass android -alias androiddebugkey -keypass android \
    -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US"
fi

# 3) configuracoes do editor (cria o arquivo padrao e acrescenta as chaves do Android)
"$GODOT_BIN" --headless --quit >/dev/null 2>&1 || true
CFGDIR="$HOME/.config/godot"; mkdir -p "$CFGDIR"
SETS=$(ls "$CFGDIR"/editor_settings-*.tres 2>/dev/null || true)
if [ -z "$SETS" ]; then
  for n in 4 4.7; do printf '[gd_resource type="EditorSettings" format=3]\n\n[resource]\n' > "$CFGDIR/editor_settings-$n.tres"; done
  SETS=$(ls "$CFGDIR"/editor_settings-*.tres)
fi
for S in $SETS; do
  sed -i '/^export\/android\//d' "$S"
  {
    echo "export/android/android_sdk_path = \"${ANDROID_SDK_ROOT:-$ANDROID_HOME}\""
    echo "export/android/java_sdk_path = \"${JAVA_HOME}\""
    echo "export/android/debug_keystore = \"$KS\""
    echo "export/android/debug_keystore_user = \"androiddebugkey\""
    echo "export/android/debug_keystore_pass = \"android\""
  } >> "$S"
done

# 4) importar recursos e exportar
"$GODOT_BIN" --headless --import || true
mkdir -p build
if [ "$BUILD_TYPE" = "release" ]; then
  "$GODOT_BIN" --headless --export-release "Android" build/JARVIS-release.apk
else
  "$GODOT_BIN" --headless --export-debug "Android" build/JARVIS-debug.apk
fi
ls -lh build/
