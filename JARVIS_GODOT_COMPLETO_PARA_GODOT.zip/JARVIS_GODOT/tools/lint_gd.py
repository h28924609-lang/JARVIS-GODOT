#!/usr/bin/env python3
"""Verificacao ESTATICA aproximada de GDScript (nao substitui o Godot): indentacao, parenteses, armadilhas conhecidas."""
import re, sys, pathlib

root = pathlib.Path(__file__).resolve().parent.parent
problems = []

def strip_strings(line):
    out, i, q = [], 0, None
    while i < len(line):
        c = line[i]
        if q:
            if c == "\\":
                i += 2
                continue
            if c == q:
                q = None
        else:
            if c in "\"'":
                q = c
            elif c == "#":
                break
            else:
                out.append(c)
        i += 1
    return "".join(out)

for f in sorted(root.rglob("*.gd")):
    if "jarvis_android_plugin" in f.parts:
        continue
    text = f.read_text(encoding="utf-8")
    depth = {"(": 0, "[": 0, "{": 0}
    pairs = {")": "(", "]": "[", "}": "{"}
    for n, raw in enumerate(text.split("\n"), 1):
        if raw.strip() == "" or raw.lstrip().startswith("#"):
            continue
        lead = raw[: len(raw) - len(raw.lstrip())]
        if " " in lead and depth["("] + depth["["] + depth["{"] == 0:
            problems.append(f"{f.relative_to(root)}:{n}: indentacao com espacos")
        code = strip_strings(raw)
        for ch in code:
            if ch in depth:
                depth[ch] += 1
            elif ch in pairs:
                depth[pairs[ch]] -= 1
        if re.search(r":=\s*await\b", code):
            problems.append(f"{f.relative_to(root)}:{n}: ':= await' (tipo nao inferivel) -> use 'var x: Tipo = await'")
        if re.search(r"\b(yield|onready var|export var|PoolStringArray|rand_range|OS\.get_ticks_msec|\.connect\(\"[a-z_]+\",\s*self)", code):
            problems.append(f"{f.relative_to(root)}:{n}: construcao do Godot 3")
        m = re.search(r"\bvar\s+\w+\s*:=\s*(.+)$", code)
        if m:
            rhs = m.group(1)
            if re.search(r"\.get\(|\[[^\]]*\]\s*$", rhs) and not re.search(r"(String|float|int|bool|Vector2|Color)\(", rhs) and "if " not in rhs:
                problems.append(f"{f.relative_to(root)}:{n}: ':=' possivelmente sobre Variant: {rhs.strip()[:70]}")
    if sum(depth.values()) != 0:
        problems.append(f"{f.relative_to(root)}: parenteses/colchetes/chaves desbalanceados {depth}")

print(f"arquivos .gd verificados: {len(list(root.rglob('*.gd')))}")
for p in problems:
    print("AVISO", p)
print("sem avisos" if not problems else f"{len(problems)} aviso(s)")
sys.exit(1 if problems else 0)
