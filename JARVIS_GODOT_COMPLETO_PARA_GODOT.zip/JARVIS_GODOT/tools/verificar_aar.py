#!/usr/bin/env python3
"""Confere se um AAR do Jarvis e REAL e completo (nao basta o arquivo existir).
Uso: python3 tools/verificar_aar.py addons/jarvis_android/bin/jarvis-debug.aar [...]
Falha (codigo 1) se faltar classes Kotlin, biblioteca nativa ARM64 ou o registro do plugin no manifesto."""
import sys, zipfile, struct

def elf_machine(data):
    # e_machine 183 (0xB7) = AArch64
    if data[:4] != b"\x7fELF" or len(data) < 20:
        return None
    return struct.unpack_from("<H", data, 18)[0]

def check(path):
    errs = []
    try:
        z = zipfile.ZipFile(path)
    except Exception as e:
        return ["nao e um ZIP/AAR valido: %s" % e]
    names = set(z.namelist())
    for need in ("AndroidManifest.xml", "classes.jar"):
        if need not in names:
            errs.append("falta %s" % need)
    so = "jni/arm64-v8a/libjarvis_llama.so"
    if so not in names:
        errs.append("falta %s (motor llama.cpp ARM64)" % so)
    else:
        data = z.read(so)
        if len(data) < 500_000:
            errs.append("%s pequena demais (%d bytes): o llama.cpp nao foi compilado dentro dela" % (so, len(data)))
        if elf_machine(data) != 183:
            errs.append("%s nao e ELF AArch64" % so)
    if "classes.jar" in names:
        import io
        cj = zipfile.ZipFile(io.BytesIO(z.read("classes.jar")))
        cn = set(cj.namelist())
        for cls in ("com/jarvis/assistant/JarvisPlugin.class", "com/jarvis/assistant/engine/LlamaBridge.class",
                    "com/jarvis/assistant/engine/LlmManager.class", "com/jarvis/assistant/engine/ModelImporter.class"):
            if cls not in cn:
                errs.append("classes.jar sem %s" % cls)
    if "AndroidManifest.xml" in names:
        m = z.read("AndroidManifest.xml")
        # manifesto do AAR e XML binario ou texto; o nome aparece como string em ambos (UTF-8 ou UTF-16LE)
        for token in ("org.godotengine.plugin.v2.JarvisPlugin", "com.jarvis.assistant.JarvisPlugin"):
            if token.encode() not in m and token.encode("utf-16-le") not in m:
                errs.append("manifesto sem o registro %s" % token)
    return errs

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(2)
    bad = 0
    for p in sys.argv[1:]:
        e = check(p)
        print(("OK    " if not e else "ERRO  ") + p)
        for x in e:
            print("   - " + x)
        bad += bool(e)
    sys.exit(1 if bad else 0)
